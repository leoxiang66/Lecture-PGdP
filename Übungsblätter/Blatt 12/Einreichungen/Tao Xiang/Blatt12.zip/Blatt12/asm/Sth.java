package asm;
import static asm.Opcode.*;
public class Sth extends Instruction{
    @Override
    public void accept(AsmVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return  STH.toString();
    }
}
