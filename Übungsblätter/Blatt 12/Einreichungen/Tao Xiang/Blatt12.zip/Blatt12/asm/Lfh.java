package asm;
import static asm.Opcode.*;
public class Lfh extends  Instruction{
    @Override
    public void accept(AsmVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return LFH.toString();
    }
}
