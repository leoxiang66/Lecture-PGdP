package asm;

public class InvalidHeapAccessException extends InterpreterException{
    public InvalidHeapAccessException() {
        super("invalid heap access");
    }
    private static final long serialVersionUID = 1L;
}
