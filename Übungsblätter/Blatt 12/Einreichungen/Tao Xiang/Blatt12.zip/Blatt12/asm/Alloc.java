package asm;

public class Alloc extends Instruction{
    @Override
    public void accept(AsmVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public java.lang.String toString() {
        return Opcode.ALLOC.toString();
    }
}
