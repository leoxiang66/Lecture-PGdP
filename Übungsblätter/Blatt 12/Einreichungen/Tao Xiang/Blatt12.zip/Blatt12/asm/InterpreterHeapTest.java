package asm;
import codegen.InvalidArraySizeDeclarationExpection;
import org.junit.*;

import static org.junit.Assert.assertEquals;

public class InterpreterHeapTest {
    /* Bsp:
    @Test
    public void testExpr() {
        Instruction[] program = {
                new Ldi(5),
                new Ldi(2),
                new Mul(),
                new Ldi(3),
                new Mod(),
                new Not(),
                new Halt()
        };
        Interpreter intp = new Interpreter(program);
        assertEquals(-4, intp.execute());
    }*/

    @Test(expected = InvalidArraySizeDeclarationExpection.class)
    public  void shouldThrow1() throws InterpreterException{
        Instruction[] program={
          new Decl(1),
          new Ldi(1025),
          new Alloc(),
          new Halt()
        };
        Interpreter intp=new Interpreter(program);
        intp.execute();
    }

    @Test(expected = InvalidHeapAccessException.class)
    public void shouldThrow2() throws  InterpreterException{
        Instruction[] program={
                new Decl(1),
                new Ldi(2),
                new Alloc(),
                new Sts(1),
                new Ldi(42),
                new Lfs(1),
                new Ldi(1025),
                new Add(),
                new Sth(),
                new Halt()
        };
        Interpreter intp= new Interpreter(program);
        intp.execute();
    }
    @Test
    public void testAssignment(){
        Instruction[] program={
          new Decl(1),
          new Ldi(2),
          new Alloc(),
          new Sts(1),
          new Ldi(42),
          new Lfs(1),
          new Ldi(1),
          new Add(),
          new Sth(),
          new Lfs(1),
          new Ldi(1),
          new Add(),
          new Lfh(),
          new Halt()
        };
        Interpreter intp= new Interpreter(program);
        assertEquals(42,intp.execute());
    }
}
