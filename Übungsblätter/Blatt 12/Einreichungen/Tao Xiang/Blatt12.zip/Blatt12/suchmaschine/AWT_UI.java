package suchmaschine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.net.Socket;
import javax.swing.*;
import javax.swing.SwingConstants.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class AWT_UI extends Frame {

    private Socket client=null;
    String host="localhost";
    int port=8000;
    private Button  exit= new Button("exit"),
                    add = new Button("add"),
                    list= new Button("list"),
                    query= new Button("query"),
                    count= new Button("count"),
                    pageRank=new Button("pageRank"),
                    crawl = new Button("crawl");
            TextArea displayField = new TextArea();
    private BufferedReader in=null;
            PrintWriter out = null;
    AWT_UI()
    {try{
        displayField.append("Welcome To My Suchmaschine!\npress[connect] to connect my server, have fun! \n");
        add.setEnabled(false);
        list.setEnabled(false);
        query.setEnabled(false);
        count.setEnabled(false);
        pageRank.setEnabled(false);
        crawl.setEnabled(false);



        Panel panel = new Panel();
        panel.setLayout(new GridLayout(7,1));
        //panel.setSize(300,300);

        setSize(500,500);
        Panel Query = new Panel(new BorderLayout());
        TextField queryField = new TextField();
        Query.add("Center",queryField);
        Query.add("East",query);
        panel.add(add);
        panel.add(list );
        panel.add(crawl);
        panel.add(Query);
        Panel Count = new Panel(new BorderLayout());
        TextField countField = new TextField();
        Count.add("Center",countField);
        Count.add("East",count);
        panel.add(Count);
        panel.add(pageRank);
        panel.add(exit);
        setLocation(600,400);
      //  setSize(500,500);
        Label title = new Label("Suchmaschine", Label.CENTER);
        title.setFont(new Font("Helvetica", Font.BOLD, 14));
        setLayout(new BorderLayout());

        Panel Connect = new Panel(new GridLayout(5,1));
        Label host = new Label("host");
        TextField hostField = new TextField("127.0.0.1");
        Label port = new Label("port");
        TextField portField= new TextField("8000");
        Button ConnectButton = new Button("connect");

        Connect.add(host);
        Connect.add(hostField);
        Connect.add(port);
        Connect.add(portField);
        Connect.add(ConnectButton);
        ConnectButton.addActionListener(actionEvent->{
            try {
                client= new Socket(hostField.getText(),Integer.parseInt(portField.getText()));
                in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                out= new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                println("connecting...");
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                println("connected to "+hostField.getText()+" "+ portField.getText());
            } catch (IOException e) {
                e.printStackTrace();
                println("connection error :"+e.getMessage());
            }

            add.setEnabled(true);
            ConnectButton.setEnabled(false);

        });
        Panel zeiger = new Panel(new BorderLayout());
        zeiger.add("North",title);
        zeiger.add("Center",displayField);
        zeiger.add("West",Connect);
        add("Center",panel);
        add("North",zeiger);
        pack();
        setVisible(true);

        pageRank.addActionListener(actionEvent->{
            out.println("pageRank");
            out.flush();
            println("pageRank instruction sending...");
            println("pageRank succeed");
            EventQueue.invokeLater(()->{
                JFrame newWindow = new JFrame("pageRank Results");
                newWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                newWindow.setLocation(800,200);
                TextArea display = new TextArea("");
                display.setEditable(false);
                this.skipIllegalChar(display);
                newWindow.add(display);
                newWindow.pack();
                newWindow.setVisible(true);
            });
        });
        count.addActionListener(actionEvent->{
            out.println("count "+countField.getText());
            out.flush();
            println("count "+countField.getText()+" instruction sending...");
            println("count "+countField.getText()+" succeed");
            EventQueue.invokeLater(()->{
                JFrame newWindow = new JFrame("count Results");
                newWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                newWindow.setLocation(800,200);
                TextArea display = new TextArea("");
                display.setEditable(false);
                this.skipIllegalChar(display);
                newWindow.add(display);
                newWindow.pack();
                newWindow.setVisible(true);
                countField.setText("");
            });

        });
        query.addActionListener(actionEvent->{
            println("query "+queryField.getText()+" instruction sending");
            println("query "+queryField.getText()+" succeed");
            out.println("query "+queryField.getText());
            out.flush();
            EventQueue.invokeLater(()->{
                JFrame newWindow = new JFrame("query Results");
                newWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                newWindow.setLocation(800,200);
                TextArea display = new TextArea("");
                display.setEditable(false);
                this.skipIllegalChar(display);
                newWindow.add(display);
                newWindow.pack();
                newWindow.setVisible(true);
                queryField.setText("");
            });
        });
        exit.addActionListener(actionEvent->{
            this.dispose();
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        });
        add.addActionListener(actionEvent->{
            println("add instruction sending...");
            EventQueue.invokeLater(()->{
                javax.swing.JFrame newWindow = new javax.swing.JFrame("add Document");
                newWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE );
                newWindow.setLocation(800,200);
                Label l1= new Label("Beispiel:");
                Label l2 = new Label("Titel:     ");
                Label l3  = new Label("Content:");
                TextArea exmp = new TextArea("z.B. :\nbei Title: \"A.txt\"\nbei Content: \"blablabla link:B.txt tralalalal link:C.txt tetsetse ende\"");
               Panel p1 = new Panel(new BorderLayout());
               p1.add("West",l1);
               p1.add("Center",exmp);
                exmp.setEditable(false);
                TextField titel = new TextField();
                Panel p2 = new Panel(new BorderLayout());
                p2.add("West",l2);
                p2.add("Center",titel);
                TextField content = new TextField();
                Panel p3 = new Panel(new BorderLayout());
                p3.add("West",l3);
                p3.add("Center",content);





                Button addButton = new Button("add");
                newWindow.setLayout(new GridLayout(4,1));
                newWindow.add(p1);
                newWindow.add(p2   );
                newWindow.add(p3);
                newWindow.add(addButton);

                addButton.addActionListener(actionEvent2->{
                    list.setEnabled(true);
                    query.setEnabled(true);
                    count.setEnabled(true);
                    pageRank.setEnabled(true);
                    crawl.setEnabled(true);
                    String request = "add "+titel.getText()+":"+content.getText();
                    println("adding "+titel.getText()+"...");
                    println("adding "+titel.getText()+" succeed");
                    out.println(request);
                    out.flush();
                    titel.setText("");
                    content.setText("");
                    newWindow.dispose();
                });
               newWindow.pack();
                newWindow.setVisible(true);
            });
        });

        list.addActionListener(actionEvent->{
            //System.out.println("t1");
            println("list instruction sending...");
            println("list succeed");
            out.println("list");
            out.flush();

            //System.out.println("t2");
            
           EventQueue.invokeLater(()->{
                JFrame newWindow = new JFrame("List Results");
               newWindow.setLocation(800,200);
             newWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

              TextArea results = new TextArea("");
              results.setEditable(false);
              Panel panel2 = new Panel();
             // StringBuilder tmp = new StringBuilder("");


              // System.out.println((char)a);

            this.skipIllegalChar(results);
               panel2.add(results);

           
            //System.out.println("results: "+results.getText());
                newWindow.add(panel2);
                newWindow.pack();
                newWindow.setVisible(true);
            });
           //System.out.println("t3");
        });

        crawl.addActionListener(actionEvent->{
            println("crawl instruction sending...");
            println("crawl succeed");
            out.println("crawl");
            out.flush();
        });
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

    }
    catch(Exception e ){}}
    private void skipIllegalChar (TextArea display)
    {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

            display.setText("");
        int a =0;
        do{
            try {
                if(!in.ready()) break;
                a = in.read();

                //System.out.print((char)a+", ");
            } catch (IOException e) {
                e.printStackTrace();
            }}
        while((char)a=='>'||(char)a==' ');

        while((char)a!='>'&&a!=-1)
        {
           //System.out.print((char)a);
            display.append(new String(new char[]{(char)a}));
            try {
                if(!in.ready()) break;
                a=in.read();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }

    private void println(String msg){displayField.append("  ***  "+msg+"\n");}

    public static void main(String[] args)
    {
    AWT_UI test = new AWT_UI();
    }
}
