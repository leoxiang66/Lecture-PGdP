package suchmaschine;

public enum HttpMethod {
  GET, POST
}
