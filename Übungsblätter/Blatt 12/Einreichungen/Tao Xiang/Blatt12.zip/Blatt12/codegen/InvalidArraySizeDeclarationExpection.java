package codegen;

public class InvalidArraySizeDeclarationExpection extends CodeGenException{
    public InvalidArraySizeDeclarationExpection() {
        super("invalid array size declaration ");
    }
    private static final long serialVersionUID = 1L;
}
