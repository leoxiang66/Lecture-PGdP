package codegen;

public class Function {
  private String name;
  private Type retType;
  public String getName() {
    return name;
  }

  private Parameter[] parameters;

  public Parameter[] getParameters() {
    return parameters;
  }

  private Declaration[] declarations;

  public Declaration[] getDeclarations() {
    return declarations;
  }

  private Statement[] statements;

  public Statement[] getStatements() {
    return statements;
  }

  public Function(Type retType,String name, Parameter[] parameters, Declaration[] declarations,
      Statement[] statements) {
    super();
    this.retType=retType;
    this.name = name;
    this.parameters = parameters;
    this.declarations = declarations;
    this.statements = statements;
  }

  public Type getRetType() {
    return retType;
  }

  public Function(String name, String[] intParameters, Declaration[] declarations,
                  Statement[] statements) {
    super();
    retType=Type.Int;
    this.name = name;
    Parameter[] parameters = new Parameter[intParameters.length];
    for(int i=0;i<parameters.length;i++)
    {
      parameters[i]= new Parameter(Type.Int,intParameters[i]);
    }
    this.parameters = parameters;
    this.declarations = declarations;
    this.statements = statements;
  }
  public void accept(ProgramVisitor visitor) {
    visitor.visit(this);
  }
}
