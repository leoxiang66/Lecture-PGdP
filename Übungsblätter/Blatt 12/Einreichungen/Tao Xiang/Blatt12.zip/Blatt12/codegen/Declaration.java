package codegen;

public class Declaration {
 private String[] names;
 private Type type;
  public String[] getNames() {
    return names;
  }
  
  public Declaration(String[] names) {
    super();
    type=Type.Int;
    this.names = names;
  }

    public Type getType() {
        return type;
    }

    public Declaration(String a) {
      type=Type.Int;
    this.names = new String [] { a };
  }

  public Declaration(String a, String b) {
      type=Type.Int;
    this.names = new String [] { a, b };
  }
  public Declaration(String a,String b,String c)
  {
      type=Type.Int;
      names=new String[]{a,b,c};
  }
  public  Declaration(Type type,String[] names)
  {
      this.type=type;
      this.names=names;
  }
  public Declaration  (Type type, String name)
  {
      this.type=type;
      this.names=new String[]{name};
  }
  public Declaration(Type type,String a, String b)
  {
      this.type=type;
      this.names=new String[]{a,b};
  }
  public Declaration(Type type,String a ,String b,String c)
  {
      this.type=type;
      names=new String[]{a,b,c};
  }
  public void accept(ProgramVisitor visitor) {
    visitor.visit(this);
  }
}
