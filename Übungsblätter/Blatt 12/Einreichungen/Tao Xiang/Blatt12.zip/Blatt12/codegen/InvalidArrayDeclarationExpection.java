package codegen;

public class InvalidArrayDeclarationExpection extends CodeGenException {
    public InvalidArrayDeclarationExpection() {
        super("invalid array declaration");
    }
    private static final long serialVersionUID = 1L;
}
