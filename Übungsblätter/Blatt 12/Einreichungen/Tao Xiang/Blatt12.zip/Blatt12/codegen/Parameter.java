package codegen;

public class Parameter {
  private Type type;
  
  public Type getType() {
    return type;
  }
  
  private String name;
  
  public String getName() {
    return name;
  }

  @Override
  public String toString() {
    return getName();
  }

  public Parameter(Type type, String name) {
    this.type = type;
    this.name = name;
  }
}
