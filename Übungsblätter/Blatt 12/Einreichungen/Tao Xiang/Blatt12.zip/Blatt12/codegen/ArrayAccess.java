package codegen;

public class ArrayAccess extends  Expression{
    private Expression Array;
    private Expression Index;
    ArrayAccess(Expression Array,Expression index){
        this.Array=Array;
        this.Index=index;
    }
    public  Expression getArray(){return Array;}

    public Expression getIndex() {
        return Index;
    }

    @Override
    public void accept(ProgramVisitor visitor) {
        visitor.visit(this);
    }
}
