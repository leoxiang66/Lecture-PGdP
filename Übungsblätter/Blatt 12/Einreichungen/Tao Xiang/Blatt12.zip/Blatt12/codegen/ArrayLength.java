package codegen;

public class ArrayLength extends Expression{
    private  Expression Array;
    public  ArrayLength(Expression array){Array=array;}
    public Expression getArray() {
        return Array;
    }

    @Override
    public void accept(ProgramVisitor visitor) {
        visitor.visit(this);
    }
}
