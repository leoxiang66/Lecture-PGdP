package codegen;

import asm.Cmp;
import asm.CompareType;
import asm.Instruction;
import asm.Interpreter;

import java.util.Arrays;

public class test{

    private static void mergeSort(int[] arr, int low, int high) {
        if (high <= low)
            return;

        int mid = (low + high) / 2;
        mergeSort(arr,low,mid);
        merge(arr,low,mid);
        mergeSort(arr,mid+1,high);
        merge(arr,mid+1,high);
        merge(arr, low, high);
        
    }

    private static void merge(int[] arr, int low,int high) {
        int mid = (low+high)/2;
        int i = low;
        int j = mid + 1;
        int k = 0;

        final int SIZE = high - low + 1;
        int[] helperArr = new int[SIZE];

        while (i <= mid && j <= high) {
            if (arr[i] < arr[j]) {
                helperArr[k++] = arr[i++];
            } else {
                helperArr[k++] = arr[j++];
            }
        }

        while (i <= mid) {
            helperArr[k++] = arr[i++];
        }
        while (j <= high) {
            helperArr[k++] = arr[j++];
        }
        for (i = 0; i < SIZE; i++) {
            arr[low + i] = helperArr[i];
        }
    }
    public static void bubbleSort(int [] arr)
    {
        int i,j,tmp;
        i=arr.length-1;
        
        while (i>0)
        {
            j=0;
            while (j<i)
            {
                if(arr[j]>arr[j+1])
                {
                    tmp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=tmp;
                }
                j++;
            }
            i--;
        }
    }
    public static void main(String[] args) {
        int[] arr = {5,4,3,2,1};





        /*
     int  main ()
    {
    int [] a ;
    a= new int[1];
    a=rec(a);
    return a.length;
    }
     int[] rec (int [] a )
    {
        int [] ret;
        if(a.length>=5) ret = a;
        if(a.length<5)
        {
            ret= new int[a.length+1];
            rec(ret);
        }
        return  ret;

    }*/

        //mergeSort(a, 0, 4);
        //System.out.println(Arrays.toString(a));
/*
        int[] rightArray= {2,3,6,8,9};
        java.util.function.Function<Integer, Program> ArrayAccess = (index) -> {
            Function main = new Function(Type.Int, "main", new Parameter[]{}, new Declaration[]{new Declaration(Type.IntArray, "a")},
                    new Statement[]{new Assignment("a", new ArrayAllocator(new Number(3))),
                            new ArrayIndexAssignment(new Variable("a"), new Number(0), new Number(9)),
                            new ArrayIndexAssignment(new Variable("a"), new Number(1), new Number(3)),
                            new ArrayIndexAssignment(new Variable("a"), new Number(2), new Number(8)),
                           // new ArrayIndexAssignment(new Variable("a"), new Number(3), new Number(2)),
                           // new ArrayIndexAssignment(new Variable("a"), new Number(4), new Number(6)),
                            new ExpressionStatement(new Call("mergeSort", new Expression[]{new Variable("a"), new Number(0), new Number(2)})),
                            new Return(new ArrayAccess(new Variable("a"), new Number(index)))
                    });
            Function mergeSort = new Function(Type.Int,"mergeSort",new Parameter[]{new Parameter(Type.IntArray,"arr"),new Parameter(Type.Int,"low"),new Parameter(Type.Int,"high")},
                  new Declaration[]{new Declaration("mid")},new Statement[]{
                          new Assignment("mid",new Binary(new Binary(new Variable("low"),Binop.Plus,new Variable("high")),Binop.DivisionOperator,new Number(2)) ),
                          new IfThen(new Comparison(new Variable("high"),Comp.LessEqual,new Variable("low")),
                                  new Return(new Number(0))),
                    new ExpressionStatement(new Call("mergeSort",new Expression[]{new Variable("arr"),new Variable("low"),new Variable("mid")})),
                    new ExpressionStatement(new Call("merge",new Expression[]{new Variable("arr"),new Variable("low"),new Variable("mid")})),
                    new ExpressionStatement(new Call("mergeSort",new Expression[]{new Variable("arr"),new Binary(new Variable("mid"),Binop.Plus,new Number(1)),new Variable("high")})),
                    new ExpressionStatement(new Call("merge",new Expression[]{new Variable("arr"),new Binary(new Variable("mid"),Binop.Plus,new Number(1)),new Variable("high")})),
                    new ExpressionStatement(new Call("merge",new Expression[]{new Variable("arr"),new Variable("low"),new Variable("high")}))
            }  );
            Function merge = new Function(Type.Int,"merge",new Parameter[]{new Parameter(Type.IntArray,"arr"),new Parameter(Type.Int,"low"),new Parameter(Type.Int,"high")},
                    new Declaration[]{
                            new Declaration(new String[]{"mid","i","j","k","size"}),
                            new Declaration(Type.IntArray,"helperArr")
                    },
                    new Statement[]{
                            new Assignment("mid",new Binary(new  Binary(new Variable("low"),Binop.Plus,new Variable("high")),Binop.DivisionOperator,new Number(2))),
                            new Assignment("i",new Variable("low")),
                            new Assignment("j",new Binary(new Variable("mid"),Binop.Plus,new Number(1))),
                            new Assignment("k",new Number(0)),
                            new Assignment("size",new Binary(new Binary(new Variable("high"),Binop.Minus,new Variable("low")),Binop.Plus,new Number(1))),
                            new Assignment("helperArr",new ArrayAllocator(new Variable("size"))),
                            new While(new BinaryCondition(new Comparison(new Variable("i"),Comp.LessEqual,new Variable("mid")),Bbinop.And,new Comparison(new Variable("j"),Comp.LessEqual,new Variable("high"))),
                                    new IfThenElse(new Comparison(new ArrayAccess(new Variable("arr"),new Variable("i")),Comp.Less,new ArrayAccess(new Variable("arr"),new Variable("j"))),
                                            new Composite(new Statement[]{
                                                    new ArrayIndexAssignment(new Variable("helperArr"),new Variable("k"),new ArrayAccess(new Variable("arr"),new Variable("i"))),
                                                    new Assignment("k",new Binary(new Variable("k"),Binop.Plus,new Number(1))),
                                                    new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))
                                            })

                                            ,
                                            new Composite(new Statement[]{
                                                    new ArrayIndexAssignment(new Variable("helperArr"),new Variable("k"),new ArrayAccess(new Variable("arr"),new Variable("j"))),
                                                    new Assignment("k",new Binary(new Variable("k"),Binop.Plus,new Number(1))),
                                                    new Assignment("j",new Binary(new Variable("j"),Binop.Plus,new Number(1)))
                                            })),false),
                            new While(new Comparison(new Variable("i"),Comp.LessEqual,new Variable("mid")),
                                //    helperArr[k++] = arr[i++];
                                   new Composite(new Statement[]{
                                           new ArrayIndexAssignment(new Variable("helperArr"),new Variable("k"),new ArrayAccess(new Variable("arr"),new Variable("i"))),
                                           new Assignment("k",new Binary(new Variable("k"),Binop.Plus,new Number(1))),
                                           new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))
                                   })
                                    ,false),
                            new While(new Comparison(new Variable("j"),Comp.LessEqual,new Variable("high")),
                                    //    helperArr[k++] = arr[j++];
                                    new Composite(new Statement[]{
                                            new ArrayIndexAssignment(new Variable("helperArr"),new Variable("k"),new ArrayAccess(new Variable("arr"),new Variable("j"))),
                                            new Assignment("k",new Binary(new Variable("k"),Binop.Plus,new Number(1))),
                                            new Assignment("j",new Binary(new Variable("j"),Binop.Plus,new Number(1)))
                                    })
                                    ,false),
                            new Assignment("i",new Number(0)),
                            /*
                            for (i = 0; i < SIZE; i++) {
                             arr[low + i] = helperArr[i];
                                           }
                             */
/*
                            new While(new Comparison(new Variable("i"),Comp.Less,new Variable("size")),new Composite(new Statement[]{
                                    new ArrayIndexAssignment(new Variable("arr"),new Binary(new Variable("low"),Binop.Plus,new Variable("i")),
                                            new ArrayAccess(new Variable("helperArr"),new Variable("i"))),
                                    new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))
                            }),false),
                            new Return(new Number(0))


                    } );
        Program p = new Program(new Function[]{main,mergeSort,merge});
        return p;};
        
            


        int [] resultArray =new int[5];
        for(int i=0;i<resultArray.length;i++)
        {
            Program p = ArrayAccess.apply(i);
            CodeGenerationVisitor cgv = new CodeGenerationVisitor();
            p.accept(cgv);
            for(Instruction in : cgv.getProgram())
                System.out.println(in.toString());
            System.out.println(new Interpreter(cgv.getProgram()).execute());
        }
*/



    }

    

}
