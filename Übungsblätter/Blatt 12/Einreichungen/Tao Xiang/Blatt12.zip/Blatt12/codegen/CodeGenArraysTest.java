package codegen;
import asm.Interpreter;
import org.junit.*;
import org.junit.Test;

import java.util.function.*;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class CodeGenArraysTest {
    public void testProgram(Program program, int expectedRetVal) {
        CodeGenerationVisitor cgv = new CodeGenerationVisitor();
        program.accept(cgv);
        int retVal = new Interpreter(cgv.getProgram()).execute();
        assertEquals(expectedRetVal, retVal);
    }

  /*  @Test
    public void testSimple() {
        Program p = new Program(new Function[] { new Function("main", new String[] {}, new Declaration[] {}, new Statement[] {
                new Return(new Binary(new Binary(new Number(5), Binop.Minus, new Number(3)), Binop.MultiplicationOperator,
                        new Unary(Unop.Minus, new Binary(new Number(3), Binop.Plus, new Number(18)))))     })});

        testProgram(p, -42);
    }
    */
@org.junit.Test
public  void testGivenExample(){
    java.util.function.Function<Integer,Program> getProgrammByN = (n)->{
            Function init = new Function(Type.IntArray, "init",
            new Parameter[] { new Parameter(Type.Int, "size")},
            new Declaration[] { new Declaration("i"), new Declaration(Type.IntArray, "array")},
            new Statement[] {
                    new Assignment("i", new Number(0)),
                    new Assignment("array", new ArrayAllocator(new Variable("size"))),
                    new While(new Comparison(new Variable("i"), Comp.Less, new Variable("size")), new Composite(new Statement[] {
                            new ArrayIndexAssignment(new Variable("array"), new Variable("i"), new Variable("i")),
                            new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                    }), false),
                    new Return(new Variable("array"))
            });

        Function sum = new Function(Type.Int, "sum",
                new Parameter[] { new Parameter(Type.IntArray, "array") },
                new Declaration[] { new Declaration("i"), new Declaration("sum") },
                new Statement[] {
                        new Assignment("i", new Number(0)),
                        new Assignment("sum", new Number(0)),
                        new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("array"))), new Composite(new Statement[] {
                                new Assignment("sum", new Binary(new Variable("sum"), Binop.Plus, new ArrayAccess(new Variable("array"),
                                        new Variable("i")))),
                                new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                        }), false),
                        new Return(new Variable("sum"))
                });

        Function main = new Function("main",
                new String[] {},
                new Declaration[] { new Declaration(Type.IntArray, "a") },
                new Statement[] {
                        new Assignment("a", new Call("init",
                                new Expression[] { new Number(n) })),
                        new Return(new Call("sum", new Expression[] { new Variable("a") }))
                });

        Program p = new Program(new Function[] { main,init, sum  });
        return p ;};
    testProgram(getProgrammByN.apply(5),10);
    testProgram(getProgrammByN.apply(10),45);
    testProgram(getProgrammByN.apply(1001),500500);
}






    @org.junit.Test(expected = InvalidArraySizeDeclarationExpection.class)
    public void shroudThrow1 (){
        java.util.function.Function<Integer,Program> getProgrammByN = (n)->{
            Function init = new Function(Type.IntArray, "init",
                    new Parameter[] { new Parameter(Type.Int, "size")},
                    new Declaration[] { new Declaration("i"), new Declaration(Type.IntArray, "array")},
                    new Statement[] {
                            new Assignment("i", new Number(0)),
                            new Assignment("array", new ArrayAllocator(new Variable("size"))),
                            new While(new Comparison(new Variable("i"), Comp.Less, new Variable("size")), new Composite(new Statement[] {
                                    new ArrayIndexAssignment(new Variable("array"), new Variable("i"), new Variable("i")),
                                    new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                            }), false),
                            new Return(new Variable("array"))
                    });

            Function sum = new Function(Type.Int, "sum",
                    new Parameter[] { new Parameter(Type.IntArray, "array") },
                    new Declaration[] { new Declaration("i"), new Declaration("sum") },
                    new Statement[] {
                            new Assignment("i", new Number(0)),
                            new Assignment("sum", new Number(0)),
                            new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("array"))), new Composite(new Statement[] {
                                    new Assignment("sum", new Binary(new Variable("sum"), Binop.Plus, new ArrayAccess(new Variable("array"),
                                            new Variable("i")))),
                                    new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                            }), false),
                            new Return(new Variable("sum"))
                    });

            Function main = new Function("main",
                    new String[] {},
                    new Declaration[] { new Declaration(Type.IntArray, "a") },
                    new Statement[] {
                            new Assignment("a", new Call("init",
                                    new Expression[] { new Number(n) })),
                            new Return(new Call("sum", new Expression[] { new Variable("a") }))
                    });

            Program p = new Program(new Function[] { main,init, sum  });
            return p ;};
        testProgram(getProgrammByN.apply(-1),-1);
        testProgram(getProgrammByN.apply(1025),-1);
    }
    @Test
    public void testZeroLengthArray(){
        java.util.function.Function<Integer,Program> getProgrammByN = (n)->{
            Function init = new Function(Type.IntArray, "init",
                    new Parameter[] { new Parameter(Type.Int, "size")},
                    new Declaration[] { new Declaration("i"), new Declaration(Type.IntArray, "array")},
                    new Statement[] {
                            new Assignment("i", new Number(0)),
                            new Assignment("array", new ArrayAllocator(new Variable("size"))),
                            new While(new Comparison(new Variable("i"), Comp.Less, new Variable("size")), new Composite(new Statement[] {
                                    new ArrayIndexAssignment(new Variable("array"), new Variable("i"), new Variable("i")),
                                    new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                            }), false),
                            new Return(new Variable("array"))
                    });

            Function sum = new Function(Type.Int, "sum",
                    new Parameter[] { new Parameter(Type.IntArray, "array") },
                    new Declaration[] { new Declaration("i"), new Declaration("sum") },
                    new Statement[] {
                            new Assignment("i", new Number(0)),
                            new Assignment("sum", new Number(0)),
                            new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("array"))), new Composite(new Statement[] {
                                    new Assignment("sum", new Binary(new Variable("sum"), Binop.Plus, new ArrayAccess(new Variable("array"),
                                            new Variable("i")))),
                                    new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))
                            }), false),
                            new Return(new Variable("sum"))
                    });

            Function main = new Function("main",
                    new String[] {},
                    new Declaration[] { new Declaration(Type.IntArray, "a") },
                    new Statement[] {
                            new Assignment("a", new Call("init",
                                    new Expression[] { new Number(n) })),
                            new Return(new Call("sum", new Expression[] { new Variable("a") }))
                    });

            Program p = new Program(new Function[] { main,init, sum  });
            return p ;};
        testProgram(getProgrammByN.apply(0),0);
    }
    @Test
    public void testMehrereArrays(){

        Function main = new Function(Type.Int,"main",new Parameter[]{},
                new Declaration[]{
                        new Declaration(Type.IntArray,"a","b","c"),
                        new Declaration("i","j","k")
                },
                //...
                new Statement[]{
                        new Assignment("a",new ArrayAllocator(new Number(50))),
                        new Assignment("b",new ArrayAllocator(new Number(50))),
                        new Assignment("c",new ArrayAllocator(new Number(50))),
                        new Assignment("i",new Number(0)),
                        new While(new Comparison(new Variable("i"),Comp.Less,new ArrayLength(new Variable("a"))),
                                new Composite(new Statement[]{new ArrayIndexAssignment(new Variable("a"),new Variable("i"),new Variable("i")),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))}),false),
                        new Assignment("j",new Number(0)),
                        new While(new Comparison(new Variable("j"),Comp.Less,new ArrayLength(new Variable("b"))),
                                new Composite(new Statement[]{new ArrayIndexAssignment(new Variable("b"),new Variable("j"),new Variable("i")),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1))),new Assignment("j",new Binary(new Variable("j"),Binop.Plus,new Number(1)))}),false),
                        new Assignment("k",new Number(0)),
                        new While(new Comparison(new Variable("k"),Comp.Less,new ArrayLength(new Variable("c"))),new Composite(new Statement[]{new ArrayIndexAssignment(new Variable("c"),
                                new Variable("k"),new Binary(new ArrayAccess(new Variable("a"),new Variable("k")),Binop.Plus,new Binary(new Number(5),Binop.MultiplicationOperator,
                                new ArrayAccess(new Variable("b"),new Variable("k"))))),new Assignment("k",new Binary(new Variable("k"),Binop.Plus,new Number(1)))}),false),
                        new Return(new ArrayAccess(new Variable("c"),new Binary(new ArrayLength(new Variable("c")),Binop.Minus,new Number(1))))
                });
        Program p = new Program(new Function[]{main});
        testProgram(p,544);
    }

    /*
     int  main ()
    {
    int [] a ;
    a= new int[1];
    a=rec(a);
    return a.length;
    }
     int[] rec (int [] a )
    {
        int [] ret;
        if(a.length>=5) ret = a;
        if(a.length<5)
        {
            ret= new int[a.length+1];
           ret= rec(ret);
        }
        return  ret;

    }*/
    @Test
    public void testRec(){
            Function main = new Function(Type.Int, "main", new Parameter[] { }, new Declaration[] {
                    new Declaration(Type.IntArray, new String[] { "a" } ) }, new Statement[] { new
                    Assignment("a", new ArrayAllocator(new Number(1))), new Assignment("a", new Call("rec",
                    new Expression[] { new Variable("a") } )), new Return(new ArrayLength(new Variable("a")))
            });

            Function rec = new Function(Type.IntArray, "rec", new Parameter[] { new
                    Parameter(Type.IntArray, "a") }, new Declaration[] { new Declaration(Type.IntArray, new
                    String[] { "ret" } ) }, new Statement[] { new IfThen(new Comparison(new ArrayLength(new
                    Variable("a")), Comp.GreaterEqual, new Number(5)), new Assignment("ret", new
                    Variable("a"))), new IfThen(new Comparison(new ArrayLength(new Variable("a")), Comp.Less,
                    new Number(5)), new Composite( new Statement[] { new Assignment("ret", new
                    ArrayAllocator(new Binary(new ArrayLength(new Variable("a")), Binop.Plus, new
                    Number(1)))), new Assignment("ret", new Call("rec", new Expression[] { new
                    Variable("ret") } )) } )), new Return(new Variable("ret")) });


            Program program = new Program( new Function[] { main, rec } );
            testProgram(program,5);
    }

    /*
    int main ()
    {
        int[] arr;
        arr = new int[4];
        arr[0]=4;
        arr[1]=3;
        arr[2]=2;
        arr[3]=1;
        bubbleSort(arr);
        return arr[index];
    }
     int bubbleSort(int [] arr)
    {
        int i,j,tmp;
        i=arr.length-1;

        while (i>0)
        {
            j=0;
            while (j<i)
            {
                if(arr[j]>arr[j+1])
                {
                    tmp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=tmp;
                }
                j++;
            }
            i--;
        }
        return 0;
    }
     */
    @Test
    public void testBubbleSort()
    {
        java.util.function.Function<Integer,Program> arrayAccess = (index)->{
        Function main = new Function(Type.Int ,"main",new Parameter[]{},new Declaration[]{new Declaration(Type.IntArray,"arr")},new Statement[]{
                new Assignment("arr",new ArrayAllocator(new Number(4))),
                new ArrayIndexAssignment(new Variable("arr"),new Number(0),new Number(4)),
                new ArrayIndexAssignment(new Variable("arr"),new Number(1),new Number(3)),
                new ArrayIndexAssignment(new Variable("arr"),new Number(2),new Number(2)),
                new ArrayIndexAssignment(new Variable("arr"),new Number(3),new Number(1)),
                new ExpressionStatement(new Call("bubbleSort",new Expression[]{new Variable("arr")})),
                new Return(new ArrayAccess(new Variable("arr"),new Number(index)))
        });
        Function bubbleSort = new Function(Type.Int,"bubbleSort",new Parameter[]{new Parameter(Type.IntArray,"arr")},
                new Declaration[]{new Declaration(Type.Int,"i","j","tmp")},new Statement[]{
                        new Assignment("i",new Binary(new ArrayLength(new Variable("arr")),Binop.Minus,new Number(1))),
                new While(new Comparison(new Variable("i"),Comp.Greater,new Number(0)),new Composite(new Statement[]{
                        new Assignment("j",new Number(0)),
                        new While(new Comparison(new Variable("j"),Comp.Less,new Variable("i")),new Composite(new Statement[]{
                                new IfThen(new Comparison(new ArrayAccess(new Variable("arr"),new Variable("j")),Comp.Greater,new ArrayAccess(new Variable("arr"),new Binary(new Variable("j"),Binop.Plus,new Number(1)))),
                                       new Composite(new Statement[]{
                                               new Assignment("tmp",new ArrayAccess(new Variable("arr"),new Variable("j"))),
                                               new ArrayIndexAssignment(new Variable("arr"),new Variable("j"),new ArrayAccess(new Variable("arr"),new Binary(new Variable("j"),Binop.Plus,new Number(1)))),
                                               new ArrayIndexAssignment(new Variable("arr"),new Binary(new Variable("j"),Binop.Plus,new Number(1)),new Variable("tmp"))
                                       }) ),
                                new Assignment("j",new Binary(new Variable("j"),Binop.Plus,new Number(1)))
                        }),false),
                        new Assignment("i",new Binary(new Variable("i"),Binop.Minus,new Number(1)))
                }),false),
                new Return(new Number(0))
        });
        return new Program(new Function[]{main,bubbleSort});
    };
        int [] expectedArray= {1,2,3,4};
        int [] actualArray=new int[4];
        for(int i=0;i<actualArray.length;i++)
        {
            Program p = arrayAccess.apply(i);
            CodeGenerationVisitor cgv = new CodeGenerationVisitor();
            p.accept(cgv);
            actualArray[i]= new Interpreter(cgv.getProgram()).execute();
        }
        assertArrayEquals(expectedArray,actualArray);
    }
}
