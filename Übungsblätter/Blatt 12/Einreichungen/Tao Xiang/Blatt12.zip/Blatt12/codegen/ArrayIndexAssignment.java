package codegen;

public class ArrayIndexAssignment extends  Statement{
    private Expression Array,Index,assignedExpression;
    ArrayIndexAssignment(Expression Array,Expression Index,Expression assignedExpression)
    {
        this.Array=Array;
        this.assignedExpression=assignedExpression;
        this.Index=Index;
    }

    public Expression getAssignedExpression() {
        return assignedExpression;
    }

    public  Expression getArray(){
        return Array;}

    public Expression getIndex() {
        return Index;
    }
    @Override
    public void accept(ProgramVisitor visitor) {
       visitor.visit(this);
    }
}
