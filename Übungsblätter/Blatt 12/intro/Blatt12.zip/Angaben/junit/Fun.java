public interface Fun<T, R> {
    public R apply(T x);
}
