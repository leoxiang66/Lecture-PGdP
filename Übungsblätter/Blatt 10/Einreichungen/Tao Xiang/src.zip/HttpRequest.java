import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public class HttpRequest {
	private HttpMethod method;
	private String path;
	private Map<String,String> parameters;

	public HttpMethod getMethod() {
		return this.method;
	}
	public String getPath() {
		return this.path;
	}
	public Map<String,String> getParameters(){
		return this.parameters;
	}
	
	public HttpRequest(String request) 
	{
		boolean hasParameter=false;
		int HTTPindex=request.indexOf("HTTP");
		if(HTTPindex==-1) throw new InvalidRequestException();
		String methode=request.substring(0, 3);
		if(methode.equals("GET")) this.method=HttpMethod.GET;
		else if(methode.equals("POST")) this.method=HttpMethod.POST;
		else throw new InvalidRequestException();
	    int index =request.indexOf('/');
	    if(index==-1) throw new InvalidRequestException();
	    if(request.indexOf('?')!=-1)
	    {
	    	hasParameter=true;
	    	int fragezeichenIndex= request.indexOf('?');
	    	path=request.substring(index, fragezeichenIndex);
	    }
	    else 
	    {
	    	
	    	path=request.substring(index, HTTPindex-1);
	    }
	    if(hasParameter )
	    {
	    	this.parameters=new HashMap<String,String>();
	    	int fragezeichenIndex= request.indexOf('?');
	    /*	int numberofPara=
	    	request.chars().filter(i->i=='&').toArray().length+1;
	    
	    	
	    	
	    	int start=0,end = 0;// end = index of '&' or' ';
	    	for(int i=1;i<=numberofPara ;i++)
	    {
	    	String para,wert;
	    	if(i==1) 
	    	{
	    	
	    	start=fragezeichenIndex+1;
	    	}
	    	else
	    	{
	    		start=end+1;
	    	}
	    	int equalsIndex=request.indexOf('=',start);
	    	if(equalsIndex==-1) throw new InvadidRequestException();
	    	para=request.substring(start, equalsIndex);
	    	
	    	
	    	if(numberofPara ==i)
	    	{
	    	end=request.indexOf(' ', start);
	    	}
	    	else end=request.indexOf('&', start	);
	    	
	    
	    	wert=request.substring(equalsIndex+1,end);
	    	this.parameters.put(para, wert);
	    	
	    	
	    }*/
	    	String paraTeil=request.substring(fragezeichenIndex+1, HTTPindex-1);
	    	String[]einzelnpara=paraTeil.split("&");
	    	Stream<String> paras=Arrays.stream(einzelnpara);
	    	Set<String> querys= new HashSet<String>();
	    	paras.forEach(i->{
	    		int index2=i.indexOf('=');
	    		if(index2==-1) throw new InvalidRequestException();
	    		
	    		{if(!querys.add(i.substring(0, index2)))
	    		  {
	    			//System.out.println("hi");
	    			throw new InvalidRequestException();
	    		  }
	    		this.parameters.put(i.substring(0, index2), i.substring(index2+1));
	    		}
	    		
	    		 
	    	});
	    	/*System.out.println(querys.size());
	    	paras.forEach(i->{
	    		//System.out.println(i);
	    		int index2=i.indexOf('=');
	    		if(index2==-1) throw new InvalidRequestException();
	    		if(!parameters.containsKey(i)) 
	    			{
	    			  this.parameters.put(i.substring(0, index2), i.substring(index2+1));
	    			  System.out.println("true");
	    			}
	    			
	    		else	throw new InvalidRequestException();
	    		//parameters.keySet().forEach(k->System.out.println(k));
	    	});*/
	    	
	 }
	    

		
	}
	

}
