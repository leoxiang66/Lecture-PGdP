/*import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.stream.IntStream;
import java.util.stream.Stream;*/

//import suchmaschine.LinkedDocument;
//import suchmaschine.LinkedDocumentCollection;

public class Test {

	public static void main(String[] args)  {
	/*	// TODO Auto-generated method stub
		TemplateProcessor  test=new TemplateProcessor("template.html");
		String request="GET /search?query=einfach HTTP/1.1";
		HttpRequest HTTPrequest= new HttpRequest(request);
		//System.out.println(HTTPrequest.path);
		//System.out.println(HTTPrequest .parameters.get("query"));// suc
		//System.out.println(test.replace(HTTPrequest .parameters));// suc
		/*String html="<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<title> PGdP Search Enigne</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<center>\r\n" + 
				"<h2>PGdP Search Engine</h2>\r\n" + 
				"<form action=\"/search\">\r\n" + 
				"<input type=\"text\" name =\"query\" value=\"\">\r\n" + 
				"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
				"</form>\r\n" + 
				"</center>\r\n" + 
				"<br><br>\r\n" + 
				"<center>\r\n" + 
				"<table border=\"1px solid black\">\r\n" + 
				"</table>\r\n" + 
				"</center>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		System.out.println(html);
		int[] havefun1=new int[5];
		IntStream havefun= Arrays.stream(havefun1);
		Stack<Integer> havefun2=new Stack<Integer>();
		havefun2.push(0);
		havefun.forEach(i->havefun2.push(havefun2.peek()+1));
		
		havefun2.stream().forEach(i->System.out.println(i));
		String query ="txt";
		double pageRankDampingFactor=0.85;
		double weightingFactor=0.6;
		LinkedDocumentCollection ldc;
		LinkedDocumentCollection tmp= new LinkedDocumentCollection();
		tmp.appendDocument(new LinkedDocument("a.txt", "", "", null, null, "link:b.txt", "a.txt"));
		ldc=tmp.crawl();
		ldc.match(query, pageRankDampingFactor, weightingFactor);
		
		int[] havefun1=new int[ldc.numDocuments()-1];
		IntStream havefun= Arrays.stream(havefun1);
		Stack<Integer> havefun2=new Stack<Integer>();
		havefun2.push(0);
		havefun.forEach(i->havefun2.push(havefun2.peek()+1));
		
		Stack<String> ret =new Stack<String>();
		ret.push("");
		 double[] relevance = ldc.match(query, pageRankDampingFactor, weightingFactor);
		havefun2.stream().forEach(i->
		{
			ret.push(ret.pop()+"<tr><td>"+(i+1)+"</td><td><a herf=\""+ldc.get(i).getTitle()+"\">"+ldc.get(i).getTitle()+"</a></td><td>"+relevance[i]
					+"</td></tr>\r\n");
		});
		System.out.println(ret.peek());*/
		/*ServerSocket webserver= new ServerSocket(8000);

	    Socket client= webserver.accept();
		BufferedReader in= new BufferedReader(new InputStreamReader(client.getInputStream()));
		PrintWriter out =new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
		out.println("\r\n" + 
				"<!template.txt>\r\n" + 
				"<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<title> PGdP Search Enigne</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<center>\r\n" + 
				"<h2>PGdP Search Engine</h2>\r\n" + 
				"<form action=\"%path\">\r\n" + 
				"<input type=\"text\" name =\"query\" value=\"%query\">\r\n" + 
				"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
				"</form>\r\n" + 
				"</center>\r\n" + 
				"<br><br>\r\n" + 
				"<center>\r\n" + 
				"<table border=\"1px solid black\">\r\n" + 
				"<tr><td><b>ID</b></td> <td><b>Page</b><td> <td><b>Revelance</b></td></tr>\r\n" + 
				"%tabelle\r\n" + 
				"</table>\r\n" + 
				"</center>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		out.flush();*/
		//System.out.println(args[0]);
		

		int startYear= -4;
		int i=(startYear >=0? startYear :0);
		System.out.println(i);
	}

}
