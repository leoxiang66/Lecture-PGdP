package NochMehrStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class IteratorTemperatures extends Temperatures  {

	public IteratorTemperatures(File csv) throws FileNotFoundException {
		super(csv);
		// TODO Auto-generated constructor stub
	}
	 public IteratorTemperatures(java.net.URL url) throws UnknownHostException, IOException {
		// TODO Auto-generated constructor stub
		super(url);
	}
	 public IteratorTemperatures(Stack<Temperature> temperatures) {
		 super(temperatures);
	 }

	@Override
	public long size() {
		// TODO Auto-generated method stub
		long num = 0;
		for(Temperature tmp : this.temperatures)
		{
		num++;	
		}
		return num;
	}

	@Override
	public List<Date> dates() {
		// TODO Auto-generated method stub
		List<Date>  ret = new ArrayList<Date>();
		
		for(Temperature tmp: temperatures )
		{
			if(!ret.contains(tmp.getDate()))
				ret.add(tmp.getDate());
		}
		
		return ret;
	}

	@Override
	public Set<String> cities() {
		// TODO Auto-generated method stub
		Set<String> ret= new HashSet<String>();
		for(Temperature tmp: temperatures )
		{
			ret.add(tmp.getCity());
		}
		return ret;
	}

	@Override
	public Set<String> countries() {
		// TODO Auto-generated method stub
		Set<String> ret= new HashSet<String>();
		for(Temperature tmp: temperatures )
		{
			ret.add(tmp.getCountry());
		}
		return ret;
	}

	@Override
	public Map<String, Temperatures> temperaturesByCountry() {
		// TODO Auto-generated method stub
		Map<String,Temperatures >ret= new HashMap<String,Temperatures>();
		for(String country: this.countries())
		{
			Stack<Temperature> tmp= new Stack<Temperature >();
			for(Temperature temp: temperatures )
			{
				if(temp.getCountry().equals(country))
					tmp.push(temp);
			}
			
			ret.put(country, new IteratorTemperatures(tmp));
		}
		return ret;
	}

	@Override
	public String coldestCountryAbs() {
		// TODO Auto-generated method stub
		double coldestTemp=0;
		String ret="";
		for(Temperature tmp: temperatures )
		{
		if(coldestTemp>tmp.getAverageTemperature())
			coldestTemp =tmp.getAverageTemperature();
		}
		
		for(Temperature tmp: temperatures )
		{
			if(coldestTemp ==tmp.getAverageTemperature())
				{
				ret= tmp.getCountry();
				break;
				}
		}
		//System.out.println(coldestTemp);
		return ret;
	}

	@Override
	public String hottestCountryAbs() {
		// TODO Auto-generated method stub
		double hottestTemp=0;
		String ret="";
		for(Temperature tmp: temperatures )
		{
		if(hottestTemp<tmp.getAverageTemperature())
			hottestTemp =tmp.getAverageTemperature();
		}
		
		for(Temperature tmp: temperatures )
		{
			if(hottestTemp ==tmp.getAverageTemperature())
				{
				ret= tmp.getCountry();
				break;
				}
		}
		//System.out.println(hottestTemp);
		return ret;
	}

	@Override
	public String coldestCountryAvg() {
		// TODO Auto-generated method stub
		String ret="";
		double coldestTempAvg=2000;
		HashMap <String,Double>country2TempAvg=new HashMap<String,Double>();
		for(String country: this.countries())
		{
			double TempAvg=0,TempSum=0;
			for(Temperature temp: this.temperaturesByCountry().get(country).temperatures)
			{
				TempSum+=temp.getAverageTemperature();
			}
			TempAvg=TempSum/(double)temperaturesByCountry().get(country).size();
			if(coldestTempAvg>TempAvg) coldestTempAvg=TempAvg;
			country2TempAvg.put(country, TempAvg);
		}
		for(String country : this.countries())
		{
			if(country2TempAvg.get(country).equals(coldestTempAvg))
			{	ret=country;
			break;}
		}
		//System.out.println(coldestTempAvg);
		return ret;
	}

	@Override
	public String hottestCountryAvg() {
		// TODO Auto-generated method stub
		String ret="";
		double hottestTempAvg=-2000;
		HashMap <String,Double>country2TempAvg=new HashMap<String,Double>();
		for(String country: this.countries())
		{
			double TempAvg=0,TempSum=0;
			for(Temperature temp: this.temperaturesByCountry().get(country).temperatures)
			{
				TempSum+=temp.getAverageTemperature();
			}
			TempAvg=TempSum/(double)temperaturesByCountry().get(country).size();
			if(hottestTempAvg<TempAvg) hottestTempAvg=TempAvg;
			country2TempAvg.put(country, TempAvg);
		}
		for(String country : this.countries())
		{
			if(country2TempAvg.get(country).equals(hottestTempAvg))
			{	ret=country;
			break;
			}
		}
		//System.out.println(hottestTempAvg);
		return ret;
	}

	@Override
	public Map<String, Double> countriesAvgTemperature() {
		// TODO Auto-generated method stub
		HashMap <String,Double>country2TempAvg=new HashMap<String,Double>();
		for(String country: this.countries())
		{
			double TempAvg=0,TempSum=0;
			for(Temperature temp: this.temperaturesByCountry().get(country).temperatures)
			{
				TempSum+=temp.getAverageTemperature();
			}
			TempAvg=TempSum/(double)temperaturesByCountry().get(country).size();
			country2TempAvg.put(country, TempAvg);
		}
		return country2TempAvg;
	}
	public static void main(String[] args) throws Exception {

		IteratorTemperatures temps=null;
		try {
		URL url = new URL(args[0]);
		temps= new IteratorTemperatures(url);
		
		temps.printSummary();
		
		}
		catch(Exception e)
		{
			try {
				//System.out.println("hi");
			temps=new IteratorTemperatures(new File(args[0]));
			temps.printSummary();
			}
			catch(Exception i)
			{
				i.printStackTrace();
			}
		}
		
	}

}
