package NochMehrStream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public abstract  class Temperatures implements Iterable<Temperature> {

	static DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd");
	// attribute?
	protected Stack<Temperature> temperatures;
	
	public Temperatures (Stack<Temperature > temperatures)
	{
		if(temperatures!=null)
		this.temperatures=temperatures;
		else throw new NullPointerException();
	}
	public void printSummary()
	{
		System.out.println("1.the size of this Temperatures :"+this.size()+"\n");
		System.out.print("2.the countries involved in this Temperatures: ");
		 Object[]hi2=  this.countries().toArray();
		 for(int i=0;i<hi2.length;i++)
		 {
			 if(i%3==0&&i!=hi2.length-1)
			 {
				 System.out.println();
				 System.out.print("    >  "+hi2[i]+" ,");
				 
			 }
			 else if(i==hi2.length-1) System.out.println(hi2[i]);
			 else System.out.print(hi2[i]+", ");
			 
		 }
		System.out.println("\n");
		System.out.print("3.the cities involved in this Temperatures: ");
		 Object[]hi=  this.cities().toArray();
		 for(int i=0;i<hi.length;i++)
		 {
			 if(i%3==0&&i!=hi.length-1)
			 {
				 System.out.println();
				 System.out.print("    >  "+hi[i]+" ,");
				 
			 }
			 else if(i==hi.length-1) System.out.println(hi[i]);
			 else System.out.print(hi[i]+", ");
			 
		 }
		System.out.println("\n");
		System.out.println("4.the country that has the absolute-lowest temperature: "+this.coldestCountryAbs()+"\n");
		System.out.println("5.the country that has the absolute-highest temperature: "+this.hottestCountryAbs()+"\n");
		System.out.println("6.the country,whose average of temperatures the lowest is :"+this.coldestCountryAvg()+"\n");
		System.out.println("7.the countey,whose average of temperatures the highest is :"+this.hottestCountryAvg()+"\n");
	}
	
	public Temperatures (File csv) throws FileNotFoundException
	{
		
		temperatures =new Stack<Temperature>();
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(csv)));
		in.lines().filter(i->!i.equals("")).skip(1).forEach(i->
		{
			String[] tmp=i.split(",");
			Date date = null;
			double averageTemperature = 0,averageTemperatureUncertainty = 0,latitude = 0,longitude = 0;
			String city = "",country="";
			try {
			for(int j=0;j<tmp.length;j++)
			{
				
				if(j==0) date=dateFormat.parse(tmp[j]);
				if(j==1)  averageTemperature=Double.parseDouble(tmp[j]);
				if(j==2) averageTemperatureUncertainty= Double.parseDouble(tmp[j]);
				if(j==3) city= tmp[j];
				if(j==4) country =tmp[j];
				if(j==5) latitude=Double.parseDouble(tmp[j].substring(0, tmp[j].length()-1));
				if(j==6) longitude =Double.parseDouble(tmp[j].substring(0, tmp[j].length()-1));	
			}
			Temperature temperature= new Temperature(date, averageTemperature, averageTemperatureUncertainty, city, country, latitude, longitude);
			temperatures.push(temperature);
			}
			catch(Exception e)
			{
				//Temperature Null = null;
				//temperatures.push(Null);
			}
			
			
			//System.out.println(date.toGMTString());
			
		});
		
	}
	
	public Temperatures (java.net.URL url) throws UnknownHostException, IOException 
	{
		boolean connectionFailed = false;
		this.temperatures =new Stack<Temperature>();
		Socket socket;
		BufferedReader in;
		PrintWriter out;
		String requestLine="",hostLine="",path,host ="";
		try
		{
			 path=url.getPath();
		     host=url.getHost();
			 requestLine="GET "+path+" HTTP/1.1";
			 hostLine = "host: "+host;
			
		}
		catch(Exception e)
		{
		this.temperatures.clear();	
		connectionFailed =true;
		}
		
		if(!connectionFailed ) 
		{
			socket =new Socket(host,80);
			 in =new BufferedReader(new InputStreamReader(socket .getInputStream()));
		     out =new PrintWriter(new OutputStreamWriter(socket .getOutputStream()));
			
			out.print(requestLine +"\r\n"+hostLine+"\r\n\r\n");
			out.flush();
			
			in.lines().filter(i->!i.equals("")).skip(1).forEach(i->
			{
				String[] tmp=i.split(",");
				Date date = null;
				double averageTemperature = 0,averageTemperatureUncertainty = 0,latitude = 0,longitude = 0;
				String city = "",country="";
				try {
				for(int j=0;j<tmp.length;j++)
				{
					
					if(j==0) date=dateFormat.parse(tmp[j]);
					if(j==1)  averageTemperature=Double.parseDouble(tmp[j]);
					if(j==2) averageTemperatureUncertainty= Double.parseDouble(tmp[j]);
					if(j==3) city= tmp[j];
					if(j==4) country =tmp[j];
					if(j==5) latitude=Double.parseDouble(tmp[j].substring(0, tmp[j].length()-1));
					if(j==6) longitude =Double.parseDouble(tmp[j].substring(0, tmp[j].length()-1));	
				}
				Temperature temperature= new Temperature(date, averageTemperature, averageTemperatureUncertainty, city, country, latitude, longitude);
				temperatures.push(temperature);
				}
				catch(Exception e)
				{
					//Temperature Null = null;
					//temperatures.push(Null);
				}
				
				
				//System.out.println(date.toGMTString());
				
			});
		}
		
			
		
		
	}
	
	
	public abstract long size();
	public abstract List<Date> dates() ;
	public abstract Set<String> cities() ;
	public abstract Set<String> countries();
	public abstract Map<String,Temperatures> temperaturesByCountry();
	public abstract String coldestCountryAbs();
	public abstract String  hottestCountryAbs();
	public abstract String coldestCountryAvg();
	public abstract String hottestCountryAvg();
	public abstract Map<String,Double > countriesAvgTemperature();

@Override
public Iterator<Temperature> iterator() {
	// TODO Auto-generated method stub
	return null;
}}
