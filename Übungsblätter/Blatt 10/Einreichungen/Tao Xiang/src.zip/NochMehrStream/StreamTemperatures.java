package NochMehrStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class StreamTemperatures extends Temperatures{

	public StreamTemperatures(File csv) throws FileNotFoundException {
		super(csv);
		// TODO Auto-generated constructor stub
	}
	public StreamTemperatures(Stack<Temperature> temperatures)
	{
		super(temperatures);
	}
	 public StreamTemperatures(URL url) throws UnknownHostException, IOException {
		// TODO Auto-generated constructor stub
		super(url);
	}

	@Override
	public long size() {
		// TODO Auto-generated method stub
		return this.temperatures.size();
	}

	@Override
	public List<Date> dates() {
		// TODO Auto-generated method stub
		List<Date> ret =new ArrayList<Date>();
		this.temperatures.forEach(i->{
			if(!ret.contains(i.getDate()))
				ret.add(i.getDate());
		});
		return ret;
	}

	@Override
	public Set<String> cities() {
		// TODO Auto-generated method stub
		Set<String> ret=new HashSet<String>();
		this.temperatures.forEach(tmp->{
			ret.add(tmp.getCity());
			
		});
		return ret;
	}

	@Override
	public Set<String> countries() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Set<String> ret=new HashSet<String>();
		this.temperatures.forEach(tmp->{
			ret.add(tmp.getCountry());
			
		});
		return ret;
	}

	@Override
	public Map<String, Temperatures> temperaturesByCountry() {
		// TODO Auto-generated method stub
		Map<String,Temperatures >ret= new HashMap<String,Temperatures>();
		this.countries().forEach(country->
		{
			Stack<Temperature> tmp= new Stack<Temperature >();
			this.temperatures.forEach(temp->
			{
				if(temp.getCountry().equals(country))
					tmp.push(temp);
			});
			
			ret.put(country, new IteratorTemperatures(tmp));
		});
		return ret;
	}

	@Override
	public String coldestCountryAbs() {
		// TODO Auto-generated method stub
		Stack<Double> coldestTemp=new Stack<Double>();
		coldestTemp .push((double) 2000);
		String ret="";
		temperatures.forEach(tmp->
		{
		if(coldestTemp.peek()>tmp.getAverageTemperature())
			coldestTemp.push( tmp.getAverageTemperature());
		});
		
		for(Temperature tmp: temperatures )
		{
			if(coldestTemp.peek() .equals(tmp.getAverageTemperature()))
				{
				ret= tmp.getCountry();
				break;
				}
		}
		//System.out.println(coldestTemp);
		//System.out.println(coldestTemp.peek());
		return ret;
	}

	@Override
	public String hottestCountryAbs() {
		// TODO Auto-generated method stub
		Stack<Double> hottestTemp=new Stack<Double>();
		hottestTemp .push((double) -2000);
		String ret="";
		temperatures.forEach(tmp->
		{
		if(hottestTemp.peek()<tmp.getAverageTemperature())
			hottestTemp.push( tmp.getAverageTemperature());
		});
		
		for(Temperature tmp: temperatures )
		{
			if(hottestTemp.peek() .equals(tmp.getAverageTemperature()))
				{
				ret= tmp.getCountry();
				break;
				}
		}
		//System.out.println(hottestTemp.peek());
		return ret;
	}

	@Override
	public String coldestCountryAvg() {
		// TODO Auto-generated method stub
		Stack<String> ret=new Stack<String>();
		Stack<Double>coldestTempAvg=new Stack<Double>();
		coldestTempAvg .push(2000.0);
		countriesAvgTemperature().forEach((country,Avgtemps)->{
			if(coldestTempAvg.peek()>Avgtemps)
				coldestTempAvg.push(Avgtemps);
		});
		
		countriesAvgTemperature().forEach((country,Avgtemps)->{
			if(coldestTempAvg.peek().equals(Avgtemps))
				ret.push(country);
		});
		//System.out.println(coldestTempAvg.peek());
		return ret.peek();
	}

	@Override
	public String hottestCountryAvg() {
		// TODO Auto-generated method stub
		Stack<String> ret=new Stack<String>();
		Stack<Double>hottestTempAvg=new Stack<Double>();
		hottestTempAvg .push(-2000.0);
		countriesAvgTemperature().forEach((country,Avgtemps)->{
			if(hottestTempAvg.peek()<Avgtemps)
				hottestTempAvg.push(Avgtemps);
		});
		
		countriesAvgTemperature().forEach((country,Avgtemps)->{
			if(hottestTempAvg.peek().equals(Avgtemps))
				ret.push(country);
		});
		//System.out.println(hottestTempAvg.peek());
		return ret.peek();
	}

	@Override
	public Map<String, Double> countriesAvgTemperature() {
		// TODO Auto-generated method stub
		HashMap <String,Double>country2TempAvg=new HashMap<String,Double>();
		countries().forEach(country->
		{
			Stack<Double> TempAvg=new Stack<Double>(),TempSum=new Stack<Double>();
			TempSum.push(0.0);
			this.temperaturesByCountry().get(country).temperatures.forEach(temp->
			{
				TempSum.push(temp.getAverageTemperature()+TempSum.pop());
			});
			TempAvg.push(TempSum.peek()/(double)temperaturesByCountry().get(country).size());
			country2TempAvg.put(country, TempAvg.peek());
		});
		return country2TempAvg;
	}
	private Stack<Integer> fromyeartoyear()
	{
		Stack<Integer> ret=new Stack<Integer>();
		Stack<Integer>startYear=new Stack<Integer>(),endYear=new Stack<Integer>();
		startYear .push(9999);
		endYear .push(-9999);

		this.temperatures.forEach(i->
		{
			if(i.getDate().getYear()<startYear.peek() ) startYear.push( i.getDate().getYear());
			if(i.getDate().getYear()>endYear.peek()) endYear .push(i.getDate().getYear());
		});
		ret.push(startYear .peek());
		ret.push(endYear .peek());
		//System.out.println(startYear .peek());
		//System.out.println(endYear .peek());
		
		return ret; 
	}
	public Map<String,Double> avgTemperatureDeltaPerYearPerCountry()
	{
		/*Object[] tmp=this.temperatures.toArray();
		Temperature[] temps= new Temperature[tmp.length];
		Stack<Double>deltaForCity=new Stack<Double>();
		Stack<Double>deltaForCountry =new Stack<Double>();
		//deltaForCity.push(0.0);
		Stack<Integer> Citycount =new Stack<Integer>();
		Stack<Integer> CountryCount= new Stack<Integer>();
		CountryCount.push(0);
		for(int i=0;i<temps.length;i++)
		{
			temps[i]=(Temperature)tmp[i];
		}*/
		Map<String,Double> ret =new HashMap<String,Double>();
		Stack<Integer> scheisse=this.fromyeartoyear(); 
		int endYear=scheisse.pop();
		//System.out.println(endYear);
		int startYear=scheisse.pop();
		
		
		//System.out.println("staryear "+startYear);
		//System.out.println("startYear :"+startYear+"  endYear"+endYear);
	
		
		/*this.countries().forEach(country->
		{
			CountryCount.push(CountryCount.pop()+1);
			if(!Citycount.empty())
			{
				System.out.println("es");
				Citycount.clear();
			}
			Citycount.push(0);
			if(!deltaForCity.empty()) deltaForCity.clear();
			
			this.cities().forEach(city->
			{
				
					
				for(Temperature temp:temps)
				{
					
					
					{if(temp.getCountry().equals(country)&&temp.getCity().equals(city))
					{
						
						double avgDelta=0;
						Citycount.push(Citycount.pop()+1);
						Stack<Double>yearAvg=new Stack<Double>();
						for(int i=startYear;i<=endYear;i++ )
						{
							double yearavg1=0;
							
							int yearcount1=0;
							for(Temperature temp1:temps)
							{
								if(temp1.getCountry().equals(country)&&temp1.getCity().equals(city)&&temp1.getDate().getYear()==i)
								{
									yearcount1++;
									yearavg1+=temp1.getAverageTemperature();
								}
							}
							yearavg1=yearavg1 /(double)yearcount1;
							System.out.println(country+" "+city+" year "+i);
							yearAvg.push(yearavg1);
							
						}
						
						for(int i=0;i<endYear-startYear;i++)
						{
							avgDelta+=yearAvg.get(i+1)-yearAvg.get(i);
						}
						avgDelta=avgDelta/(double) endYear-startYear;
						deltaForCity.push(avgDelta);
				
						break;
					}
					
					}
				};
			});
		
			deltaForCountry.push(deltaForCity.stream().reduce(0.0, (i,j)->i+j)/(double)Citycount.pop());
		ret.put(country, deltaForCountry.peek());
		});*/
		
		Stack<Double> values=new Stack<Double>();
		
		this.countries().forEach(country->{
			Stack<Double> deltaOfCountry=new Stack<Double>();
			
			this.theCitiesOf(country).forEach(city->{
				HashMap<Integer,Double>AvgTempPerYear=new HashMap<Integer,Double>();
				StreamTemperatures TempsOfCity=this.forCity(city);
				for(int i=(startYear>=0? startYear:0) ;i<=endYear ;i++)
				{
					StreamTemperatures TempsInYearOfThisCity=TempsOfCity.forYear(i);
					AvgTempPerYear.put(i, TempsInYearOfThisCity.calculateAvg());
				}
				int count =0;
				double deltaOfCity=0.0;
				for(int i=(startYear>=0? startYear:0) ;i<endYear ;i++)
				{
					deltaOfCity +=AvgTempPerYear.get(i+1)-AvgTempPerYear.get(i);  
					count++;
				}
				deltaOfCity=deltaOfCity/(double)count;
				deltaOfCountry.push(deltaOfCity);
			});
			double value =deltaOfCountry.stream().reduce(0.0, (i,j)->i+j);
			value=value/(double)this.theCitiesOf(country).size();
			values.push(value);
			ret.put(country, value);
		});
		
		ret.put("Globally", values.stream().reduce(0.0, (i,j)->i+j)/(double)this.countries().size());
		
		return ret;
	}
	private double calculateAvg()
	{
		double ret =0.0;
		long size =this.size();
		for(Temperature temp:this.temperatures )
		{
			ret+=temp.getAverageTemperature();
		}
		return ret/(double)size;
	}
	private StreamTemperatures forYear(int year)
	{
		Stack<Temperature> temps= new Stack<Temperature>();
		this.temperatures.forEach(i->{
			if(i.getDate().getYear()==year)
			{
				temps.push(i);
			}
		});
		return new StreamTemperatures(temps);
	}
	private StreamTemperatures forCity(String city)
	{
		Stack<Temperature> temps=new Stack<Temperature>();
		this.temperatures.forEach(i->{
			if(i.getCity().equals(city))
				temps.push(i);
		});
		return new StreamTemperatures(temps);
	}
	private Set<String> theCitiesOf(String country)
	{
		HashSet<String> ret= new HashSet<String>();
		this.temperatures.forEach(i->{
			if(i.getCountry().equals(country))
			{
				ret.add(i.getCity());
			}
		});
		return ret;
	}
	public static void main(String[] args) throws Exception {

		StreamTemperatures temps=null;
		try {
		URL url = new URL(args[0]);
		temps= new StreamTemperatures(url);
		
		temps.printSummary();
		temps.avgTemperatureDeltaPerYearPerCountry().entrySet().forEach(i->System.out.println("Country: "+i.getKey()+"\n  >avgTemperatureDeltaPerYearPerCountry:     "+i.getValue()+"\n"));
		
		}
		catch(Exception e)
		{
			try {
				//System.out.println("hi");
			temps=new StreamTemperatures(new File(args[0]));
			temps.printSummary();
			temps.avgTemperatureDeltaPerYearPerCountry().entrySet().forEach(i->System.out.println("Country: "+i.getKey()+"\n  >avgTemperatureDeltaPerYearPerCountry:     "+i.getValue()+"\n"));
			}
			catch(Exception i)
			{
				i.printStackTrace();
			}
		}
		
	}

}
