import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class TemplateProcessor {
	private BufferedReader reader;
	public TemplateProcessor (String FileName) throws FileNotFoundException {
		reader = new BufferedReader(new InputStreamReader(new FileInputStream(FileName)));
	}
	public String replace(java.util.Map<String, String> variableAssignments)
	{
		String ret="";
		ArrayList<String> linelist= new ArrayList<String>();
		ArrayList<String> tempList=new ArrayList<String>();
		reader.lines().filter(i->!i.equals("")).forEach(i->
		{
			variableAssignments .keySet().stream().forEach(j->
			{
				String tmp="%"+j;
				if(tempList.isEmpty())
				{
					tempList.add(i);
					tempList.set(0, tempList.get(0).replaceAll(tmp, variableAssignments.get(j)));
				}
				else tempList.set(0, tempList.get(0).replaceAll(tmp, variableAssignments.get(j)));	
			});
			
			linelist.add(tempList.get(0)+"\n");
			//System.out.println(tempList.get(0));
			tempList.clear();
		});
		
		ret=linelist.stream().reduce(ret, (i,j)->i+j);
		return ret;
	}
	
	

}
