import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import suchmaschine.*;
public class TestItServer {
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		ServerSocket server= new ServerSocket(8000); 
		try {
			
			while(true) {
		                 Socket client = server.accept();
		                 BufferedReader in= new BufferedReader(new InputStreamReader(client.getInputStream()));
	 	                 PrintWriter out = new PrintWriter(new PrintWriter(new OutputStreamWriter(client.getOutputStream())));
	 	                 
	 	                 //String befehl= in.readLine();
		
	 	                 
	 	                	 
	 	                	 double pageRankDampingFactor = 0.85;
	    double weightingFactor = 0.6;

	    LinkedDocumentCollection ldc = new LinkedDocumentCollection();
	    String command;

	    boolean exit = false;

	    while (!exit) {
	    	out.print(">");
             out.flush();
	      command = in.readLine();

	      if (command == null || command.equals("exit")) {
	        // Exit program 
	        exit = true;
	      } else if (command.startsWith("add ")) {
	        // add a new document 
	        String titleAndText = command.substring(4);

	        // title and text separated by : 
	        int separator = titleAndText.indexOf(':');
	        String title = titleAndText.substring(0, separator);
	        String text = titleAndText.substring(separator + 1);

	        ldc.appendDocument(new LinkedDocument(title, "", "", null, null, text, title));
	      } else if (command.startsWith("list")) {
	        // list all document in collection 
	        for (int i = 0; i < ldc.numDocuments(); i++) {
	          out.println(ldc.get(i).getTitle());
	          out.flush();
	        }
	      } else if (command.startsWith("query ")) {
	        // query on the documents in the collection 
	        String query = command.substring(6);

	        double[] relevance = ldc.match(query, pageRankDampingFactor, weightingFactor);
	        
	        String msg = "";
	        for (int i = 0; i < ldc.numDocuments(); i++) {
	          msg = (i + 1) + ". " + ldc.get(i).getTitle() + "; Relevanz: " + relevance[i];
	          out.println(msg);
	          out.flush();
	        }

	        out.println();
	        out.flush();
	      } else if (command.startsWith("count ")) {
	        // print the count of a word in each document 
	        String word = command.substring(6);

	        for (int i = 0; i < ldc.numDocuments(); i++) {
	          Document doc = ldc.get(i);
	          WordCountsArray docWordCounts = doc.getWordCounts();

	          int count = docWordCounts.getCount(docWordCounts.getIndexOfWord(word));

	          // -1 and 0 makes a difference! 
	          if (count == -1) {
	            out.println(doc.getTitle() + ": gar nicht.");
	            out.flush();
	          } else {
	            out.println(doc.getTitle() + ": " + count + "x ");
	            out.flush();
	           
	          }
	        }
	      } else if (command.startsWith("pageRank")) {
	        double[] pageRanks = ldc.pageRank(pageRankDampingFactor);

	        for (int i = 0; i < ldc.numDocuments(); i++) {
	          out.println(ldc.get(i).getTitle() + "; PageRank: " + pageRanks[i]);
	          out.flush();
	        }
	      } else if (command.startsWith("crawl")) {
	    	  
	        ldc = ldc.crawl();
      }
    }
	    out.println("Connection closed by foriegn host");
	    out.flush();
	    client.close();
	 	                 }
		                
		    }
		finally {
			server.close();
		}
	}

}
/*
 * 
 * Es kann nicht mehrere Clients gleichzeitig zu dem Server verbinden,
 * denn es gibt nur eine "accept" Methode in einer Main Thread, also nachdem 
 * der Client akzeptiert wird , kann nur dieser Client mit dem Server kommunizieren.
 * 
 * 
 */
