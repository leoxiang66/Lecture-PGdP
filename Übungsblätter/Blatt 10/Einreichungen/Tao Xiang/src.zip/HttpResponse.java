
public class HttpResponse {
	private HttpStatus status ;
	private String body;
	public HttpResponse(HttpStatus status,String body)
	{
		this.body=body;
		this.status=status;
	}
	public String toString() { //ueberschreiben

		
		    String statusLine = "HTTP/1.1 " + status.getCode() + " " + status.getText().toUpperCase();
		    return statusLine + "\r\n" + "Host: http://127.0.0.1:8000/" + "\r\n\r\n" +body;
		  
	
		

	}
	public HttpStatus getStatus() {
		return this.status;
	}
	public String getBody() {
		return this.body;
	}

}
