import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.stream.IntStream;

import suchmaschine.*;
public class WebServer {
	private static HttpResponse handleMainPage() {
		String hauptSeite=
			
				"<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<title> PGdP Search Enigne</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<center>\r\n" + 
				"<h2>PGdP Search Engine</h2>\r\n" + 
				"<form action=\"/search\">\r\n" + 
				"<input type=\"text\" name =\"query\" value=\"\">\r\n" + 
				"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
				"</form>\r\n" + 
				"</center>\r\n" + 
				"<br><br>\r\n" + 
				"<center>\r\n" + 
				"<table border=\"1px solid black\">\r\n" + 
				"</table>\r\n" + 
				"</center>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		return new HttpResponse(HttpStatus.Ok, hauptSeite);
	}
	private static HttpResponse handleSearchRequest(String query)
	{
	
		double pageRankDampingFactor=0.85;
		double weightingFactor=0.6;
		LinkedDocumentCollection ldc;
		LinkedDocumentCollection tmp= new LinkedDocumentCollection();
		tmp.appendDocument(new LinkedDocument("B.txt", "", "", null, null, "link:A.txt link:E.txt", "B.txt"));
		ldc=tmp.crawl();
		ldc.match(query, pageRankDampingFactor, weightingFactor);
		
		int[] havefun1=new int[ldc.numDocuments()-1];
		IntStream havefun= Arrays.stream(havefun1);
		Stack<Integer> havefun2=new Stack<Integer>();
		havefun2.push(0);
		havefun.forEach(i->havefun2.push(havefun2.peek()+1));
		
		Stack<String> ret =new Stack<String>();
		ret.push("");
		 double[] relevance = ldc.match(query, pageRankDampingFactor, weightingFactor);
		havefun2.stream().forEach(i->
		{
			ret.push(ret.pop()+"<tr><td>"+(i+1)+"</td><td><a href=\""+ldc.get(i).getTitle()+"\">"+ldc.get(i).getTitle()+"</a></td><td>"+relevance[i]
					+"</td></tr>\r\n");
		});
		return new HttpResponse(HttpStatus.Ok,	ret.peek());
	}
	private static HttpResponse handleFileRequest(String fileName) throws FileNotFoundException
	{
		try {
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName))); 
		String tmp =(String)reader.lines().toArray()[1];
		String html=
				 
				"<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<title>"+fileName+"</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<h1>"+tmp+"</h1>\r\n" + 
				"</body>\r\n" + 
				"</html>\r\n" ;
		//System.out.println(tmp);
		return new HttpResponse(HttpStatus.Ok,html);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new HttpResponse(HttpStatus.NotFound, "<!DOCTYPE html>\r\n"
					+ "<html>\r\n"+
					"<body>file not found</body></html>");
		}
		
	}
	public static void main(String[] args) throws IOException {
		ServerSocket webserver=new ServerSocket(8000);
		
		try{ 
		
			int[]times = new int[214748];
			IntStream havefun666=Arrays.stream(times);
		// hi
			havefun666.forEach(m->
			
		     { 
		    	 try{
			    Socket client= webserver.accept();
				BufferedReader in= new BufferedReader(new InputStreamReader(client.getInputStream()));
				PrintWriter out =new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
				
				
				
				
				
				
				
				/*out.println( 
						new HttpResponse(HttpStatus.Ok, 
								"<!DOCTYPE html>\r\n" + 
							"<html>\r\n" + 
								"<head>\r\n" + 
								"<title> PGdP Search Enigne</title>\r\n" + 
								"</head>\r\n" + 
								"<body>\r\n" + 
								"<center>\r\n" + 
								"<h2>PGdP Search Engine</h2>\r\n" + 
								"<form action=\"/search\">\r\n" + 
								"<input type=\"text\" name =\"query\" value=\"\">\r\n" + 
								"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
								"</form>\r\n" + 
								"</center>\r\n" + 
								"<br><br>\r\n" + 
								"<center>\r\n" + 
								"<table border=\"1px solid black\">\r\n" + 
								"</table>\r\n" + 
								"</center>\r\n" + 
								"</body>\r\n" + 
								"</html>\r\n" + 
								"").toString()
						);
				out.flush();*/
				
				
				
				
				
				
				
				String query= in.readLine();
				//System.out.println(query);
				//System.out.println(query==null);
				HttpRequest request = null;
				HttpResponse response=new HttpResponse(HttpStatus.Ok, "");
			try { request= new HttpRequest(query);}
			catch(InvalidRequestException e)
			{
				response= new HttpResponse(HttpStatus.Forbidden, "<!DOCTYPE html>\r\n" + 
						"<html>\r\n" + 
						"<head>\r\n" + 
						"<title> Invalied Request</title>\r\n" + 
						"</head>\r\n" + 
						"<body>\r\n" + 
						
						"<h2>Invalied Request</h2>\r\n" + 
						
						
						"</body>\r\n" + 
						"</html>\r\n" );
				out.println(response.toString());
				out.flush();
				e.printStackTrace();
			}
			if(response.getStatus()==HttpStatus.Ok) {
				boolean hauptseite= false;
				if(request.getPath().equals("/"))
				{
					hauptseite=true;	
				}
				
				if(hauptseite)
				{
					out.println( 
							new HttpResponse(HttpStatus.Ok,
									"<!DOCTYPE html>\r\n" + 
								"<html>\r\n" + 
									"<head>\r\n" + 
									
									"<title> PGdP Search Enigne</title>\r\n" + 
									"</head>\r\n" + 
									"<body>\r\n" + 
									"<center>\r\n" + 
									"<h2>PGdP Search Engine</h2>\r\n" + 
									"<form action=\"/search\">\r\n" + 
									"<input type=\"text\" name =\"query\" value=\"\">\r\n" + 
									"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
									"</form>\r\n" + 
									"</center>\r\n" + 
									"<br><br>\r\n" + 
									"<center>\r\n" + 
									"<table border=\"1px solid black\">\r\n" + 
									"</table>\r\n" + 
									"</center>\r\n" + 
									"</body>\r\n" + 
									
									"</html>\r\n" 
									).toString()
							);
					out.flush();
				}
				else if(request.getPath().equals("/search"))
				{
					//System.out.println(request.getParameters().size());
					/*boolean mehereQuerys= false;
					if(request.getParameters().size()>1)
					{
						mehereQuerys =true;
					}*/
					request.getParameters().forEach((i,j)->{
						//System.out.println(i+" "+j);
						if(i.startsWith("query")){
						if(j.equals(""))
						{
							
							out.println(
									new HttpResponse(HttpStatus.Ok,
									"<!DOCTYPE html>\r\n" + 
										
									"<html>\r\n" + 
									//"<form action=\"action.jsp\" target=\"_blank\">\r\n"+
									"<head>\r\n" + 
									"<title> PGdP Search Enigne</title>\r\n" + 
									"</head>\r\n" + 
									"<body>\r\n" + 
									"<center>\r\n" + 
									"<h2>PGdP Search Engine</h2>\r\n" + 
									"<form action=\"/search\">\r\n" + 
									"<input type=\"text\" name =\"query\" value=\"\">\r\n" + 
									"<input type = \"submit\" value=\"Submit Query\">\r\n" + 
									"</form>\r\n" + 
									"</center>\r\n" + 
									"<br><br>\r\n" + 
									"<center>\r\n" + 
									"<table border=\"1px solid black\">\r\n" + 
									"</table>\r\n" + 
									"</center>\r\n" + 
									"</body>\r\n" + 
								//	"</form>\r\n"+
									"</html>\r\n" + 
									"").toString());
							out.flush();
						}
						else
						{
							String tabelle = handleSearchRequest(j).getBody();
							try {
								TemplateProcessor t= new TemplateProcessor("template.html");
								Map<String,String> map = new HashMap<String,String>();
								map.put(i, j);
								String replaced=t.replace(map);
								String ret = replaced.replaceAll("%tabelle", tabelle);
								//System.out.println(new HttpResponse(HttpStatus.Ok, ret).toString());
								out.println(new HttpResponse(HttpStatus.Ok, ret).toString());
								out.flush();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						}
					});
				}
				else if(request.getPath().contains("."))
				{
					//System.out.println("yes");
					String name = request.getPath().substring(1);
					HttpResponse tmp =handleFileRequest(name);
					
					
						out.println(tmp.toString());
						out.flush();
					
					
				}
				
				else {
					System.out.println(request.getPath());
					response= new HttpResponse(HttpStatus.Forbidden, "<!DOCTYPE html>\r\n" + 
							"<html>\r\n" + 
							"<head>\r\n" + 
							"<title> Invalied Request</title>\r\n" + 
							"</head>\r\n" + 
							"<body>\r\n" + 
							
							"<h2>Invalied Request</h2>\r\n" + 
							
							
							"</body>\r\n" + 
							"</html>\r\n" );
					out.println(response.toString());
					out.flush();
					InvalidRequestException e = new InvalidRequestException();
					e.printStackTrace();
				}
			
			
				//System.out.println(client.isClosed()+"hi");
			out.flush();
	 	     }}
		    	 catch(Exception e)
		    	 {
		    		 
		    	 }
		    	 
					
		     }
		     
					);
			
			
			//
		   }
		
		finally
		{
			
		}
	
		

}}
