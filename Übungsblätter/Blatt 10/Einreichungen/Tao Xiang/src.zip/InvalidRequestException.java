
public class InvalidRequestException extends RuntimeException {


	public String toString() {

		return "InvalidRequestException:invalid Request!!";

	}

}
