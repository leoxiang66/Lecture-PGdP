/**
 * The class {@code Review} represents a review of a {@see Document}.
 * 
 * @author Florian Kelbert
 *
 */
public class Review {
  
}
