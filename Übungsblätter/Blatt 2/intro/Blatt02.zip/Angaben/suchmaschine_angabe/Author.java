/**
 * The class {@code Author} represents an author of a {@see Document} or a
 * {@see Review}.
 * 
 * @author Florian Kelbert
 *
 */
public class Author {
  
}
