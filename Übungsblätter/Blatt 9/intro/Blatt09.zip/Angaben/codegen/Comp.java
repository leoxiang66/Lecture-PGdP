package codegen;

public enum Comp {
  Equals, NotEquals, LessEqual, Less, GreaterEqual, Greater
}
