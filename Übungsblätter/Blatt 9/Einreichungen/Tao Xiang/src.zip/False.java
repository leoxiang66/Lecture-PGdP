
public class False extends Condition{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "(false)";
	}
	 void accept(ProgramVisitor visitor) {
			visitor.visit(this);
		}
	

}
