
public class FormatVisitor implements ProgramVisitor{

	private static String FormattedCode="";
	public String getFormattedCode() {
		return FormatVisitor.FormattedCode;
	}
	private static int loopTimes=0;
	private  void formatingStatements(Statement stmt)
	{
		String whiteSpace="  ";
		for(int i=0;i<loopTimes;i++)
		{
			whiteSpace+="  ";
		}
		if(!(stmt instanceof Composite))
		FormattedCode+=whiteSpace;
		if(stmt instanceof Assignment)
		{
			Assignment tmp =(Assignment) stmt;
			this.visit(tmp);
		
		}
		if(stmt instanceof Composite)
		{
			Composite tmp= (Composite) stmt;
			this.visit(tmp);
			
		}
		if(stmt instanceof IfThen)
		{
			IfThen tmp = (IfThen) stmt;
			this.visit(tmp);
			
		}
		if(stmt instanceof IfThenElse)
		{
			IfThenElse tmp= (IfThenElse) stmt;
			this.visit(tmp);
			
		}
		if(stmt instanceof While)
		{
			While tmp= (While) stmt;
			this.visit(tmp);
		}
		if(stmt instanceof Return)
		{
			Return tmp= (Return) stmt;
			this.visit(tmp);
		}
		if(stmt instanceof ExpressionStatement)
		{
			ExpressionStatement tmp=(ExpressionStatement )stmt;
			this.visit(tmp);
		}
		if(stmt instanceof Switch) {
			Switch tmp= (Switch)stmt;
			visit(tmp);
		}
		if(stmt instanceof Break){
			Break tmp=(Break) stmt;
			visit(tmp);
		}
	}
	@Override
	public void visit(Program pg) {
		// TODO Auto-generated method stub
		FormattedCode="";
		for(Function fun: pg.getFunctions())
		{
		  boolean hasReturn=false;
		  for(Statement stmt:fun.getStatements())
		  { 
		  
			  if(stmt instanceof Return) 
			  {
				  hasReturn = true;
				  break;
			  }
		  }
		  if(hasReturn)
		  {
			  FormattedCode+="int ";
		  }
		  else FormattedCode+="void ";
		  
		  this.visit(fun);
		  
		  
		  
		}
		}
	@Override
	public
	 void visit(UnaryCondition unaryCondition) {
		// TODO Auto-generated method stub
		FormattedCode+=unaryCondition.toString();
		
	}
	@Override
	public void visit(Function fun) {
		FormattedCode+=fun.getName()+"(";

		  String[] tmp1=new String[fun.getParameters().length];
		  for(int i=0;i<tmp1.length;i++)
		  {
			  tmp1[i]="int "+fun.getParameters()[i];
		  }
		  for(int i=0;i<tmp1.length;i++)
		  {
			  if(i==tmp1.length-1) {
				  FormattedCode+=tmp1[i];
			  break;
		      }
			  
			  FormattedCode+=tmp1[i]+", ";
		  }
		  
		  FormattedCode+=") {\n";
		  
		  for(Declaration i:fun.getDeclarations())
		  {
			  this.visit(i);
		  }
		  for(Statement s:fun.getStatements()) {
			  this.formatingStatements(s);
		  }
		  FormattedCode+="}\n\n";
 
		  

		  
		  
		  
		  
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visit(Declaration i) {
		
		// TODO Auto-generated method stub
		FormattedCode+="  ";
		  FormattedCode+="int ";
		  for(int j=0;j<i.getNames().length;j++)
		  {
			  if(j==i.getNames().length-1)
			  {
				  FormattedCode+=i.getNames()[j]+" ;";
				  break;
			  }
			  FormattedCode+=i.getNames()[j]+" ,";
		  }
		  FormattedCode+="\n";
	}
	@Override
	public void visit(Assignment tmp) {
		FormattedCode+=tmp.getName()+" = ";
		this.visit(tmp.getExpression());
		FormattedCode+=";\n";
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visit(Composite tmp) {
		// TODO Auto-generated method stub
		for(Statement i: tmp.getStatements()) {
			formatingStatements(i);
		}
		
	}
	@Override
	public void visit(IfThen tmp) {
		// TODO Auto-generated method stub
		loopTimes++;
		FormattedCode+="if(";
		this.visit(tmp.getCond());
		FormattedCode+=") {\n";
		formatingStatements(tmp.getThenBranch());
		//System.out.println(";");
		String whiteSpace2="";
		for(int i=0;i<loopTimes;i++)
		{
			whiteSpace2+=" ";
		}
		
		FormattedCode+=whiteSpace2+"}\n";
		loopTimes--;
		
	}
	@Override
	public void visit(IfThenElse tmp) {
		// TODO Auto-generated method stub
		loopTimes++;
		FormattedCode+="if(";
		this.visit(tmp.getCond());
		FormattedCode+=") {\n";
		formatingStatements(tmp.getThenBranch());
		//System.out.println(";");
		FormattedCode+=" }\n";
	
		FormattedCode+="else+ {\n";
		formatingStatements(tmp.getElseBranch());
		//System.out.println(";");
		String whiteSpace2="";
		for(int i=0;i<loopTimes;i++)
		{
			whiteSpace2+=" ";
		}
		
		FormattedCode+=whiteSpace2+"}\n";
		loopTimes--;
		
	}
	@Override
	public void visit(While tmp) {
		// TODO Auto-generated method stub
		loopTimes++;
		if(tmp.isDowhile())
		{
			FormattedCode+="do {\n";
			formatingStatements(tmp.getBody());
			String whiteSpace3="  ";
			for(int i=0;i<loopTimes-1;i++)
			{
				whiteSpace3+="  ";
			}
			FormattedCode+=whiteSpace3+"while(";
			this.visit(tmp.getCon());
			FormattedCode+=");\n";
			
			String whiteSpace2="";
			for(int i=0;i<loopTimes;i++)
			{
				whiteSpace2+=" ";
			}
			
			FormattedCode+=whiteSpace2+"}\n";
			loopTimes--;
		}
		else {
			FormattedCode+="while(";
			this.visit(tmp.getCon());
			FormattedCode+=") {\n";
			formatingStatements(tmp.getBody());
			String whiteSpace2="";
			for(int i=0;i<loopTimes;i++)
			{
				whiteSpace2+=" ";
			}
			
			FormattedCode+=whiteSpace2+"}\n";
			loopTimes--;
		}
		
	}
	@Override
	public void visit(Return tmp) {
		// TODO Auto-generated method stub
		FormattedCode+="return "+tmp.getExpression().toString()+";\n";
		
	}
	@Override
	public void visit(ExpressionStatement tmp) {
		FormattedCode+=tmp.getExpression().toString()+";\n";
		// TODO Auto-generated method stub
		
	}
	@Override
	public void visit(Variable variable) {
		// TODO Auto-generated method stub
		FormattedCode+= variable.toString();
		
	}
	@Override
	public void visit(Number num) {
		// TODO Auto-generated method stub
		FormattedCode+=num.toString();
		
	}
	@Override
	public void visit(Binary binary) {
		// TODO Auto-generated method stub
		FormattedCode+=binary.toString();
		
	}
	@Override
	public void visit(Unary unary) {
		// TODO Auto-generated method stub
		FormattedCode+=unary.toString();
	}
	@Override
	public void visit(Read read) {
		// TODO Auto-generated method stub
		FormattedCode+=read.toString();
		
	}
	@Override
	public void visit(Write write) {
		// TODO Auto-generated method stub
		FormattedCode+=write.toString();
		
	}
	@Override
	public void visit(Call call) {
		// TODO Auto-generated method stub
		FormattedCode+=call.toString();
		
	}
	@Override
	public void visit(True true1) {
		// TODO Auto-generated method stub
		FormattedCode+=true1.toString();
		
	}
	@Override
	public void visit(False false1) {
		// TODO Auto-generated method stub
		FormattedCode+=false1.toString();
		
	}
	@Override
	public void visit(BinaryCondition binaryCondition) {
		// TODO Auto-generated method stub
		
		FormattedCode+=binaryCondition.toString();
	}
	@Override
	public void visit(Comparison comparison) {
		// TODO Auto-generated method stub
		FormattedCode+=comparison.toString();
	}
	@Override
	public void visit(Expression exp) {
		// TODO Auto-generated method stub
		if(exp instanceof Variable) this.visit((Variable)exp);
		if(exp instanceof Number) this.visit((Number)exp);
		if(exp instanceof Binary) this.visit((Binary)exp);
		if(exp instanceof Unary) this.visit((Unary)exp);
		if(exp instanceof Read) this.visit((Read)exp);
		if(exp instanceof Write) this.visit((Write)exp);
		if(exp instanceof Call) this.visit((Call)exp);
		
	}
	@Override
	public void visit(Condition cond) {
		// TODO Auto-generated method stub
		if(cond instanceof True) this.visit((True)cond);
		if(cond instanceof False) this.visit((False)cond);
		if(cond instanceof BinaryCondition) this.visit((BinaryCondition)cond);
		if(cond instanceof Comparison) this.visit((Comparison)cond);
		if(cond instanceof UnaryCondition) this.visit((UnaryCondition)cond);
		
	}
	@Override
	public void visit(Switch swi) {
		// TODO Auto-generated method stub
		loopTimes++;
		FormattedCode+="switch("+swi.getSwitchExpression().toString()+") {\n";
		String whitespace4="  ";
		for(int i=0;i<loopTimes;i++) {
			whitespace4+="  ";
		}
		for(SwitchCase Case:swi.getCases())
		{
			FormattedCode+=whitespace4+"case "+Case.getNumber()+": {\n";
			loopTimes++;
			this.formatingStatements(Case.getCaseStatement());
			loopTimes--;
			FormattedCode+=whitespace4+"}\n";
		}
		if(swi.getDefault()!=null)
		{
		FormattedCode+=whitespace4+"default:\n";
		loopTimes++;
		this.formatingStatements(swi.getDefault());
		loopTimes--;
		}
		loopTimes--;
		String whitespace6="  ";
		for(int i=0;i<loopTimes;i++) {
			whitespace6+="  ";
		}
		FormattedCode+=whitespace6+"}\n";
	}
	@Override
	public void visit(Break break0) {
		// TODO Auto-generated method stub
		FormattedCode+="break;\n";
	}
		
	

}
