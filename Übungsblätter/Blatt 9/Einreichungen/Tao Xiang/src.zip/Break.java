
public class Break extends Statement{

	@Override
	void accept(ProgramVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}

}
