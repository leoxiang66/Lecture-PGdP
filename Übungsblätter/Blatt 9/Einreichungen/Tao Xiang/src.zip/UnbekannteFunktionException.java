
public class UnbekannteFunktionException extends CodeGenException{
	public String toString() {
		return "UnbekannteFunktionException:\n keine solche Funktion vorhanden!!";
	}

}
