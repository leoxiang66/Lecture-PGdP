
public class Binary extends Expression{
	private Expression lhs;
	private Binop operator;
	private Expression rhs;
	
	public Expression getLhs() {
		return this.lhs;
	}
	public Binop getOperator() {
		return this.operator;
	}
	public Expression getRhs() {
		return this.rhs;
	}
	public Binary(Expression lhs,Binop operator,Expression rhs) {
		this.lhs=lhs;
		this.operator=operator;
		this.rhs=rhs;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		boolean lhsNoBracket=lhs instanceof Variable||lhs instanceof Number||lhs instanceof Call;
		boolean c=lhsNoBracket;
		
		boolean rhsNoBracket=rhs instanceof Variable||rhs instanceof Number||rhs instanceof Call;
		boolean b=rhsNoBracket;
		switch(this.operator)
		{
		case Plus :
		{
			if(!c&&!b)
		    return "("+lhs.toString()+")"+" + ("+rhs.toString()+")"; 
			if(c&&b)
				return lhs.toString()+" + "+rhs.toString();
			if(c&&!b)
				return lhs.toString()+" + ("+rhs.toString()+")";
			if(!c&&b)
				return "("+lhs.toString()+") + "+rhs.toString();
			
			
		}
		case Minus:
			{
				if(!c&&!b)
				    return "("+lhs.toString()+")"+" - ("+rhs.toString()+")"; 
					if(c&&b)
						return lhs.toString()+" - "+rhs.toString();
					if(c&&!b)
						return lhs.toString()+" - ("+rhs.toString()+")";
					if(!c&&b)
						return "("+lhs.toString()+") - "+rhs.toString();
			
			}
		case  MultiplicationOperator :
			{
				if(!c&&!b)
				    return "("+lhs.toString()+")"+" * ("+rhs.toString()+")"; 
					if(c&&b)
						return lhs.toString()+" * "+rhs.toString();
					if(c&&!b)
						return lhs.toString()+" * ("+rhs.toString()+")";
					if(!c&&b)
						return "("+lhs.toString()+") * "+rhs.toString();
			
			}
		case DivisionOperator: 
			{
				if(!c&&!b)
				    return "("+lhs.toString()+")"+" / ("+rhs.toString()+")"; 
					if(c&&b)
						return lhs.toString()+" / "+rhs.toString();
					if(c&&!b)
						return lhs.toString()+" / ("+rhs.toString()+")";
					if(!c&&b)
						return "("+lhs.toString()+") / "+rhs.toString();
			}
		case Modulo:
			{
				if(!c&&!b)
				    return "("+lhs.toString()+")"+" % ("+rhs.toString()+")"; 
					if(c&&b)
						return lhs.toString()+" % "+rhs.toString();
					if(c&&!b)
						return lhs.toString()+" % ("+rhs.toString()+")";
					if(!c&&b)
						return "("+lhs.toString()+") % "+rhs.toString();
			}
		}
		return"";
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
