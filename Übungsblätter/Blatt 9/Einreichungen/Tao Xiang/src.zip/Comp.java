

public enum Comp {
  Equals, NotEquals, LessEqual, Less, GreaterEqual, Greater
}
