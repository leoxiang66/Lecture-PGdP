
public class Switch extends Statement{
	private SwitchCase[] Cases;
	private Statement Default;
	private Expression SwitchExpression;
	
	public SwitchCase[] getCases() {
		return this.Cases;
	}
	public Statement getDefault() {
		return this.Default;
	}
	public Expression getSwitchExpression() {
		return this.SwitchExpression;
	}
	public Switch(SwitchCase[] cases,Statement default0,Expression switchexpression) 
	{
		Cases=cases;
		Default=default0;
		SwitchExpression =switchexpression;
	}

	@Override
	void accept(ProgramVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	

}
