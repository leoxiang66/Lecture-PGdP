
public class UnaryCondition extends Condition{
	private Bunop Operator;
	private Condition operand;
	
	public Bunop getOperator() {
		return this.Operator;
	}
	public Condition getOperand() {
		return this.operand;
	}
	public UnaryCondition(Bunop operator ,Condition operand) {
		this.operand=operand;
		this.Operator=operator;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		if(operand instanceof Comparison)
		{
			Comparison tmp= (Comparison) operand;
			if(tmp.getOperator().equals(Comp.Equals))
				return tmp.getLhs().toString()+"!="+tmp.getRhs().toString();
		}
		return "!"+operand.toString();
	}

	 void accept(ProgramVisitor visitor) {
			visitor.visit(this);
		}
}
