
public class Unary extends Expression{
	private Unop operator;
	private Expression operand;
	public Unop getOperator() {
		return this.operator;
	}
	public Expression getOperand() {
		return this.operand;
	}
	public Unary (Unop operator,Expression operand) {
		this.operator=operator;
		this.operand=operand;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String ret="";
		switch(this.operator)
		{
		case Minus: ret="-"+this.operand.toString();
		}
		return ret;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
