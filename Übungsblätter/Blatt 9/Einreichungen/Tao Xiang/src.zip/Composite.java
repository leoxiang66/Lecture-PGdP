
public class Composite  extends Statement{

	private Statement[] Statements;
	public Statement[] getStatements()
	{
		return this.Statements;
	}
	public Composite(Statement[] stmts) {
		this.Statements=stmts;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
}
