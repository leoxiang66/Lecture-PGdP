
public class BinaryCondition extends Condition{
	private Condition lhs;
	private Bbinop operator;
	private Condition rhs;
	
	public Condition getLhs() {
		return this.lhs;
	}
	public Condition getRhs() {
		return this.rhs;
	}
	public Bbinop getOperator() {
		return this.operator;
	}
	public BinaryCondition(Condition lhs,Bbinop operator,Condition rhs) {
		this.lhs=lhs;
		this.operator=operator;
		this.rhs=rhs;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String ret="";
		switch(this.operator)
		{
		case And:ret="("+lhs.toString()+") && ("+rhs.toString()+")";break;
		case Or :ret="("+lhs.toString()+") || ("+rhs.toString()+")";break;
		}
		return ret;
	}
	 void accept(ProgramVisitor visitor) {
			visitor.visit(this);
		}

}
