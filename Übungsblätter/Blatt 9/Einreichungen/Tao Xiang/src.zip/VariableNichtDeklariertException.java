
public class VariableNichtDeklariertException extends CodeGenException{
public String toString() {
	return "VariableNichtDeklariertException:\ndiese Variable wird nict deklariert!!";
}
}
