
public class FormatVisitorTest {
	public static void main(String[] args) {

		// Beispiel 1
				System.out.println("Beispiel 1: ");
				 Function main = new Function("main",  new String[] {},  new Declaration[] {},  new Statement[] {  new ExpressionStatement(new Write(new Call("sum", new Expression[] { new Read(), new Read() }))), new Return(new Number(0))  }); 
				 
				 Function sum = new Function("sum",  new String[] {"a", "b"},  new Declaration[] {},  new Statement[] {  new Return(new Binary(new Variable("a"), Binop.Plus, new Variable("b"))),  }); 
				// Function compare =new Function("compare",new String[] {"a","b"},new Declaration[] {},new Statement[] {new IfThen(new Comparison(new Variable("a"),Comp.Greater,new Variable("b")),new Return (new Number(1)))});
				 
				 FormatVisitor fv = new FormatVisitor(); 
				 Program prog0 =new Program (new Function[] {sum,main});
				 prog0.accept(fv);
				 System.out.println(fv.getFormattedCode());
				
				 
				 
		//Beispiel 2		 
				 System.out.println("Beispiel 2: ");
				 Function haha=new Function("haha",new String[] {},new Declaration[] {new Declaration(new String[] {"i","n","result"})},new Statement[] {new Assignment("n",new Read()),new Assignment("result",new Number(0)),new Assignment("i",new Number(1)),
							new While(
							new Comparison
							(new Variable("i"),Comp.NotEquals,new Variable("n"))
							,new Composite(new Statement[] {new Assignment("result",new Binary(new Variable("rusult"),Binop.Plus,new Variable("i")))
									,new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))}),false)});
						
				 
				 Program prog1 = new Program(new Function[] {haha});
				 
				 prog1.accept(fv); 
				 System.out.println(fv.getFormattedCode());
				 
				
				 
		//Beispiel 3 
				 System.out.println("Beispiel 3: ");
				Function main2 = new Function("main", new String[] {}, new Declaration[] {},
						new Statement[] {
								new ExpressionStatement(
										new Write(new Call("ggt", new Expression[] { new Read(), new Read() }))),
								new Return(new Number(0)) });

				Function ggt = new Function("ggt", new String[] { "a", "b" },
						new Declaration[] { new Declaration(new String[] { "temp" }) },
						new Statement[] { new IfThen(
								new UnaryCondition(Bunop.Not, new Comparison(new Variable("b"), Comp.Less, new Variable("a"))),
								new Composite(new Statement[] { new Assignment("temp", new Variable("b")),
										new Assignment("b", new Variable("a")), new Assignment("a", new Variable("temp")) })),
								new While(
										new UnaryCondition(Bunop.Not,
												new Comparison(new Variable("b"), Comp.Equals, new Number(0))),
										new Composite(new Statement[] { new Assignment("temp", new Variable("b")),
												new Assignment("b",
														new Binary(new Variable("a"), Binop.Modulo, new Variable("b"))),
												new Assignment("a", new Variable("temp")) }),
										true),
								new Return(new Variable("a")) });
				Program pro3 = new Program(new Function[] {main2,ggt});
				fv.visit(pro3);
				System.out.println(fv.getFormattedCode());

		}
}
