import aufgabe9_6.Interpreter;

public class TestSwitch {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function main = new Function("main",new String[] {},new Declaration[] {new Declaration(new String[] {"x","y","z"})},
				new Statement[] {new Assignment("x",new Read()),new Assignment("z",new Number(0)),
				//switch(x)
						new Switch(new SwitchCase[] {
								// case1
								new SwitchCase(new Number(1), new Composite(
								new Statement[] {new Assignment("y",new Read()),
										// switch(y)
										new Switch(new SwitchCase[] {
												//case1.1
												new SwitchCase(new Number(1), new Composite(
												new Statement[] {new Assignment("z",new Binary(new Variable("z"), Binop.Plus, new Number(1))),
														new Break()})),
												//case1.2
												new SwitchCase(new Number(2), new Assignment("z",new Binary(new Variable("z"),Binop.Plus,new Number(2))))},null,new Variable("y")),new Break()}))
								, // case 2
								new SwitchCase(new Number(2), new Assignment("z",new Number(42)))},
								new Assignment("z",new Binary(new Variable("z"),Binop.Plus,new Number(1))),new Variable("x"))
						,new ExpressionStatement(new Write(new Variable("z"))),new Return(new Number(0))
						});
		
		Program pr0= new Program(new Function[] {main})	;
	/*	FormatVisitor test0 = new FormatVisitor();
		test0.visit(pr0);
		System.out.println(test0.getFormattedCode()+"\n");
		*/
		
		CodeGenerationVisitor test1=new CodeGenerationVisitor(pr0);
		Interpreter interpreter1= new Interpreter(test1.getProgram());
		/*for(aufgabe9_6.Instruction in:test1.getProgram())
		{
			System.out.println(in.toString());
		}*/
		interpreter1.execute();
	}

}
