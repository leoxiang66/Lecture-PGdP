
public class IfThen extends Statement{

	private Condition condition;
	private Statement ThenBranch;
	public Condition getCond() {
		return this.condition;
	}
	public Statement getThenBranch() {
		return this.ThenBranch;
	}

	public IfThen(Condition cond,Statement ThenBranch)
	{
		this.condition=cond;
		this.ThenBranch=ThenBranch;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
}
