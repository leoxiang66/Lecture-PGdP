
public class Assignment extends Statement{
	// variable = expression;
	private String Name;// die Namen der zugewiesenen Variablen
	private Expression Expressions;
	public String getName() {
		return this.Name;
	}
	public Expression getExpression()
	{
		return this.Expressions;
	}
	public Assignment(String name,Expression exp)
	{
		this.Name=name;
		this.Expressions=exp;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
