
public class While extends Statement {

	private Condition condition;
	private Statement body;
	private boolean doWhile;
	public Condition getCon() {
		return this.condition;
	}
	public Statement getBody() {
		return this.body;
	}
	public boolean isDowhile() {
		return this.doWhile;
		
	}
	public While(Condition cond,Statement body,boolean dowhile) {
		this.body=body;
		this.doWhile=dowhile;
		this.condition=cond;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
}
