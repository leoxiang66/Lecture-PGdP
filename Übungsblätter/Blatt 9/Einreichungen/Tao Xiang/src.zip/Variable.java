
public class Variable extends Expression {
	private String Name;
	public String getName() {
		return this.Name;
	}
	public Variable(String Name) {
		this.Name=Name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.Name;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
