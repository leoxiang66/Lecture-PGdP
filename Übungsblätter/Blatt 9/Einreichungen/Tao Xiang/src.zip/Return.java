
public class Return extends Statement {
	private Expression expression;// die nach dem return steht.
	public Expression getExpression() {
		return this.expression;
	}
	public Return(Expression exp) {
		this.expression=exp;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
	

}
