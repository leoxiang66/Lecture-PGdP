
public class IfThenElse extends Statement{
	private Condition condition;
	private Statement ThenBranch;
	private Statement ElseBranch;
	
	public Condition getCond() {
		return this.condition;
	}
	public Statement getThenBranch() {
		return this.ThenBranch;
	}
	public Statement getElseBranch() {
		return this.ElseBranch;
	}
	public IfThenElse(Condition cond,Statement ThenBranch,Statement ElseBranch) {
		this.condition=cond;
		this.ThenBranch=ThenBranch;
		this.ElseBranch=ElseBranch;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
