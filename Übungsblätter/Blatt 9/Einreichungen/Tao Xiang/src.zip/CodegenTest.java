import aufgabe9_6.*;
public class CodegenTest {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

// Beispiel : ggt		
		
		System.out.println("ggt:");
		Function main0 = new Function("main", new String[] {}, new Declaration[] {},
				new Statement[] {
						new ExpressionStatement(
								new Write(new Call("ggt", new Expression[] { new Read(), new Read() }))),
						new Return(new Number(0)) });
		
		Function ggt = new Function("ggt", new String[] { "a", "b" },
				new Declaration[] { new Declaration(new String[] { "temp" }) },
				new Statement[] { new IfThen(
						new Comparison(new Variable("b"), Comp.GreaterEqual, new Variable("a")),
						new Composite(new Statement[] { new Assignment("temp", new Variable("b")),
								new Assignment("b", new Variable("a")), new Assignment("a", new Variable("temp")) })),
						new While(
								new UnaryCondition(Bunop.Not,
										new Comparison(new Variable("b"), Comp.Equals, new Number(0))),
								new Composite(new Statement[] { new Assignment("temp", new Variable("b")),
										new Assignment("b",
												new Binary(new Variable("a"), Binop.Modulo, new Variable("b"))),
										new Assignment("a", new Variable("temp")) }),
								true),
						new Return(new Variable("a")) });
		
				
		Program pr0 = new Program(new Function[] {main0,ggt});
		CodeGenerationVisitor test0=new CodeGenerationVisitor(pr0);
		Interpreter interpreter0= new Interpreter(test0.getProgram());
		interpreter0.execute();
		System.out.println();
		
		
		

// Beispiel : fak
		
		System.out.println("fak:");
		
		Function main1=new Function ("main",new String[] {},new Declaration[] {},
				new Statement[] {new ExpressionStatement(new Write (new Call("fak",new Expression[] {new Read()}))),
						new Return (new Number(0))});
		Function fak =new Function ("fak",new String[] {"n"},new Declaration[] {},
				new Statement[] {new IfThen(new Comparison(new Variable("n"),Comp.Equals,new Number(1)
						),new Return(new Number(1) )),
						new Return( new Binary(new Variable("n"),Binop.MultiplicationOperator,new Call("fak",new Expression[] {new Binary(new Variable("n"),Binop.Minus,new Number(1))})))});
		Program pr1= new Program(new Function[] {main1,fak});
		
		
		CodeGenerationVisitor test1=new CodeGenerationVisitor(pr1);
		/*for(Instruction in:test.getProgram())
		{
			System.out.println(in.toString());
		}*/
		
		Interpreter interpreter1= new Interpreter(test1.getProgram());
		interpreter1.execute();
		System.out.println();
		
	
		
		
// mein Beispiel:		

		System.out.println("mein Beispiel: ");

		Function add= new Function("add",new String[] {"i"},new Declaration[] {new Declaration(new String[] {"m"})},
			new Statement[] {new Return(new Number(5) )});
		
		Function main2 = new Function("main",new String[] {},new Declaration[] 
		{
		new Declaration(new String[] {"a"})},
		new Statement[] {new ExpressionStatement(new Write(new Call("add",new Expression[] {new Variable("a")})))});

		Program pr2 = new Program(new Function[] {main2,add});
		CodeGenerationVisitor test2=new CodeGenerationVisitor(pr2);
		Interpreter interpreter2= new Interpreter(test2.getProgram());
		interpreter2.execute();
		
		/*for(Instruction in:test2.getProgram())
		{
			System.out.println(in.toString());
		}*/
		System.out.println();
		
		
		
		/*FormatVisitor fv=new FormatVisitor();
		fv.visit(pr2);
		System.out.println(fv.getFormattedCode());
		*/
		
		//System.out.println(main1.numOfReturn());
				//Program pr = new Program (new Function[] {main,add});
	}

}
