
public class Write extends Expression {
	private Expression expression;
	public Expression getExpression() {
		return this.expression;
	}
	public Write(Expression exp) {
		this.expression=exp;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "write("+this.getExpression().toString()+")";
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
