
public class Comparison extends Condition{
	private Expression lhs;
	private Comp operator;
	private Expression rhs;
	
	public Expression getLhs() {
		return this.lhs;
	}
	public Comp getOperator() {
		return this.operator;
	}
	public Expression getRhs() {
		return this.rhs;
	}
	public Comparison(Expression lhs,Comp operator,Expression rhs) {
		this.lhs=lhs;
		this.operator=operator;
		this.rhs=rhs;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String ret="";
		switch (this.operator)
		{
		case Equals:ret=lhs.toString()+"=="+rhs.toString();break;
		case Greater:ret=lhs.toString()+">"+rhs.toString();break;
		case GreaterEqual :ret=lhs.toString()+">="+rhs.toString();break;
		case Less:ret=lhs.toString()+"<"+rhs.toString();break;
		case LessEqual: ret=lhs.toString()+"<="+rhs.toString();break;
		case NotEquals:ret=lhs.toString()+"!="+rhs.toString();break;
		}
		return ret;
	}
	 void accept(ProgramVisitor visitor) {
			visitor.visit(this);
		}
	

}
