
public class Number extends Expression {

	private int value;
	public int getValue() {
		return this.value;
	}
	public Number(int value) {
		this.value=value;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.value+" ";
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
}
