
public abstract class Statement {

	abstract void accept(ProgramVisitor visitor);
}
