
public class Call extends Expression{

	private String FunctionName;
	private Expression[] arguments;
	
	public String getFunctionName() {
		return this.FunctionName;
	}
	public Expression[] getArguments() {
		return this.arguments ;
	}
	public Call(String funcName,Expression[] arguments) {
		this.arguments=arguments;
		this.FunctionName=funcName;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String tmp="";
		for(int i=0;i<arguments.length;i++)
		{
			if(i==arguments.length-1)
			{
				tmp+=arguments[i];
				break;
			}
			tmp+=arguments[i]+",";
		}
		return this.FunctionName+"("+tmp+")";
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
	
}
