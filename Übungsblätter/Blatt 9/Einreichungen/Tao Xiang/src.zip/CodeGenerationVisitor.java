
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Stack;
import  aufgabe9_6.*;

public class CodeGenerationVisitor implements ProgramVisitor{
	private LinkedList<Instruction> Program;
	private HashMap<String,ArrayList<Instruction>> dividedProg;
	private Program visitedProgram;
	private Stack<String> virtuelleStack;
	private HashMap<String,Stack<Integer>> returnMap;
	private ArrayList<Brc> brcList;
	//private HashMap<String,Boolean> casedMap;
	//private Stack<String> switchStack;
	public Instruction[] getProgram () {
		Instruction[] ret= new Instruction[this.Program.size()];
		return this.Program.toArray(ret);
	}
	public CodeGenerationVisitor(Program program) {
		this.Program=new LinkedList<Instruction>();
		dividedProg=new HashMap<String,ArrayList<Instruction>>();
		lokalVariable=new HashMap<String,ArrayList<String>>();
		FuncPara=new HashMap<String,ArrayList<String>>();
		virtuelleStack=new Stack<String>();
		letzteFunc=new Stack<String>();
		callmap=new HashMap<String,ArrayList<Call>>();
		returnMap=new HashMap<String,Stack<Integer>>();
		brcList=new ArrayList<Brc>();
		//breakMap=new HashMap<String,Boolean>();
		//switchStack= new Stack<String>();
		this.visitedProgram=program;
		this.visit(program);
	}
	

	
	@Override
	public void visit(Program pro) {
		// TODO Auto-generated method stub
		for(Function f: pro.getFunctions())
		{
			if(f.getName().equals("main"))
			{
				  visit(f);
			}
			break;
		}
		//System.out.println("hi: "+this.dividedProg.get("main")==null);
		this.dividedProg.get("main").forEach(i-> this.Program.add(i));
		
		HashMap<String,Integer> index=new HashMap<String,Integer>();
		index.put("main", 0);
		this.dividedProg.keySet().stream().filter(i-> !i.equals("main")).sorted().
		                                   forEach(
		        //k ist FuncName            		   
		                         k->
		                            {
		                                   index.put(k, this.Program.size());	
		                                   this.dividedProg.get(k).stream().
		                                   filter(i->i instanceof Brc).
		                                   forEach(i->{
		                                	   Brc tmp=(Brc) i;
		                                	   tmp.setIndexOfInstruction(tmp.getIndexOfInstruction()+this.Program.size());
		                   
		                                   });
		                                   this.dividedProg.get(k).	  
				                           forEach(j->this.Program.add(j));
		                   		    }
		                      );
		for(Function fun:this.visitedProgram.getFunctions())
		{
			
			
			if(callmap.get(fun.getName())!=null)
			{//if(fun.getName().equals("fak"))
				{
				//System.out.println("1");
				
			}
			callmap.get(fun.getName()).forEach(call->
			{
				String calledFunc=call.getFunctionName();
				//System.out.println(index.get(calledFunc));
				//System.out.println(this.dividedProg.get("fak").size());
				for(int Insindex=index.get(fun.getName());Insindex<this.dividedProg.get(fun.getName()).size()+index.get(fun.getName());Insindex++)
				{
					if(this.Program.get(Insindex) instanceof Ldi)
					{//System.out.println("Index: "+Insindex);
						Ldi tmp= (Ldi) this.Program.get(Insindex);
						if(tmp.equals(new Ldi(Integer.MIN_VALUE)))
						{
							tmp.setImme(index.get(calledFunc));
						}
					}
				}
			
			});
		}
			}
	}
	private String aktuelleFunc;
	private Stack<String> letzteFunc; // im Call Block behandeln
	private Map<String,ArrayList<String>> lokalVariable;
	private Map<String,ArrayList<String>> FuncPara;
	@Override
	public void visit(Function f) throws CodeGenException{
	
			if (this.visitedProgram.getFunctionOfName(f.getName())==null)
				throw new UnbekannteFunktionException();
			
			Stack<Integer> returnNum=new Stack<Integer>();
			//System.out.println(f.getName()+"  "+f.numOfReturn());
			int retNum =f.numOfReturn();
			for(int i=0;i<retNum;i++) {
				//System.out.println(f.getName()+"  "+retNum);
				returnNum.push(1);
			}
			this.returnMap.put(f.getName(), returnNum);
		    ArrayList<Call> callList= new ArrayList<Call>();
		    ArrayList<Instruction> ins=new ArrayList<Instruction>();
	        aktuelleFunc=f.getName(); 	
	        //System.out.println("aktuelleFunc in visit: "+aktuelleFunc);
	        callmap.put(aktuelleFunc, callList);
	        this.dividedProg.put(aktuelleFunc, ins);
	        ArrayList<String > para= new ArrayList<String>();
	        for(String i:f.getParameters()) {
	        	para.add(i);
	        }
	        this.FuncPara.put(f.getName(), para);
	        
		    int declNum=0;
		    ArrayList<String> variable= new ArrayList<String>();
		    for(Declaration i: f.getDeclarations())
		    {
		    	declNum+=i.getNames().length;
		    	for(String j: i.getNames())
		    	{
		    		variable.add(j);
		    	}
		    }
		    lokalVariable.put(f.getName(), variable);
			this.dividedProg.get(this.aktuelleFunc).add(new Decl(declNum));
			
			for(Statement stmt: f.getStatements())
				visit(stmt);
			
			
			if(f.getName().equals("main")) {
				this.dividedProg.get("main").add(new Halt());
			}
		
		/*int ParaNum=f.getParameters().length;
		for(String i: f.getParameters())
		{
			this.Program.add(new In());
		}
		this.Program.add(new Ldi(0));//platzhalter , spaeter behandeln
		this.Program.add(new aufgabe9_6.Call(ParaNum));*/
		
	
	
		
		}

	@Override
	public void visit(Declaration declaration) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Assignment tmp) throws CodeGenException{
		// TODO Auto-generated method stub
		
		
			String name=tmp.getName();
			if(!lokalVariable.get(aktuelleFunc).contains(name)&&
					!this.FuncPara.get(aktuelleFunc).contains(name))
				throw new VariableNichtDeklariertException();
		visit(tmp.getExpression());
		//int index=this.lokalVariable.get(aktuelleFunc).indexOf(tmp.getName());
		//this.dividedProg.get(this.aktuelleFunc).add(new Sts(index+1));
		
		if(lokalVariable.get(aktuelleFunc).contains(name))
		{
		
		int index=lokalVariable.get(aktuelleFunc).indexOf(name);
		this.dividedProg.get(this.aktuelleFunc).add(new Sts(index+1));
		virtuelleStack.push(name);
		}
		
		
		if(this.FuncPara.get(aktuelleFunc).contains(name)) {
			double mid=((double)FuncPara.get(aktuelleFunc).size()-1)/2.0;
			int index=(int) (2*mid-FuncPara.get(aktuelleFunc).indexOf(name));
			this.dividedProg.get(this.aktuelleFunc).add(new Sts(-index));
			virtuelleStack.push(name);
		}
		this.virtuelleStack.pop();
	
		
		
	}
	@Override
	public void visit(Composite composite) {
		// TODO Auto-generated method stub
		for(Statement stmt:composite.getStatements())
			visit(stmt);
	}

	@Override
	public void visit(IfThen ifthen) {
		// TODO Auto-generated method stub
		visit(ifthen.getCond());
		this.dividedProg.get(aktuelleFunc).add(new Not());
		Brc brc=new Brc(0);
		this.dividedProg.get(aktuelleFunc).add(brc);
		visit(ifthen.getThenBranch());
		brc.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
	}

	@Override
	public void visit(IfThenElse ifthenelse) {
		// TODO Auto-generated method stub
		visit(ifthenelse.getCond())	;
		this.dividedProg.get(aktuelleFunc).add(new Not());
		Brc brc0 =new Brc(0);
		this.dividedProg.get(aktuelleFunc).add(brc0);
		visit(ifthenelse.getThenBranch());
		Brc brc1 = new Brc(0);
		this.dividedProg.get(aktuelleFunc).add(brc1);
		brc0.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
		visit(ifthenelse.getElseBranch());
		brc1.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
	}

	@Override
	public void visit(While whi) {
		// TODO Auto-generated method stub
		if(!whi.isDowhile())
		{
		int pointer = this.dividedProg.get(aktuelleFunc).size();
		visit(whi.getCon());
		this.dividedProg.get(aktuelleFunc).add(new Not());
		Brc brc = new Brc(0);
		this.dividedProg.get(aktuelleFunc).add(brc);
		visit(whi.getBody());
		brc.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
		this.dividedProg.get(aktuelleFunc).add(new Ldi(-1));
		this.dividedProg.get(aktuelleFunc).add(new Brc(pointer));
		}
		else {
			int pointer =this.dividedProg.get(aktuelleFunc).size();
			visit(whi.getBody());
			visit(whi.getCon());
			this.dividedProg.get(aktuelleFunc).add(new Brc(pointer));
		}
	}

	@Override
	public void visit(Return return1) {// nicht sicher!!
		// TODO Auto-generated method stub
		visit(return1.getExpression());
		this.returnMap.get(aktuelleFunc).pop();
		if(!aktuelleFunc.equals("main"))
		{
		int num=this.FuncPara.get(aktuelleFunc).size()+this.lokalVariable.get(aktuelleFunc).size();
		this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Return(num));
		}
		if(!letzteFunc.empty()&&this.returnMap.get(aktuelleFunc).empty())
		aktuelleFunc=letzteFunc.pop();
		//else System.out.println("letzteFunc is empty ,cant pop!! Line:198");
	}

	@Override
	public void visit(ExpressionStatement tmp) {
		// TODO Auto-generated method stub
	
		visit(tmp.getExpression());
	}

	/*private  boolean isInStack(String var) {
		if(virtuelleStack.indexOf(var)!=-1) return true;
		return false;
	}*/
	@Override
	public void visit(Variable var) {//???
		// TODO Auto-generated method stub
		
		
		if(lokalVariable.get(aktuelleFunc).contains(var.getName()))
		{
		String name=var.getName();
		int index=lokalVariable.get(aktuelleFunc).indexOf(name);
		this.dividedProg.get(this.aktuelleFunc).add(new Lfs(index+1));
		virtuelleStack.push(var.getName());
		}
		
		
		if(this.FuncPara.get(aktuelleFunc).contains(var.getName())) {
			String name=var.getName();
			double mid=((double)FuncPara.get(aktuelleFunc).size()-1)/2.0;
			int index=(int) (2*mid-FuncPara.get(aktuelleFunc).indexOf(name));
			this.dividedProg.get(this.aktuelleFunc).add(new Lfs(-index));
			virtuelleStack.push(var.getName());
		}
	}

	@Override
	public void visit(Number num) {
		// TODO Auto-generated method stub
		this.dividedProg.get(this.aktuelleFunc).add(new Ldi(num.getValue()));
		virtuelleStack.push(Integer.toString(num.getValue()));
	}

	@Override
	public void visit(Binary binary) {//?
		// TODO Auto-generated method stub
		visit(binary.getRhs());
		visit(binary.getLhs());
		/*if((binary.getLhs() instanceof Variable || binary.getLhs() instanceof Number)
				&&
				(binary.getRhs() instanceof Variable || binary.getRhs() instanceof Number)) {
			
			if(binary.getLhs() instanceof Variable) 
			{
				if(!virtuelleStack.peek().equals(((Variable)binary.getLhs()).getName()))
				{
					this.exchange();
				}
			}
			if(binary.getLhs() instanceof Number)
			{
				Number tmp =(Number) binary.getLhs();
				if(!virtuelleStack.peek().equals(Integer.toString(tmp.getValue())))
						{
					      this.exchange();
						}
			}
		}*/
		
		switch(binary.getOperator()) {
		case Minus:this.dividedProg.get(this.aktuelleFunc).add(new Sub());break;
		case DivisionOperator:this.dividedProg.get(this.aktuelleFunc).add(new Div());break;
			
		case Modulo:this.dividedProg.get(this.aktuelleFunc).add(new Mod());
			break;
		case MultiplicationOperator:this.dividedProg.get(this.aktuelleFunc).add(new Mul());
			break;
		case Plus:this.dividedProg.get(this.aktuelleFunc).add(new Add());
			break;
		}
			
	}

	/*private void exchange() {
		// TODO Auto-generated method stub
		this.Program.add(new Pop(0));
		this.Program.add(new Pop(1));
		this.Program.add(new Push(0));
		this.Program.add(new Push(1));
		String tmp0 ,tmp1;
		tmp0=this.virtuelleStack.pop();
		tmp1=this.virtuelleStack.pop();
		this.virtuelleStack.push(tmp0);
		this.virtuelleStack.push(tmp1);
	}*/
	@Override
	public void visit(Unary unary) {
		// TODO Auto-generated method stub
		visit(unary.getOperand());
		switch(unary.getOperator()) {
		case Minus:
			this.dividedProg.get(this.aktuelleFunc).add(new Ldi(-1)); 
			this.dividedProg.get(this.aktuelleFunc).add(new Mul());
			break;
		default:
			break;
		
		}
		
	}

	@Override
	public void visit(Read read) {
		// TODO Auto-generated method stub
		this.dividedProg.get(this.aktuelleFunc).add(new In());
		
	}

	@Override
	public void visit(Write write) {
		// TODO Auto-generated method stub
		visit(write.getExpression());
		this.dividedProg.get(this.aktuelleFunc).add(new Out());
		
	}

	private int platzhalter=Integer.MIN_VALUE;
	private HashMap<String,ArrayList<Call>> callmap;
	@Override
	public void visit(Call call) {
		// TODO Auto-generated method stub
	
		//System.out.println("aktuelleFunc : "+this.aktuelleFunc);
		callmap.get(aktuelleFunc).add(call);
		
		//letzteFunc.push(aktuelleFunc);
		for(Expression e:call.getArguments()) {
			visit(e);
		}
		
		this.dividedProg.get(this.aktuelleFunc).add(new Ldi(platzhalter));
		this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Call(call.getArguments().length));
		if(!call.getFunctionName().equals(aktuelleFunc))
		{//System.out.println("calledFunc:"+call.getFunctionName()+"  aktuelleFunc: "+aktuelleFunc);
			letzteFunc.push(aktuelleFunc);
		    this.visit(this.visitedProgram.getFunctionOfName(call.getFunctionName()));
		}
	}

	@Override
	public void visit(True true1) {
		// TODO Auto-generated method stub
		this.dividedProg.get(this.aktuelleFunc).add(new Ldi(-1));
		this.virtuelleStack.push(Integer.toString(-1));
	}

	@Override
	public void visit(False false1) {
		// TODO Auto-generated method stub
		this.dividedProg.get(this.aktuelleFunc).add(new Ldi(0));
		this.virtuelleStack.push(Integer.toString(0));
		
	}

	@Override
	public void visit(BinaryCondition bC) {
		// TODO Auto-generated method stub
	
		switch(bC.getOperator()) {
		case And:
			visit(bC.getLhs());
			visit(bC.getRhs());
			this.dividedProg.get(aktuelleFunc).add(new And());
			break;
		case Or:
			visit(bC.getLhs());
			visit(bC.getRhs());
			this.dividedProg.get(aktuelleFunc).add(new Or());
			break;
		default:
			break;
		
		}
	}

	@Override
	public void visit(Comparison cmp) {
		// TODO Auto-generated method stub
		
		switch(cmp.getOperator()) {
		case Equals:
			visit(cmp.getRhs());
			visit(cmp.getLhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.Equals));
			break;
		case Greater:
			visit(cmp.getLhs());
			visit(cmp.getRhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.LessThan));
			break;
		case GreaterEqual:
			visit(cmp.getRhs());
			visit(cmp.getLhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.LessThan));
			this.dividedProg.get(aktuelleFunc).add(new Not());
			break;
		case Less:
			visit(cmp.getRhs());
			visit(cmp.getLhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.LessThan));
			break;
		case LessEqual:
			visit(cmp.getLhs());
			visit(cmp.getRhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.LessThan));
			this.dividedProg.get(aktuelleFunc).add(new Not());
			break;
		case NotEquals:
			visit(cmp.getRhs());
			visit(cmp.getLhs());
			this.dividedProg.get(this.aktuelleFunc).add(new aufgabe9_6.Cmp(Operator.Equals));
			this.dividedProg.get(aktuelleFunc).add(new Not());
			break;
		default:
			break;
		
		}
	}
	@Override
	public void visit(UnaryCondition uC) {
		// TODO Auto-generated method stub
		visit(uC.getOperand());
		this.dividedProg.get(aktuelleFunc).add(new Not());
	}
	@Override
	public void visit(Expression exp) {
		// TODO Auto-generated method stub
		if(exp instanceof Variable) this.visit((Variable)exp);
		if(exp instanceof Number) this.visit((Number)exp);
		if(exp instanceof Binary) this.visit((Binary)exp);
		if(exp instanceof Unary) this.visit((Unary)exp);
		if(exp instanceof Read) this.visit((Read)exp);
		if(exp instanceof Write) this.visit((Write)exp);
		if(exp instanceof Call) this.visit((Call)exp);
		
	}

	@Override
	public void visit(Condition cond) {
		// TODO Auto-generated method stub
		if(cond instanceof True) this.visit((True)cond);
		if(cond instanceof False) this.visit((False)cond);
		if(cond instanceof BinaryCondition) this.visit((BinaryCondition)cond);
		if(cond instanceof Comparison) this.visit((Comparison)cond);
		if(cond instanceof UnaryCondition) this.visit((UnaryCondition)cond);
		
	}
	private void visit(Statement stmt) {
		 
			if(stmt instanceof Assignment) visit((Assignment)stmt);
			if(stmt instanceof Composite) visit((Composite)stmt);
			if(stmt instanceof IfThen) visit((IfThen)stmt);
			if(stmt instanceof IfThenElse) visit((IfThenElse)stmt);
			if(stmt instanceof While) visit((While)stmt);
			if(stmt instanceof Return) visit((Return)stmt);
			if(stmt instanceof ExpressionStatement) visit((ExpressionStatement)stmt);
			if(stmt instanceof Switch) visit((Switch)stmt);
			if(stmt instanceof Break) visit ((Break)stmt);
			
			
	}
	//private String aktuelleSwitch;
	@Override
	public void visit(Switch swi) {
		// TODO Auto-generated method stub
		//String name = swi.getSwitchExpression().toString();
		//this.switchStack.push(name);
		//this.aktuelleFunc=name;
		//this.casedMap.put(name, false);
		for(int i=0;i<swi.getCases().length;i++)
		{
			SwitchCase Case= swi.getCases()[i];
			
			if(i==0)
			{
			visit(swi.getSwitchExpression());
			visit(Case.getNumber());
			this.dividedProg.get(aktuelleFunc).add(new Cmp(Operator.Equals));
			this.dividedProg.get(aktuelleFunc).add(new Not());
			Brc brc=new Brc(platzhalter);//wenn die bedingung nicht erfuellt ist ,spring zu naechsten case;
			this.dividedProg.get(aktuelleFunc).add(brc);
			
			visit(Case.getCaseStatement());
			this.dividedProg.get(aktuelleFunc).add(new Ldi(-1));
			Brc tmp= new Brc(0);//wenn kein Break gibts,spring zu naechsten case statement ohne Auswerten der naechsten bedingung 
		    brcList.add(tmp);
			this.dividedProg.get(aktuelleFunc).add(tmp);
			brc.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
			}
			else if(i!=swi.getCases().length-1)
			{
				visit(swi.getSwitchExpression());
				visit(Case.getNumber());
				this.dividedProg.get(aktuelleFunc).add(new Cmp(Operator.Equals));
				this.dividedProg.get(aktuelleFunc).add(new Not());
				Brc brc=new Brc(platzhalter);
				this.dividedProg.get(aktuelleFunc).add(brc);
				
				brcList.get(i-1).setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
				
				visit(Case.getCaseStatement());
				this.dividedProg.get(aktuelleFunc).add(new Ldi(-1));
				Brc tmp= new Brc(0);
			    brcList.add(tmp);
				this.dividedProg.get(aktuelleFunc).add(tmp);
				brc.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());	
			}
			else
			{
				visit(swi.getSwitchExpression());
				visit(Case.getNumber());
				this.dividedProg.get(aktuelleFunc).add(new Cmp(Operator.Equals));
				this.dividedProg.get(aktuelleFunc).add(new Not());
				Brc brc=new Brc(platzhalter);
				this.dividedProg.get(aktuelleFunc).add(brc);
				
				brcList.get(i-1).setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
				
				visit(Case.getCaseStatement());
				brc.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());	
			}
		}
		visit(swi.getDefault());
		
		this.dividedProg.get(aktuelleFunc).stream().filter(i-> i instanceof Brc  ).forEach(i->
		{
			Brc tmp = (Brc )i;
			if(tmp.getIndexOfInstruction()==Integer.MAX_VALUE) {// for break
				tmp.setIndexOfInstruction(this.dividedProg.get(aktuelleFunc).size());
			}
		});
	}
	@Override
	public void visit(Break br) {
		// TODO Auto-generated method stub
		this.dividedProg.get(aktuelleFunc).add(new Ldi(-1));
		this.dividedProg.get(aktuelleFunc).add(new Brc(Integer.MAX_VALUE));
		
	}
	
}
