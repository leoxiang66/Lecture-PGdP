
public class SwitchCase {
	private Number num;
	private Statement CaseStatement;
	public Number getNumber() {
		return this.num;
	}
	public Statement getCaseStatement() {
		return this.CaseStatement;
	}
	public SwitchCase(Number num,Statement CaseStatement ) {
		this.num=num;
		this.CaseStatement=CaseStatement;
	}

}
