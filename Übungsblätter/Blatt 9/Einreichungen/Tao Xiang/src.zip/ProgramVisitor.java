
public interface ProgramVisitor {

	public  abstract void visit(UnaryCondition unaryCondition);

	abstract void visit(Program pro);

	abstract void visit(Function function);

	 abstract void visit(Declaration declaration);

	public abstract void visit(Assignment assignment);

	public abstract void visit(Composite composite);

	public abstract void visit(IfThen ifThen);

	public abstract void visit(IfThenElse ifThenElse);

	public abstract void visit(While while1);

	public abstract void visit(Return return1);

	public abstract void visit(ExpressionStatement expressionStatement);

	
	abstract void visit (Variable variable);
	abstract void visit (Number num);

	public abstract void visit(Binary binary);

	public abstract void visit(Unary unary);

	public abstract void visit(Read read);

	public abstract void visit(Write write);

	public abstract void visit(Call call);

	public abstract void visit(True true1);

	public abstract void visit(False false1);

	public abstract void visit(BinaryCondition binaryCondition);

	public abstract void visit(Comparison comparison);
	public abstract void visit(Expression exp);
	public abstract void visit(Condition cond);
	public abstract void visit(Switch switch0);
	public abstract void visit(Break break0);

}
