
public class Function {
	private String Name;
	private String[] Parameters;
	private Declaration[] Declarations;
	private Statement[] Statements;
	private int numOfReturn=0;
	
	public String getName()
	{
		return this.Name;
	}
	public String[] getParameters()
	{
		return this.Parameters;
	}
	public Declaration[] getDeclarations()
	{
		return this.Declarations;
	}
	public Statement[] getStatements()
	{
		return this.Statements;
	}
	public Function(String name,String[] parameters,Declaration[] declarations,Statement[] statements)
	{
		this.Name=name;
		this.Parameters=parameters;
		this.Declarations=declarations;
		this.Statements=statements;
	}

	private void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
	private void computeNumOfReturn(Statement stmt) {
		if(stmt instanceof Return)
			numOfReturn++;
		if(stmt instanceof Composite)
		{
			Composite tmp = (Composite) stmt;
			for(Statement temp: tmp.getStatements())
				this.computeNumOfReturn(temp);
		}
		if(stmt instanceof IfThen)
			this.computeNumOfReturn(((IfThen)stmt).getThenBranch());
		if(stmt instanceof IfThenElse)
		{
			this.computeNumOfReturn(((IfThenElse)stmt).getThenBranch());
			this.computeNumOfReturn(((IfThenElse)stmt).getElseBranch());
		}
		if(stmt instanceof While)
			this.computeNumOfReturn(((While)stmt).getBody());
	}
	public int numOfReturn() {
		for(Statement stmt:this.Statements) {
			this.computeNumOfReturn(stmt);
		}
		return this.numOfReturn;
	}
}
