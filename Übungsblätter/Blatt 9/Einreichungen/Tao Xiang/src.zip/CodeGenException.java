
public class CodeGenException extends RuntimeException{

}
