
public class Read extends Expression{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "read()";
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
	

}
