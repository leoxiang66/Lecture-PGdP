
public class Declaration {

	private String[] Names;
	public String[] getNames()
	{
		return this.Names;
	}
	public Declaration(String[] names) {
		this.Names=names;
	}
	/*public Declaration() {
		this.Names=null;
	}*/
	private void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
}
