

public enum Bunop {
  Not
}
