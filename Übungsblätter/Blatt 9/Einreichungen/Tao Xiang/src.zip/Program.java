
public class Program {
	public void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}
	public Function getFunctionOfName(String funcName) {
		for(Function f: this.functions)
		{
			if(f.getName().equals(funcName))
				return f;
		}
		System.out.println("no such function in this program!!");
		return null;
	}

	private Function[] functions;
	public Function[] getFunctions()
	{
		return this.functions;
	}
	Program(Function[] functions){
		this.functions=functions;
	}
	
}
