
public abstract class Condition {
	public abstract String toString();
	abstract void accept(ProgramVisitor visitor);

}
