
public class ExpressionStatement extends Statement {
	private Expression expression;
	public Expression getExpression() {
		return this.expression;
	}
	public ExpressionStatement(Expression exp) {
		this.expression=exp;
	}
	void accept(ProgramVisitor visitor) {
		visitor.visit(this);
	}

}
