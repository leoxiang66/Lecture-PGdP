package aufgabe9_6;

public class Sts extends Instruction{

	private int i;
	public int getParaOrVariaNumber() {
		return this.i;
	}
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Sts(int i) {
		this.i=i;
	}
	public String toString() {
		return "Sts "+this.i;
	}

}
