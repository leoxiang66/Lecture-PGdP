package aufgabe9_6;

public class Cmp extends Instruction{

	
	private Operator op;
	public Operator getOperator() {
		return this.op;
	}
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Cmp(Operator op) {
		this.op=op;
	}
	public String toString() {
		return "Cmp "+this.op;
	}

}
