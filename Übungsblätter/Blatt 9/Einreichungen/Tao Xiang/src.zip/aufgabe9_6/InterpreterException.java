package aufgabe9_6;

public class InterpreterException extends RuntimeException {

}
