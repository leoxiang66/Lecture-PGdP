package aufgabe9_6;
import java.util.Stack;

public class Interpreter implements AsmVisitor{
	private miniStack<Integer> stack;
	private int r0=0;
	private int r1=0;
	private int pc=0;
	private int fp=-1;
	private int sp=-1;
	private Instruction[] instructions;
	
	public int getPC() {
		return this.pc;
	}
	public int getFP() {
		return fp;
	}
	
	public int getRegister0() {
		return this.r0;
	}
	public int getRegister1() {
		return this.r1;
	}

	private boolean exceptioned=false;
	public Interpreter(Instruction[] instructions) {
		stack=new miniStack<Integer>();
		//LengthOfInstructionArray=instructions.length;
		
		this.instructions=instructions;
		
	}
	public int execute() {// return the stacktop
		while(pc<instructions.length)
		{
			if(exceptioned)
			{
				System.out.println("Instruction"+(pc-1)+" exceptioned");
				exceptioned=false;
			}
			/*
			if(stack.getSizeFrom0()!=0) {
				System.out.println("pc: "+(pc)+"		sp:  "+sp);
				System.out.print("fp:  "+fp+"\t\t");
				System.out.println("st: "+stack.getLastElement().getValue()+"\n");
				System.out.println("\n");
				
			}
			*/
			pc++;
		
			
			this.visit(instructions[pc-1]);
		}	
		
		if(stack.getLastElement()!=null)
		 return stack.getLastElement().getValue() ;
		return 0;
	}
	@Override
	public void visit(Add add) throws InterpreterException {//??
		
		// TODO Auto-generated method stub
		
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()+stack.pop().getValue()));
				sp--;
			

		
		

		
		
	}

	@Override
	public void visit(Sub sub) throws InterpreterException {
		// TODO Auto-generated method stub
	
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()-stack.pop().getValue()));
				sp--;
			
		
		
		
	}

	@Override
	public void visit(Mul mul) throws InterpreterException{
		// TODO Auto-generated method stub
	
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()*stack.pop().getValue()));
				sp--;
			
		
		
	}

	@Override
	public void visit(Mod mod) throws InterpreterException {
		// TODO Auto-generated method stub
		
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()%stack.pop().getValue()));
				sp--;
			
		
		
	}

	@Override
	public void visit(Div div) throws InterpreterException{
		// TODO Auto-generated method stub
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()/stack.pop().getValue()));
				sp--;
			
	
		
	}

	@Override
	public void visit(And and) throws InterpreterException{
		// TODO Auto-generated method stub
		
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()&stack.pop().getValue()));
				sp--;
			
		
		
	}

	@Override
	public void visit(Or or) throws InterpreterException{
		// TODO Auto-generated method stub
		
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(stack.pop().getValue()|stack.pop().getValue()));
				sp--;
			
		
		
	}

	@Override
	public void visit(Not not) throws InterpreterException{
		// TODO Auto-generated method stub
		
			if(stack.getSizeFrom0()<1) throw new NotEnoughElementsInStackException();
			
				stack.push(new StackElement<Integer>(~stack.pop().getValue()));
				
			
		
		
		
	}

	@Override
	public void visit(Ldi ldi) {
		// TODO Auto-generated method stub
		stack.push(new StackElement<Integer>(ldi.getImme()));
		sp++;
		
		;
		
	}

	@Override
	public void visit(Lfs lfs) throws InterpreterException{
		// TODO Auto-generated method stub
		
			int number=lfs.getParaOrVariaNumber();
		if(number>0) {
			int fp = -this.sum(temp, 0);
			if(number>stack.getSizeFromMinus1())throw new StackIndexOutOfBoundException();
			stack.push(new StackElement<Integer>(stack.getStackElement(fp-number).getValue()));
			sp++;
		}
		else {
			//System.out.println("fp: "+fp+"  number: "+number);
			if((fp+number)<0) throw new StackIndexOutOfBoundException();
			//System.out.println(fp+number);
			stack.push(new StackElement<Integer>(stack.getStackElement(number+fp).getValue()));
			sp++;
		}		
		
	
		
	}

	@Override
	public void visit(Sts sts) throws InterpreterException{
		// TODO Auto-generated method stub
		
			
			int number=sts.getParaOrVariaNumber();
			if(number>0) {
				int fp = this.sum(temp, 0);
				if(number>stack.getSizeFromMinus1())throw new StackIndexOutOfBoundException();
				stack.getStackElement(fp-number).setValue(stack.pop().getValue());;
				sp--;
			}
			else {
				if(fp+number<0) throw new StackIndexOutOfBoundException();
				stack.getStackElement(fp+number).setValue(stack.pop().getValue());
				sp--;
			}		

			
			
		
	
		
	}

	@Override
	public void visit(Brc brc) throws InterpreterException{
		// TODO Auto-generated method stub
		
			if(stack.isEmpty()) throw new NotEnoughElementsInStackException();
			int index =brc.getIndexOfInstruction();
			if(index<0||index>=this.instructions.length)
				throw new ArrayIndexOutOfBoundsException();
			 
				if(stack.pop().getValue()==-1)
					pc=brc.getIndexOfInstruction();	
				sp--;
		
		
		
		
	}

	@Override
	public void visit(Cmp cmp) throws InterpreterException{
		// TODO Auto-generated method stub
		
			sp--;
			if(stack.getSizeFrom0()<2) throw new NotEnoughElementsInStackException();
			
			if(cmp.getOperator().equals(Operator.Equals)) {
				if(stack.pop().getValue()==stack.pop().getValue())
				{
					stack.push(new StackElement<Integer>(-1));
				}
				else {
					stack.push(new StackElement<Integer>(0));
				}
				
			}
			else {
				if(stack.pop().getValue()<stack.pop().getValue())
				{
					stack.push(new StackElement<Integer>(-1));
				}
				else {
					stack.push(new StackElement<Integer>(0));
				}
			}		
	
		
	}

	@Override
	public void visit(Nop nop) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Call call) throws InterpreterException {
		// TODO Auto-generated method stub
		
			if(!declared) {
				temp.push(0);
				//System.out.println("hi");
			}
			if(stack.getSizeFrom0()<call.getNumberOfArguments()+1) throw new NotEnoughElementsInStackException();
			int tmp =pc;
			pc=stack.pop().getValue();
			stack.push(new StackElement<Integer>(tmp));
			stack.push(new StackElement<Integer>(fp));
			sp++;
			fp=sp-2;
			declared=false;

			//System.out.println(fp);
			
			
	
		
		
		
	}

	@Override
	public void visit(Decl decl) {
		// TODO Auto-generated method stub
		declared =true;
		temp.push(decl.getNumberOfReservedPlaces());
		for(int i=0;i<decl.getNumberOfReservedPlaces();i++)
		{
			stack.pushInReverseDirection(new StackElement<Integer>(0));   
		}
		
	}

	private Stack<Integer> temp = new Stack<Integer>();
	private boolean declared=false;
	private int sum(Stack<Integer> stack,int index) {
		if(index<stack.size()-1)
			return stack.get(index)+sum(stack,index+1);
		return 0;
	}
	@Override
	public void visit(Return return1) {
		// TODO Auto-generated method stub
		
		int tmp=stack.pop().getValue();
		fp=stack.pop().getValue();
		pc=stack.pop().getValue();
		int tmp2=temp.pop();
		//System.out.println("temp.pop: "+tmp2);
		for(int i=0;i<return1.getSumOfLocalVariableAndFunctionParameter()-tmp2;i++)
		{
			stack.pop();
		}
		for(int i=0;i<tmp2;i++)
		{
			stack.popInReverseDirection();
		}
		stack.push(new StackElement<Integer>(tmp));  //???
		sp=sp-2-return1.getSumOfLocalVariableAndFunctionParameter()+tmp2;
		
		/*while(stack.getSizeFrom0()!=0)
		{
			stack.pop();    
		}
		
		while(stack.getSizeFromMinus1()!=0) {
			stack.popInReverseDirection();
		}
		StackElement<Integer> hi = new StackElement<Integer>(tmp);
		hi.setIndex(0);
		hi.setNext(null);
		stack.clear();
		stack.push(hi);
		sp=0;*/
		
		
	}

	@Override
	public void visit(In in) {
		// TODO Auto-generated method stub
		sp++;
		stack.push(new StackElement<Integer>(Terminal.askInt("please input a number:\n>")));
		
	}

	@Override
	public void visit(Out out) {
		// TODO Auto-generated method stub
		sp--;
		//System.out.println(stack.getSizeFrom0());
		System.out.println(stack.pop().getValue());
		
	}

	@Override
	public void visit(Push push) {
		// TODO Auto-generated method stub
		sp++;
		if(push.getIndexOfRegister()==0)
		stack.push(new StackElement<Integer>(r0));
		else 
			stack.push(new StackElement<Integer>(r1));
		
	}

	@Override
	public void visit(Pop pop) {
		// TODO Auto-generated method stub
		sp--;
		if(pop.getIndexOfRegister()==0)
			r0=stack.pop().getValue();
		else r1=stack.pop().getValue();
		
	}

	@Override
	public void visit(Halt halt) {
		// TODO Auto-generated method stub
		while (stack.getSizeFromMinus1()!=0) {
			stack.popInReverseDirection();
		}
		pc=Integer.MAX_VALUE;    
		fp=-1;
		sp=-1;
		r0=0;
		r1=0;
		
	}

	@Override
	public void visit(Instruction tmp) {
		// TODO Auto-generated method stub
		if(tmp instanceof Add) this.visit((Add)tmp);
		if(tmp instanceof Sub) this.visit((Sub)tmp);
		if(tmp instanceof Mul) this.visit((Mul)tmp);
		if(tmp instanceof Mod) this.visit((Mod)tmp);
		if(tmp instanceof Div) visit((Div)tmp);
		if(tmp instanceof And) visit((And)tmp);
		if(tmp instanceof Or ) visit((Or)tmp);
		if(tmp instanceof Not) visit((Not)tmp);
		if(tmp instanceof Ldi) visit((Ldi)tmp);
		if(tmp instanceof Lfs) visit((Lfs)tmp);
		if(tmp instanceof Sts) visit((Sts)tmp);
		if(tmp instanceof Brc) visit((Brc)tmp);
		if(tmp instanceof Cmp) visit ((Cmp)tmp);
		if(tmp instanceof Nop) visit((Nop )tmp);
		if(tmp instanceof Call)visit((Call)tmp);
		if(tmp instanceof Decl) visit((Decl)tmp);
		if(tmp instanceof Return )visit((Return)tmp);
		if(tmp instanceof In)visit((In)tmp);
		if(tmp instanceof Out)visit	((Out)tmp);
		if(tmp instanceof Push )visit((Push)tmp);
		if(tmp instanceof Pop )visit((Pop)tmp);
		if(tmp instanceof Halt)visit((Halt)tmp);
		
	}

}
