package aufgabe9_6;

public  class Instruction {
	 void accept(AsmVisitor visitor) {
		 visitor.visit(this);
	}
}
