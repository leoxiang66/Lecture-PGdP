package aufgabe9_6;

public class StackElement<T>{
	private int index;
	private StackElement<T> next;
	private T value;
	
	public T getValue() {
		T ret=null;
		if(this!=null)
		ret= this.value;
		if(ret==null)
			System.out.println("NullPointer");
			
		return ret;
	}
	public void setValue(T value) {
		
		this.value=value;
	}
	public StackElement(T value){
		this.value=value;
		next=null;
	}
	public StackElement(StackElement<T> newElement) {
		next=newElement;
	}
	public void setIndex(int index) {
		this.index=index;
	}

	public int getIndex() {
		return this.index;
	}
	public StackElement<T> getNext() {
		return this.next;
	}
	public void setNext(StackElement<T> next) {
		this.next=next;
	}

}
