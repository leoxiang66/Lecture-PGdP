package aufgabe9_6;

public class Sub extends Instruction{

	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		
		visitor.visit(this);
	}
	public String toString() {
		return "Sub";
	}
}
