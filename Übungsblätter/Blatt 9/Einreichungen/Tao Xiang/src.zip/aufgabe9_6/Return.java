package aufgabe9_6;

public class Return extends Instruction{
	private int SumOfLocalVariableAndFunctionParameter;
	public int getSumOfLocalVariableAndFunctionParameter() {
		return this.SumOfLocalVariableAndFunctionParameter;
	}

	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Return(int n) {
		this.SumOfLocalVariableAndFunctionParameter=n;
	}
	public String toString() {
		return "Return "+this.SumOfLocalVariableAndFunctionParameter;
	}

}
