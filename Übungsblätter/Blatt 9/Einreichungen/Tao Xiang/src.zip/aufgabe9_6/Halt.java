package aufgabe9_6;

public class Halt extends Instruction{

	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public String toString() {
		return "Halt";
	}

}
