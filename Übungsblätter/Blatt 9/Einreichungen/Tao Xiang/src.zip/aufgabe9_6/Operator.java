package aufgabe9_6;

public enum Operator  {Equals,LessThan};


