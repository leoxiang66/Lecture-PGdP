package aufgabe9_6;

public class Push extends Instruction {

	private int indexOfRegister;
	public int getIndexOfRegister() {
		return this.indexOfRegister;
	}
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Push(int i) {
		if(i!=1&&i!=0)
		{
			System.out.println("wrong input,the index must be within 0,1");
			return;
		}
		this.indexOfRegister=i;
	}

	public String toString() {
		return "Push "+this.indexOfRegister;
	}
}
