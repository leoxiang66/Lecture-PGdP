package aufgabe9_6;

public class InterpreterTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//beispiel 1
		System.out.println("ggt:");
		In in0= new In();
		In in1 = new In();
		Ldi in2 = new Ldi(7);
		Call in3 = new Call(2);
		Out in4 = new Out();
		Ldi in5 = new Ldi(0);
		Halt in6 = new Halt();
		Decl in7 = new Decl(1);
		Lfs in8 = new Lfs(-1);
		Lfs in9 = new Lfs(0);
		Cmp in10 = new Cmp(Operator.LessThan);
		Brc in11 = new Brc (16);
		Lfs in12 = new Lfs(0);
		Lfs in13 = new Lfs(-1);
		Sts in14 = new Sts(0);
		Sts in15 = new Sts(-1);
		Lfs in16 = new Lfs(0);
		Sts in17 = new Sts(1);
		Lfs in18 = new Lfs( 0);
		Lfs in19 = new Lfs(-1);
		Mod in20 = new Mod();
		Sts in21 = new Sts(0);
		Lfs in22= new Lfs(1);
		Sts in23= new Sts(-1);
		Ldi in24 = new Ldi (0);
		Lfs in25= new Lfs(0);
		Cmp in26= new Cmp(Operator.Equals);
		Not in27= new Not();
		Brc in28 = new Brc(16);
		Lfs in29= new Lfs(-1);
		Return in30 = new Return(3);
		
		Instruction[] ins=new Instruction[] {in0,in1,in2,in3,in4,in5,in6,in7,in8,in9,in10,in11,in12,in13,in14,in15,in16,in17,in18,in19,in20,in21,in22,in23,in24,in25,in26,in27,in28,in29,in30};
		Interpreter interpreter= new Interpreter(ins);
		interpreter.execute();
		System.out.println();
		
//beispiel 2
		System.out.println("fak");
		In a0 = new In();
		Ldi a1 = new Ldi(6);
		Call a2= new Call(1);
		Out a3= new Out();
		Ldi a4= new Ldi(0);
		Halt a5= new Halt();
		Ldi a6= new Ldi(1);
		Lfs a7= new Lfs(0);
		Cmp a8= new Cmp( Operator.Equals);
		Not a9 = new Not();
		Brc a10 = new Brc(13);
		Ldi a11= new Ldi(1);
		Return a12= new Return(1);
		Ldi a13= new Ldi(1);
		Lfs a14= new Lfs(0);
		Sub a15= new Sub();
		Ldi a16= new Ldi(6);
		Call a17= new Call(1);
		Lfs a18 = new Lfs(0);
		Mul a19= new Mul();
		Return a20= new Return (1);
		Instruction[] ins2= new Instruction[] {a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19,a20};
		Interpreter int2=new Interpreter(ins2);
		int2.execute();
	}

}
