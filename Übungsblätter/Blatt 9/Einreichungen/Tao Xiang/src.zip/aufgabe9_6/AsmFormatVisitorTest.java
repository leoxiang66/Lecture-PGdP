package aufgabe9_6;

public class AsmFormatVisitorTest {
	 public static void main(String[] args) {
		 In in1=new In();
		 Ldi in2=new Ldi(13);
		 Call in3 =new Call(2);
		 Out in4=new Out();
		 Ldi in5 =new Ldi(0);
		 Halt in6=new Halt();
		 
		 Instruction[] ins =new Instruction[] {in1,in1,in2,in3,in4,in5,in6};
		 AsmFormatVisitor test =new AsmFormatVisitor(ins);
		 System.out.println(test.getFormattedCode());
		 
	 }
}
