package aufgabe9_6;

public class ArrayIndexOutOfBoundsException extends InterpreterException {
	public String toString () {
		return "ArrayIndexOutOfBoundsException:\n Instruction Array index out of bounds! ";
	}

}
