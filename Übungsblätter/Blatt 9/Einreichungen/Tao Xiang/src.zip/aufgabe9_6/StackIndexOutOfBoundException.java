package aufgabe9_6;

public class StackIndexOutOfBoundException extends InterpreterException {
	public String toString() {
		return "StackIndexOutOfBoundException:\nThe input index is out of bound of the stack index!";
	}

}
