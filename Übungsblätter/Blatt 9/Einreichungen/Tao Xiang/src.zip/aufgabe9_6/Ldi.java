package aufgabe9_6;

public class Ldi extends Instruction{

	private int imme;
	public int getImme() {
		return this.imme;
	}
	public void setImme(int index) {
		imme=index;
	}
	
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Ldi(int c) {
		imme=c;
		
	}
	public boolean equals(Ldi ldi)
	{
		return this.imme==ldi.imme;
	}
	public String toString() {
		return "Ldi "+this.imme;
	}

}
