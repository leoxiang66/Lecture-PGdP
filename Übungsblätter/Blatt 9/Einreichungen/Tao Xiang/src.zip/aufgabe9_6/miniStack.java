package aufgabe9_6;

public class miniStack<T> {
	private StackElement<T> first;
	private int sizeFrom0=0;
	private int sizeFromMinus1=0;
	
	
	public void clear() {
		this.first=null;
		this.sizeFrom0=0;
		this.sizeFromMinus1=0;
	}
	public boolean isEmpty() {
		return sizeFrom0==0;
	}
	public int getSizeFrom0() {
		return this.sizeFrom0;
	}
	public int getSizeFromMinus1() {
		return this.sizeFromMinus1;
	}
	public StackElement<T> getFirstElement() {
		return this.first;
	}
	public miniStack(StackElement<T> firstelement) {
		first=firstelement;
		first.setIndex(0);
		sizeFrom0++;
	}
	public int getLastIndex() {
		if(this.sizeFrom0>0)
		return this.sizeFrom0-1;
		return 0;
	}
	public miniStack() {
		
	}
	public StackElement<T> getLastElement(){
		if(sizeFrom0>0)
		return this.getStackElement(sizeFrom0-1);
		return null;
		
	}
	public StackElement<T> getStackElement(int index) throws InterpreterException{
		StackElement<T> ret=null;
		try {
			if(!(index>=-(this.sizeFromMinus1)&&index<=sizeFrom0-1))
				throw new StackIndexOutOfBoundException();
		
		
		if(index>=-(this.sizeFromMinus1)&&index<=sizeFrom0-1)
		{

			for(StackElement<T> tmp=this.first;tmp!=null;tmp=tmp.getNext()) {
				
				//System.out.println(tmp.getIndex());
				if(tmp.getIndex()==index)
					ret= tmp;
				
			}
		}
	}
		catch (StackIndexOutOfBoundException e) {
			System.out.println(e.toString());
		}
		return ret;
		
		}
	public void push(StackElement<T> newelement)
	{
		newelement.setIndex(sizeFrom0);
		if(sizeFrom0!=0)
		this.getLastElement().setNext(newelement);
		else {
			if(this.sizeFromMinus1==0)
			first=newelement;
			else {
				this.getStackElement(-1).setNext(newelement);
			}
		}
		sizeFrom0++;
	}
	public void pushInReverseDirection(StackElement<T> newelement)
	{
		sizeFromMinus1++;
		if(first!=null) {
		newelement.setIndex(-(sizeFromMinus1));
		newelement.setNext(first);
		first=newelement;}
		else {
			newelement.setIndex(-1);
			newelement.setNext(null);
			first=newelement;
		}
	}
	public StackElement<T> pop() {
		StackElement<T> ret=null;
		if(this.sizeFrom0>1)
		{//System.out.println("last element:"+this.getLastElement().getValue());
			ret=this.getLastElement();
			this.getStackElement(sizeFrom0-2).setNext(null);
			
			
			
		}
		if(this.sizeFrom0==1)
		{
			//System.out.println("last element:"+this.getLastElement().getValue());
			if(this.sizeFromMinus1!=0) {
			ret=this.getStackElement(0);
			this.getStackElement(-1).setNext(null);
			}
			else {
				//System.out.println("hello");
				ret=this.getStackElement(0);
				first=null;
			}
			//System.out.println(ret==null);
		}
		
		if(ret==null)
			System.out.println("sizeFrom0==0,cant pop");
		else this.sizeFrom0--;
		return ret;
	}
	public StackElement<T> popInReverseDirection() throws NotEnoughElementsInStackException
	{StackElement<T> ret=null;
		
		
		if(this.sizeFromMinus1>0) {
			ret=first;
			first=first.getNext();
			ret.setNext(null);
			this.sizeFromMinus1--;
		}
		if(ret==null)
			throw new NotEnoughElementsInStackException();
	
	
			return ret;
	}
	public void inset(StackElement<T> toinsert,int index) throws StackIndexOutOfBoundException
	{
		
			
		if(index>=-(this.sizeFromMinus1)&&index<=sizeFrom0-1&&index-1>=-(this.sizeFromMinus1)&&index-1<=sizeFrom0-1)
		{
		toinsert.setIndex(index);
		toinsert.setNext(this.getStackElement(index));

		this.getStackElement(index-1).setNext(toinsert);

		for(StackElement<T> tmp=toinsert.getNext();tmp!=null;tmp=tmp.getNext())
		{
			tmp.setIndex(tmp.getIndex()+1);
		}
	
		this.sizeFrom0++;
		}
		
		else throw new StackIndexOutOfBoundException();
		
		
		
		}
	

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackElement<Integer> first=new StackElement<Integer>(5);


		StackElement<Integer> tmp =new StackElement<Integer>(8);
		miniStack<Integer> stack=new miniStack<Integer>(first);
		stack.push(new StackElement<Integer>(3));
		/*System.out.println(stack.sizeFrom0);
		System.out.println(stack.getStackElement(1).getValue());
		System.out.println(stack.sizeFromMinus1);
		System.out.println(stack.getFirstElement().getValue());
		System.out.println(stack.getLastElement().getValue());
		//System.out.println(stack.getStackElement(0).getValue());
		
		stack.push(tmp);
		//System.out.println(stack.getStackElement(2).getValue());
		stack.inset(new StackElement<Integer>(9), 1);
		//System.out.println(stack.sizeFrom0);
		//System.out.println(stack.getLastElement().getValue());
		//System.out.println(stack.getStackElement(3).getValue());


		//System.out.println(stack.getStackElement(1).getNext().getValue());
		//System.out.println(stack.getStackElement(3).getValue());
		//System.out.println(stack.pop().getValue());
		//System.out.println(stack.getStackElement(2).getValue());
		stack.pushInReverseDirection(new StackElement<Integer>(88));
		//System.out.println(stack.sizeFromMinus1);
		//System.out.println(stack.getStackElement(3).getValue());
		//System.out.println(stack.popInReverseDirection().getValue());
		//System.out.println(stack.sizeFromMinus1);
		//System.out.println(stack.getStackElement(2).getValue());

	}*/

}
