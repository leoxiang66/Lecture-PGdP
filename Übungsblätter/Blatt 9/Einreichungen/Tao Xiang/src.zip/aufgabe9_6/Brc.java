package aufgabe9_6;

public class Brc extends Instruction {
	private int indexOfInstruction;

	public int getIndexOfInstruction() {
		return this.indexOfInstruction;
	}
	public void setIndexOfInstruction(int indexOfInstruction) {
		this.indexOfInstruction=indexOfInstruction;
	}
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Brc(int i) {
		this.indexOfInstruction=i;
	}
	public String toString() {
		return "Brc "+this.indexOfInstruction;
	}
	

}
