package aufgabe9_6;

public class Call extends Instruction{

	public int getNumberOfArguments() {
		return this.NumberOfArguments;
	}
	private int NumberOfArguments;
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
	visitor.visit(this);	
	}
	public Call(int n) {
		this.NumberOfArguments=n;
	}
	public String toString() {
		return "Call "+this.NumberOfArguments;
	}
	

}
