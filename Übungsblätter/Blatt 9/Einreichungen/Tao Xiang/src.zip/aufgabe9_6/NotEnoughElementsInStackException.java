package aufgabe9_6;

public class NotEnoughElementsInStackException extends InterpreterException {

	/**
	 * 
	 */
	
		public String toString() {
			return "NotEnoughElementsInStackException:\nThere are not enough elements in Stack for this operation!";
		}
		
}
