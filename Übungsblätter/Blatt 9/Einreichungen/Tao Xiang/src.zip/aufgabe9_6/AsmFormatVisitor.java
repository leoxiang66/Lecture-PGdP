package aufgabe9_6;


public class AsmFormatVisitor implements AsmVisitor {

	private String FormattedCode="";
	public String getFormattedCode() {
		return FormattedCode;
	}
	public AsmFormatVisitor(Instruction[] instructions) {
		for(int i=0;i<instructions.length;i++)
		{
			FormattedCode+=i+": ";
			this.visit(instructions[i]);// Zeileumbruch;
		}
	} 
	 public void visit(Instruction tmp) {
		// TODO Auto-generated method stub
		if(tmp instanceof Add) this.visit((Add)tmp);
		if(tmp instanceof Sub) this.visit((Sub)tmp);
		if(tmp instanceof Mul) this.visit((Mul)tmp);
		if(tmp instanceof Mod) this.visit((Mod)tmp);
		if(tmp instanceof Div) visit((Div)tmp);
		if(tmp instanceof And) visit((And)tmp);
		if(tmp instanceof Or ) visit((Or)tmp);
		if(tmp instanceof Not) visit((Not)tmp);
		if(tmp instanceof Ldi) visit((Ldi)tmp);
		if(tmp instanceof Lfs) visit((Lfs)tmp);
		if(tmp instanceof Sts) visit((Sts)tmp);
		if(tmp instanceof Brc) visit((Brc)tmp);
		if(tmp instanceof Cmp) visit ((Cmp)tmp);
		if(tmp instanceof Nop) visit((Nop )tmp);
		if(tmp instanceof Call)visit((Call)tmp);
		if(tmp instanceof Decl)visit((Decl)tmp);
		if(tmp instanceof Return )visit((Return)tmp);
		if(tmp instanceof In)visit((In)tmp);
		if(tmp instanceof Out)visit	((Out)tmp);
		if(tmp instanceof Push )visit((Push)tmp);
		if(tmp instanceof Pop )visit((Pop)tmp);
		if(tmp instanceof Halt)visit((Halt)tmp);
		
	}
	@Override
	public void visit(Add tmp) {
		// TODO Auto-generated method stub
		FormattedCode+="ADD\n";
		
		
	}

	@Override
	public void visit(Sub sub) {
		// TODO Auto-generated method stub
		FormattedCode+="SUB\n";
		
	}

	@Override
	public void visit(Mul mul) {
		// TODO Auto-generated method stub
		FormattedCode+="MUL\n";
	}

	@Override
	public void visit(Mod mod) {
		// TODO Auto-generated method stub
		FormattedCode+="MOD\n";
	}

	@Override
	public void visit(Div div) {
		// TODO Auto-generated method stub
		FormattedCode+="DIV\n";
	}

	@Override
	public void visit(And and) {
		// TODO Auto-generated method stub
		FormattedCode+="AND\n";
	}

	@Override
	public void visit(Or or) {
		// TODO Auto-generated method stub
		FormattedCode+="OR\n";
	}

	@Override
	public void visit(Not not) {
		// TODO Auto-generated method stub
		FormattedCode+="NOT\n";
	}

	@Override
	public void visit(Ldi ldi) {
		// TODO Auto-generated method stub
		FormattedCode+="LDI "+ldi.getImme()+"\n";
		
	}

	@Override
	public void visit(Lfs lfs) {
		// TODO Auto-generated method stub
		FormattedCode+="LFS "+lfs.getParaOrVariaNumber()+"\n";
	}

	@Override
	public void visit(Sts sts) {
		// TODO Auto-generated method stub
		FormattedCode="STS "+sts.getParaOrVariaNumber()+"\n";
		
	}

	@Override
	public void visit(Brc brc) {
		// TODO Auto-generated method stub
		FormattedCode+="BRC "+brc.getIndexOfInstruction()+"\n";
		
	}

	@Override
	public void visit(Cmp cmp) {
		// TODO Auto-generated method stub
		if(cmp.getOperator().equals(Operator.Equals))
		{
 
			FormattedCode+="CMP EQUALS\n";
			return;
		}
		FormattedCode+="CMP LESS\n";
		
		
	}

	@Override
	public void visit(Nop nop) {
		// TODO Auto-generated method stub


		FormattedCode+="NOP\n";
	}

	@Override
	public void visit(Call call) {
		// TODO Auto-generated method stub

		FormattedCode+="CALL "+call.getNumberOfArguments()+"\n";
		
	}

	@Override
	public void visit(Decl decl) {
		// TODO Auto-generated method stub

		FormattedCode+="DECL "+decl.getNumberOfReservedPlaces()+"\n";
		
	}

	@Override
	public void visit(Return return1) {
		// TODO Auto-generated method stub

		FormattedCode+="RETURN "+return1.getSumOfLocalVariableAndFunctionParameter()+"\n";
	}

	@Override
	public void visit(In in) {
		// TODO Auto-generated method stub

		FormattedCode+="IN\n";
		
	}

	@Override
	public void visit(Out out) {
		// TODO Auto-generated method stub

		FormattedCode+="OUT\n";
		
	}

	@Override
	public void visit(Push push) {
		// TODO Auto-generated method stub

		FormattedCode+="PUSH "+push.getIndexOfRegister()+"\n";
		
	}

	@Override
	public void visit(Pop pop) {
		// TODO Auto-generated method stub

		FormattedCode+="POP "+pop.getIndexOfRegister()+"\n";
		
	}

	@Override
	public void visit(Halt halt) {
		// TODO Auto-generated method stub

		FormattedCode+="HALT\n";
		
	}

}
