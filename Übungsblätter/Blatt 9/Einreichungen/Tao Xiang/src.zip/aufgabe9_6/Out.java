package aufgabe9_6;

public class Out extends Instruction {

	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public String toString() {
		return "Out";
	}
}
