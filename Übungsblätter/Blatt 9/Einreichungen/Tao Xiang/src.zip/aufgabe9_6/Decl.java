package aufgabe9_6;

public class Decl extends Instruction{

	public int getNumberOfReservedPlaces() {
		return this.numberOfReservedPlaces;
	}
	private int numberOfReservedPlaces;
	@Override
	void accept(AsmVisitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}
	public Decl(int n) {
		this.numberOfReservedPlaces=n;
	}
	public String toString() {
		return "Decl "+this.numberOfReservedPlaces;
	}

}
