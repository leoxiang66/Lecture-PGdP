import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.TreeMap;
import java.util.stream.IntStream;

public class WebserverThread extends Thread{
	private Socket client;
	private LinkedDocumentCollection ldc;
	private TemplateProcessor tp;
	public WebserverThread(Socket client ,LinkedDocumentCollection ldc, TemplateProcessor tp) {
		// TODO Auto-generated constructor stub
		this.client=client;
		this.ldc=ldc;
		this.tp=tp;
	}
	
	
	private  HttpResponse handleMainPage() {
	    TreeMap<String, String> varass = new TreeMap<>();
	    varass.put("%value", "");
	    varass.put("%results", "");
	    String body = tp.replace(varass); // tp hat nur eine String Typ Attribute ,welche nach "call by value" nie veraendert wird
	    return new HttpResponse(HttpStatus.Ok, body);
	  }

	  private  HttpResponse handleSearchRequest(String query,LinkedDocumentCollection ldc) {
	   
		  double pageRankDampingFactor = 0.85;
		    double weightingFactor = 0.6;
	    TreeMap<String, String> varass = new TreeMap<>();
	    varass.put("%value", query);
	    varass.put("%results", "");
	   synchronized(ldc) { // ldc. match erfordert eine schreibend-lesende Operation,
		   				// welche sollte atomar sein
	    double[] relevance = ldc.match(query, pageRankDampingFactor, weightingFactor);
	    String msg = "";
	    if (ldc.numDocuments() > 0)
	      msg += "<tr><td><b>ID</b></td><td><b>Page</b></td><td><b>Relevance</b></td></tr>";
	    msg += IntStream.range(0, ldc.numDocuments()).boxed().reduce("", (acc, i) -> {
	      acc += "<tr>";
	      acc += "<td>" + (i + 1) + "</td>";
	      acc += "<td><a href=\"" + ldc.get(i).getTitle() + "\">" + ldc.get(i).getTitle() + "</a></td>";
	      acc += "<td>" + relevance[i] + "</td>";
	      acc += "</tr>";
	      return acc;
	    }, (a, b) -> a + b);
	    varass.put("%results", msg);
	    String body = tp.replace(varass);
	    return new HttpResponse(HttpStatus.Ok, body);
	  }}

	  private static HttpResponse handleFileRequest(String fileName) {
	    if (fileName.contains("/"))
	      return new HttpResponse(HttpStatus.Forbidden);
	    String[] fileContents = Terminal.readFile(fileName);
	    if (fileContents == null)
	      return new HttpResponse(HttpStatus.NotFound);
	    if(fileContents.length != 2)
	      return new HttpResponse(HttpStatus.Forbidden);
	    String body = fileContents[1];
	    return new HttpResponse(HttpStatus.Ok, body);
	  }

	  private  void communicate(BufferedReader in, PrintWriter out,LinkedDocumentCollection ldc) throws IOException {
	    /*
	     * Todo: Request und Response-Klassen
	     */

	    String requestLine = in.readLine();
	    if (requestLine == null)
	      return;
	    in.lines().takeWhile(l -> !l.equals("")).count();
	    
	    System.out.println("=> Request header received");

	    HttpRequest request;
	    try {
	      request = new HttpRequest(requestLine);
	    } catch (InvalidRequestException ex) {
	      System.out.println("=> Bad request!");
	      out.print(new HttpResponse(HttpStatus.BadRequest));
	      return;
	    }

	    if (request.getMethod() != HttpMethod.GET) {
	      System.out.println("=> Invalid method!");
	      out.print(new HttpResponse(HttpStatus.MethodNotAllowed));
	      return;
	    }

	    HttpResponse response;
	    if (request.getPath().equals("/")) {
	      System.out.println("=> Query for main page");
	      response = handleMainPage();
	    } else if (request.getPath().equals("/search")) {
	      System.out.println("=> Search query");
	      String query = request.getParameters().get("query");
	      response = handleSearchRequest(query,ldc);
	    } else {
	      System.out.println("=> File query");
	      String fileName = request.getPath().substring(1);
	      response = handleFileRequest(fileName);
	    }
	    out.print(response);
	  }
	
	public void run() {
		BufferedReader  in ;
		PrintWriter out;
		      try {
		       
		    	System.out.println(Thread.currentThread().getName()+" is running."+"\n*** Client connected!");
		      
				
			
		    	in = new BufferedReader(new InputStreamReader(client.getInputStream()));
		        out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
		        
		        
		        try {
		        
						
					
		         communicate(in, out,ldc);
		        } catch (IOException exp) {
		        } finally {
		          out.close();
		          client.close();
		          //System.out.println();
		        }
		      }catch (IOException e) {
		        e.printStackTrace();
		      }
		    
	}

}
