import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.Stack;

public class TestItServer {
  private static String askString(BufferedReader in, PrintWriter out, String prompt) throws IOException {
    out.print(prompt);
    out.flush();
    return in.readLine();
  }

  static void communicate(BufferedReader in, PrintWriter out,SynchronizedLdcWrapper wrapper) throws IOException {
   // double pageRankDampingFactor = 0.85;
  //  double weightingFactor = 0.6;

    
    String command;

    boolean exit = false;

    while (!exit) {
      command = askString(in, out, "> ");
      if(command == null)
        break;

      if (command == null || command.equals("exit")) {
        /* Exit program */
        exit = true;
      } else if (command.startsWith("add ")) {
        /* add a new document */
        String titleAndText = command.substring(4);

        /* title and text separated by : */
        int separator = titleAndText.indexOf(':');
        String title = titleAndText.substring(0, separator);
        String text = titleAndText.substring(separator + 1);

        wrapper. appendDocument(new LinkedDocument(title, "", "", null, null, text, title));
      } else if (command.startsWith("list")) {
        /* list all document in collection */
        wrapper.forEach(i->out.println(i.getTitle()));
        out.flush();
      } else if (command.startsWith("query ")) {
        /* query on the documents in the collection */
        String query = command.substring(6);

        Stack<Integer> tmp = new Stack<Integer>();
        tmp.push(1);
        wrapper.query(query, (doc,rel)->{
        	out.println((tmp.peek()) + ". " + doc.getTitle() + "; Relevanz: " + rel);
        	tmp.push(1+tmp.pop());
        });
        out.flush();
      } else if (command.startsWith("count ")) {
        /* print the count of a word in each document */
        String word = command.substring(6);
        wrapper.forEach(doc->{
            WordCountsArray docWordCounts = doc.getWordCounts();

            int count = docWordCounts.getCount(docWordCounts.getIndexOfWord(word));

            /* -1 and 0 makes a difference! */
            if (count == -1) {
              out.println(doc.getTitle() + ": gar nicht.");
            } else {
              out.println(doc.getTitle() + ": " + count + "x ");
            }
        });
        out.flush();
      } else if (command.startsWith("pageRank")) {
    	  Stack<Integer> tmp = new Stack<Integer>();
          tmp.push(1);
       wrapper.pageRank((doc,rank)->{
    	   out.println(tmp.peek()+". "+doc.getTitle() + "; PageRank: " + rank);
    	   tmp.push(1+tmp.pop());

       });
       out.flush();
      } else if (command.startsWith("crawl")) {
        wrapper.crawl();
      }
      
      out.flush();
    }
   System.out.println("Client disconnected!");
  }

  public static void main(String[] args) throws IOException {
    @SuppressWarnings("resource")
    ServerSocket serverSocket = new ServerSocket(8000);
    while (true) {
      java.net.Socket client = serverSocket.accept();
      System.out.println("Client connected!");
      SynchronizedLdcWrapper wrapper = new SynchronizedLdcWrapper();
      TestItThread t = new TestItThread(wrapper, client);
      t.start();
    }
  }

}
