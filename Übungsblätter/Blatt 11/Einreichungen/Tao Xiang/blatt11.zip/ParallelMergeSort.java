import java.util.Arrays;
import java.util.Random;
import java.util.Stack;
public class ParallelMergeSort  extends Thread{
	private int[] arr;
	private int low,high;
	private int numberOfThreadLevels ;
	ParallelMergeSort(int[] arr,int low,int high ,int numberOfThreadLevels	){
		this.high=high;
		this.arr=arr;
		this.low=low;
		this.numberOfThreadLevels=numberOfThreadLevels;
	}
	public void run() 
	{	
		if(numberOfThreadLevels==0)  singleThreadMergeSort(arr, low, high);
		else
		{
			int mid = (low+high)/2;
			ParallelMergeSort next;
				 next = new ParallelMergeSort(arr,low,mid,numberOfThreadLevels/2);
			next.start();
			singleThreadMergeSort(arr, mid+1, high);
			while(next.isAlive())
				try {
					if(numberOfThreadLevels<8)
					Thread.sleep(100);
					else Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			doMerge(arr, low, high);
		}
		
	}
	public static void mergeSort(int[] arr,int numberOfThreadLevels) throws InterruptedException
	{
		ParallelMergeSort t = new ParallelMergeSort(arr, 0, arr.length-1, numberOfThreadLevels);
		t.start();
		t.join();
	}
	private static  void singleThreadMergeSort(int[] arr, int low , int high	)
	{
		if(low<high)
		{
			int mid =(low+high)/2;
			singleThreadMergeSort(arr, low, mid);
			doMerge(arr, low, mid);
			singleThreadMergeSort(arr, mid+1, high);
			doMerge(arr, mid+1, high);
			doMerge(arr, low, high);
		}
	}
	private static void doMerge(int[] arr, int low ,int high) {
		if(low<high){
		int mid = (low+high)/2;
		int p1 = low, p2 =mid+1;
		Stack<Integer> tmp = new Stack<Integer> ();
		while(p1<=mid&&p2<=high)
		{
			int a1=arr[p1],a2=arr[p2];
			int delta ;
			if(arr[p1]>=arr[p2]) delta =1;
			else delta =0;
			switch(delta) {
			case 1 :
			   {
				   tmp.push(a2);
				   p2++;
				   break;
			   }
			case 0 :
			 	{
			 		tmp.push(a1);
			 		p1++;
			 		break;
			 	}
			}
		}
		while(p1<=mid) tmp.push(arr[p1++]);
		while(p2<=high) tmp.push(arr[p2++]);
		for(int i =high;i>=low;i--)
		{
			arr[i]=tmp.pop();
			//System.out.println("a["+i+"]="+arr[i]);
		}
	}}
	public static void main(String[] args) throws InterruptedException {
		//int [] mergeSort= new int[] {3,2,1,6,5,4,7,8};
		//ParallelMergeSort.singleThreadMergeSort(mergeSort, 0, mergeSort.length-1);
		//System.out.println(Arrays.toString(mergeSort));
		 int n = 1000000;
		    int maxValue = 10000000;
		    Random rand = new Random();

		    int[] randomArray = new int[n];
		    for (int i = 0; i < n; i++) {
		      randomArray[i] = rand.nextInt(maxValue);
		    }
		    int[] sortedArray = Arrays.copyOf(randomArray, randomArray.length);
		    Arrays.sort(sortedArray);

		    int[] copy1 = Arrays.copyOf(randomArray, randomArray.length);

		    long timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 0);
		    long timeEnd = System.nanoTime();
		    long timeDiff = timeEnd - timeStart;
		    //assertTrue("Single-Threaded MergeSort - Das Array sollte sortiert sein!",
		       
		    System.out.println( Arrays.equals(sortedArray, copy1)+":  Single-Threaded MergeSort MergeSort took: " + timeDiff + " nanoseconds.");

		    copy1 = Arrays.copyOf(randomArray, randomArray.length);
		    timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 4);
		    timeEnd = System.nanoTime();
		    timeDiff = timeEnd - timeStart;
		   // assertTrue("ParallelMergeSort - n = 4 - Das Array sollte sortiert sein!",
		        //Arrays.equals(sortedArray, copy1));
		    System.out.println( Arrays.equals(sortedArray, copy1)+":  Parallel MergeSort with n =   4 took: " + timeDiff + " nanoseconds.");

		    // n = 8
		    copy1 = Arrays.copyOf(randomArray, randomArray.length);
		    timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 8);
		    timeEnd = System.nanoTime();
		    timeDiff = timeEnd - timeStart;
		   // assertTrue("ParallelMergeSort - n = 8 - Das Array sollte sortiert sein!",
		     //   Arrays.equals(sortedArray, copy1));
		    System.out.println(Arrays.equals(sortedArray, copy1)+":  Parallel MergeSort with n =   8 took: " + timeDiff + " nanoseconds.");

		    // n = 16
		    copy1 = Arrays.copyOf(randomArray, randomArray.length);
		    timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 16);
		    timeEnd = System.nanoTime();
		    timeDiff = timeEnd - timeStart;
		   // assertTrue("ParallelMergeSort - n = 16 - Das Array sollte sortiert sein!",
		     //   Arrays.equals(sortedArray, copy1));
		    System.out.println(Arrays.equals(sortedArray, copy1)+":  Parallel MergeSort with n =  16 took: " + timeDiff + " nanoseconds.");

		    // n = 32
		    copy1 = Arrays.copyOf(randomArray, randomArray.length);
		    timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 32);
		    timeEnd = System.nanoTime();
		    timeDiff = timeEnd - timeStart;
		 //   assertTrue("ParallelMergeSort - n = 32 - Das Array sollte sortiert sein!",
		   //     Arrays.equals(sortedArray, copy1));
		    System.out.println(Arrays.equals(sortedArray, copy1)+":  Parallel MergeSort with n =  32 took: " + timeDiff + " nanoseconds.");

		    // n = 128
		    copy1 = Arrays.copyOf(randomArray, randomArray.length);
		    timeStart = System.nanoTime();
		    ParallelMergeSort.mergeSort(copy1, 128);
		    timeEnd = System.nanoTime();
		    timeDiff = timeEnd - timeStart;
		   // assertTrue("ParallelMergeSort - n = 128 - Das Array sollte sortiert sein!",
		     //   Arrays.equals(sortedArray, copy1));
		    System.out.println(Arrays.equals(sortedArray, copy1)+":  Parallel MergeSort with n = 128 took: " + timeDiff + " nanoseconds.");
	}
}
