import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.TreeMap;
import java.util.stream.IntStream;

public class Webserver {
  private static TemplateProcessor tp;

  private static HttpResponse handleMainPage() {
    TreeMap<String, String> varass = new TreeMap<>();
    varass.put("%value", "");
    varass.put("%results", "");
    String body = tp.replace(varass);
    return new HttpResponse(HttpStatus.Ok, body);
  }

  private static HttpResponse handleSearchRequest(String query) {
    double pageRankDampingFactor = 0.85;
    double weightingFactor = 0.6;
    LinkedDocumentCollection ldc;
    {
      LinkedDocumentCollection temp = new LinkedDocumentCollection();
      temp.appendDocument(new LinkedDocument("B.txt", "", "", null, null, "link:A.txt link:E.txt", "B.txt"));
      ldc = temp.crawl();
    }
    
    TreeMap<String, String> varass = new TreeMap<>();
    varass.put("%value", query);
    varass.put("%results", "");
    double[] relevance = ldc.match(query, pageRankDampingFactor, weightingFactor);
    String msg = "";
    if (ldc.numDocuments() > 0)
      msg += "<tr><td><b>ID</b></td><td><b>Page</b></td><td><b>Relevance</b></td></tr>";
    msg += IntStream.range(0, ldc.numDocuments()).boxed().reduce("", (acc, i) -> {
      acc += "<tr>";
      acc += "<td>" + (i + 1) + "</td>";
      acc += "<td><a href=\"" + ldc.get(i).getTitle() + "\">" + ldc.get(i).getTitle() + "</a></td>";
      acc += "<td>" + relevance[i] + "</td>";
      acc += "</tr>";
      return acc;
    }, (a, b) -> a + b);
    varass.put("%results", msg);
    String body = tp.replace(varass);
    return new HttpResponse(HttpStatus.Ok, body);
  }

  private static HttpResponse handleFileRequest(String fileName) {
    if (fileName.contains("/"))
      return new HttpResponse(HttpStatus.Forbidden);
    String[] fileContents = Terminal.readFile(fileName);
    if (fileContents == null)
      return new HttpResponse(HttpStatus.NotFound);
    if(fileContents.length != 2)
      return new HttpResponse(HttpStatus.Forbidden);
    String body = fileContents[1];
    return new HttpResponse(HttpStatus.Ok, body);
  }

  private static void communicate(BufferedReader in, PrintWriter out) throws IOException {
    /*
     * Todo: Request und Response-Klassen
     */

    String requestLine = in.readLine();
    if (requestLine == null)
      return;
    in.lines().takeWhile(l -> !l.equals("")).count();
    
    System.out.println("=> Request header received");

    HttpRequest request;
    try {
      request = new HttpRequest(requestLine);
    } catch (InvalidRequestException ex) {
      System.out.println("=> Bad request!");
      out.print(new HttpResponse(HttpStatus.BadRequest));
      return;
    }

    if (request.getMethod() != HttpMethod.GET) {
      System.out.println("=> Invalid method!");
      out.print(new HttpResponse(HttpStatus.MethodNotAllowed));
      return;
    }

    HttpResponse response;
    if (request.getPath().equals("/")) {
      System.out.println("=> Query for main page");
      response = handleMainPage();
    } else if (request.getPath().equals("/search")) {
      System.out.println("=> Search query");
      String query = request.getParameters().get("query");
      response = handleSearchRequest(query);
    } else {
      System.out.println("=> File query");
      String fileName = request.getPath().substring(1);
      response = handleFileRequest(fileName);
    }
    out.print(response);
  }

  public static void main(String[] args) throws IOException {
	     tp = new TemplateProcessor("search.html");
	    
	    LinkedDocumentCollection ldc;
	    {
	      LinkedDocumentCollection temp = new LinkedDocumentCollection();
	      temp.appendDocument(new LinkedDocument("B.txt", "", "", null, null, "link:A.txt link:E.txt", "B.txt"));
	      ldc = temp.crawl();
	    }

	    @SuppressWarnings("resource")
	    ServerSocket serverSocket = new ServerSocket(8000);
	    while(true) {
	    	try {
	    		Socket client;
	    		
	    	 client = serverSocket .accept();
	    	
	    	 
	    	WebserverThread thread = new WebserverThread(client, ldc, tp);
	    	thread.start();}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    	
	    }}

}
