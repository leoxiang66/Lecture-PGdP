import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class SynchronizedLdcWrapper {
	private LinkedDocumentCollection ldc;
	private final double pageRankDampingFactor= 0.85;
	private final double weightingFactor=0.6;
	
	public SynchronizedLdcWrapper() {
		this.ldc=new  LinkedDocumentCollection();
	}
	public void appendDocument(LinkedDocument doc) {
	synchronized(ldc){
		ldc.appendDocument(doc);
	}
	}
	
	public void forEach(Consumer<Document> callback) {
		synchronized(ldc){
			for(int i=0;i<ldc.numDocuments();i++) {
				callback.accept(ldc.get(i));
			}
		}
	}
	
	public void query(String query,BiConsumer<Document,Double> callback) {
		synchronized(ldc){
			double[] relevance =ldc.match(query, pageRankDampingFactor, weightingFactor);
			for(int i=0;i<ldc.numDocuments();i++)
			{
				callback.accept(ldc.get(i), relevance[i]);
			}
		}
	}
	
	public void pageRank(BiConsumer<Document,Double> callback) {
		synchronized(ldc){
		double[] pageRanks = ldc.pageRank(pageRankDampingFactor);
		for(int i=0;i<ldc.numDocuments();i++) {
			callback.accept(ldc.get(i), pageRanks[i]);
		}
		}
	}
	
	public void crawl() {
		synchronized(ldc){
			ldc=ldc.crawl();
		}
	}
	

}
