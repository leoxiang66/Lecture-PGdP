package ProducerUndConsumer;

public class Queue <T>{
    private  T[] elements;
    private int start;
    private int stop;
    public Queue()
    {
        this.elements= (T[]) new Object[3];
        start=0;
        stop=-1;
    }
    private int actualSize()
    {
        synchronized (this) {
            int count = 0;
            for (T t : elements) if (t != null) count++;
            return count;
        }
    }
    public void enqueue(T value) throws InterruptedException{
        synchronized (this)
        {
            while(actualSize()==3) wait();
            stop=nextFreePlace();// zyklisch
            elements[stop]=value;
            notify();
        }
    }
    public T dequeue() throws  InterruptedException{
        synchronized (this)
        {
            while (actualSize()==0) wait();
            if(elements[start]==null) throw new NullPointerException("first element is null, can't dequeue");
            int size = actualSize();
            T ret = elements[start];
            elements[start]=null;
            if(size==1) stop =-1;
            start=(start+1)%3;
            notify();
            return ret;
        }
    }
    private void init()
    {
        synchronized (this) {
        this.elements = (T[]) new Object[3];
        start = 0;
        stop = -1;
    }
    }
    private int nextFreePlace() {
        synchronized (this){
        if(actualSize()==3) throw new NoMorePlacesException();
        int pointer = start;
        while(elements[pointer]!=null) pointer=(pointer+1)%3;
        return  pointer;
    }}
    public T get(int index) throws IndexOutOfBoundsException
    {
           return elements[index];
    }
}
