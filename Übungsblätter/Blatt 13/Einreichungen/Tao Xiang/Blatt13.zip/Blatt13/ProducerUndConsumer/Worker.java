package ProducerUndConsumer;

import java.util.function.Function;

public class Worker <T,U> extends  Thread{
    private Queue<T> input=null;
    private Queue<U> output=null;
    private Function<T,U> fun =null;
    Worker(Queue<T> input, Queue<U> output, Function<T,U> fun)
    {
        this.input=input;
        this.output=output;
        this.fun=fun;
    }

    @Override
    public void run() {
        Thread me = Thread.currentThread();
        while(true)
        {
            try{
                T tmp=input.dequeue();
                output.enqueue(fun.apply(tmp));
            }
            catch (InterruptedException e){break;}
            if(me.isInterrupted()) break;
        }
    }

    public Queue<T> getInput() {
        return input;
    }

    public Queue<U> getOutput() {
        return output;
    }

    public Function<T, U> getFun() {
        return fun;
    }
}
