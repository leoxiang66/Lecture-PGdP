package ProducerUndConsumer;

public class NoMorePlacesException extends ProducerConsumerException {
    NoMorePlacesException() {
        super("no more free places exception");
    }
}
