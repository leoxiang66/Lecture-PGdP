package ProducerUndConsumer;
import org.junit.*;
import java.util.function.Function;
import  static org.junit.Assert.*;
public class JUnitTests {
   private Function<Integer,String> encodingInteger = integer -> "encoded: "+integer.toString();
   private Function<String,Integer> decodingInteger = s -> Integer.parseInt(s.substring(9));
   private Function<Integer,Double> mapToDouble=Integer::doubleValue;
   private Function<Double,Double> doubleFunction=aDouble -> 2*aDouble;
   private Function<Double,String> toString= aDouble ->aDouble.toString().substring(0,aDouble.toString().indexOf('.'));
   private  Queue<Integer> input ;
  private   Queue<String> encodingToString ;
  private   Queue<Integer> decodingToInteger ;
  private   Queue<Double> mapToDoubleQueue ;
  private   Queue<Double> verdoppeltQueue;
  private   Queue<String> toStringQueue ;

@Before
public void inits() throws InterruptedException {
     input = new Queue<Integer>();
     input.enqueue(1);
     input.enqueue(2);
     input.enqueue(3);
     encodingToString = new Queue<String>();
     decodingToInteger = new Queue<Integer>();
     mapToDoubleQueue = new Queue<Double>();
     verdoppeltQueue= new Queue<Double>();
     toStringQueue = new Queue<String>();
}

    @org.junit.Test()
    public void TestSimple() throws InterruptedException {
        String[] expected= {"encoded: 1","encoded: 2","encoded: 3"};
        Worker<Integer,String> worker = new Worker<Integer, String>(input,encodingToString,encodingInteger);
        worker.start();
        Thread.sleep(3000);
        worker.interrupt();
        String[]actual = {encodingToString.get(0),encodingToString.get(1),encodingToString.get(2)};
        assertArrayEquals(expected,actual);
    }
    @Test
    public void TestTwoWorkers() throws  InterruptedException{
        int[] expected ={1,2,3};
        Worker<Integer,String> worker1 = new Worker<Integer, String>(input,encodingToString,encodingInteger);
        Worker<String,Integer> worker2= new Worker<String, Integer>(encodingToString,decodingToInteger,decodingInteger);
        worker1.start();
        worker2.start();
        Thread.sleep(6000);
        worker1.interrupt();
        worker2.interrupt();
        int [] actual = {decodingToInteger.get(0),decodingToInteger.get(1),decodingToInteger.get(2)};
        assertArrayEquals(expected,actual);
    }
    @Test
    public void TestAllWorkers() throws  InterruptedException{
    String[] expected={"2","4","6"};
        Worker<Integer,String> worker1 = new Worker<Integer, String>(input,encodingToString,encodingInteger);
        Worker<String,Integer> worker2= new Worker<String, Integer>(encodingToString,decodingToInteger,decodingInteger);
        Worker<Integer,Double> worker3= new Worker<Integer, Double>(decodingToInteger,mapToDoubleQueue,mapToDouble);
        Worker<Double,Double>  worker4= new Worker<Double, Double>(mapToDoubleQueue,verdoppeltQueue,doubleFunction);
        Worker<Double,String>  worker5 = new Worker<Double, String>(verdoppeltQueue,toStringQueue,toString);
        for(Worker worker: new Worker[]{worker1,worker2,worker3,worker4,worker5}) worker.start();
        Thread.sleep(15000);
        for(Worker worker: new Worker[]{worker1,worker2,worker3,worker4,worker5}) worker.interrupt();
        String[] actual= {toStringQueue.get(0),toStringQueue.get(1),toStringQueue.get(2)};
        assertArrayEquals(expected,actual);
    }


}
