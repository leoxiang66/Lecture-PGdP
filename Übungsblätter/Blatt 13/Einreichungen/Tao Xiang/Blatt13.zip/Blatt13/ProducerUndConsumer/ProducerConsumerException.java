package ProducerUndConsumer;

public class ProducerConsumerException extends RuntimeException{
    ProducerConsumerException(String msg)
    {
        super(msg);
    }
}
