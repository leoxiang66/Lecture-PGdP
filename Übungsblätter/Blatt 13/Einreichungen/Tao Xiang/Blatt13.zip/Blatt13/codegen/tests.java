package codegen;

import java.util.Arrays;

class person{
  private   String name;
    private String Geschlechter;
    public person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
   static void changeName(person[] ps)
   {
       for(person p:ps) p.setName("");
   }

}
public class tests {
    public static void main(String[] args)
    {
        person[] ps = new person[5];
        for(int i=0;i<ps.length;i++) ps[i]= new person("peter");
        Arrays.stream(ps).filter(person->person.getName().equals("peter")).forEach(person->{
           person. changeName(ps);
           System.out.println("hi");
        });
    }
    
}
