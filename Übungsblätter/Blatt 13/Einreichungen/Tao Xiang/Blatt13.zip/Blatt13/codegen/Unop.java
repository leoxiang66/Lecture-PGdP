package codegen;

public enum Unop {
  Minus
}
