package codegen;

import asm.Interpreter;
import org.junit.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class CodeGeneratorThreadsTest {
    public void testProgram(Program program, int expectedRetVal) {
        CodeGenerationVisitor cgv = new CodeGenerationVisitor();
        program.accept(cgv);
        int retVal = new Interpreter(cgv.getProgram()).execute();
        assertEquals(expectedRetVal, retVal);
    }

    /*
        int main ()
        {
            int[] arr;
            int i,t1;
            arr= new int[3];
            i=0;
            while(i<arr.length)
            {
                arr[i]=1;
                i++;
            }
             t1=fork:sum(arr);
            fork:changeValue(arr);
            return join(t1);
        }
       int changeValue(int[] arr)
        {
            int i;
            i=0;
            while(i<arr.length)
            {
                arr[i]=5;
                i++;
            }
            return 0;
        }
        int sum(int[]arr)
        {
            int ret,i;
            ret=0;
            i=0;
            while(i<arr.length)
            {
                ret=ret+arr[i];
                i++;
            }
            return ret;
        }

     */
    @Test
    public void TestOccurrenceOfRaceCondition() {
        Function main = new Function("main", new String[]{}, new Declaration[]{new Declaration(Type.IntArray, "arr"), new Declaration("i"), new Declaration("t1", "t2")},
                new Statement[]{
                        new Assignment("arr", new ArrayAllocator(new Number(1000))),
                        new Assignment("i", new Number(0)),
                        new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("arr"))),
                                new Composite(new ArrayIndexAssignment(new Variable("arr"), new Variable("i"), new Number(1)), new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))), false),
                        new Assignment("t2", new codegen.Call("changeValue", new Expression[]{new Variable("arr")}, true)),
                        new Assignment("t1", new codegen.Call("sum", new Expression[]{new Variable("arr")}, true)),
                        new ExpressionStatement(new codegen.Join(new Variable("t2"))),
                        new codegen.Return(new codegen.Join(new Variable("t1")))
                });
        Function changeValue = new Function(Type.Int, "changeValue", new Parameter[]{new Parameter(Type.IntArray, "arr")}, new Declaration[]{new Declaration("i")}, new Statement[]{
                new Assignment("i", new Number(0)),
                new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("arr"))),
                        new Composite(new ArrayIndexAssignment(new Variable("arr"), new Variable("i"), new Number(5)), new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))), false),
                new codegen.Return(new Number(0))
        });
        Function sum = new Function(Type.Int, "sum", new Parameter[]{new Parameter(Type.IntArray, "arr")}, new Declaration[]{new Declaration("ret", "i")}, new Statement[]{
                new Assignment("ret", new Number(0)),
                new Assignment("i", new Number(0)),
                new While(new Comparison(new Variable("i"), Comp.Less, new ArrayLength(new Variable("arr"))), new Composite(new Assignment("ret", new Binary(new Variable("ret"), Binop.Plus, new ArrayAccess(new Variable("arr"), new Variable("i")))),
                        new Assignment("i", new Binary(new Variable("i"), Binop.Plus, new Number(1)))), false),
                new codegen.Return(new Variable("ret"))
        });
        codegen.Program program = new Program(new Function[]{main, changeValue, sum});
        CodeGenerationVisitor cgv = new CodeGenerationVisitor();
        program.accept(cgv);
        int retVal = new Interpreter(cgv.getProgram()).execute();
        assertNotEquals(5000, retVal);
    }
}