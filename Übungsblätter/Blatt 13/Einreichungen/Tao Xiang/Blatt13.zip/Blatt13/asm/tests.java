package asm;

import java.util.HashMap;

public class tests {
    
    static HashMap<Integer,Integer>  a = new HashMap<Integer, Integer>();
    public static void main(String[] args)
    {
        if (!a.containsKey(2)) a.put(2,3);
        else System.out.println("hi");
    }
}
