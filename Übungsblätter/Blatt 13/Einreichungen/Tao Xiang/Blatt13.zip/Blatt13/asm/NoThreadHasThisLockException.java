package asm;

public class NoThreadHasThisLockException extends InterpreterException {
    public NoThreadHasThisLockException(String no_thread_has_this_lock) {
        super(no_thread_has_this_lock);
    }
}
