package asm;

public class DeadLockException extends InterpreterException {
    public DeadLockException(String s) {
        super(s);
    }
}
