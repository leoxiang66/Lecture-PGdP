package asm;

public class NoSuchThreadException extends InterpreterException{
    public NoSuchThreadException(String no_such_thread) {
        super(no_such_thread);
    }
}
