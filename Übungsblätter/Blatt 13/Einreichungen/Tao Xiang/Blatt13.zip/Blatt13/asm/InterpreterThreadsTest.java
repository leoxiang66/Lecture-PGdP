package asm;
import codegen.Call;
import codegen.Number;
import codegen.Program;
import org.junit.*;
import codegen.*;
import static org.junit.Assert.*;
public class InterpreterThreadsTest {

        @Test
        public void TestSimple()
        {
            Instruction[] pro= {
                    /* 0*/new Decl(2),   //Platz machen für t1 und result
                    /* 1*/new Ldi(1),  //P1
                    /* 2*/new Ldi(2),  //P2
                    /* 3*/new Ldi(11),   //Adresse von f1 laden
                    /* 4*/new Fork(2),   //f1 in neuem Thread starten
                    /* 5*/new Sts(1),    //Thread ID in t1 speichern
                    /* 6*/new Lfs(1),    //Thread ID aus t1 laden
                    /* 7*/new Join(),    //Warten, bis der Thread fertig ist und Ergebnis geben lassen
                    /* 8*/new Sts(2),    //Ergebnis in result speichern
                    /* 9*/new Lfs(2),    //Ergebnis aus result laden
                    /*10*/new Halt(),    //Fertig!

                    //Start f1
                    /*11*/new Lfs(-1),   //P1 (a laden)
                    /*12*/new Lfs(0),    //P2 (b laden)
                    /*13*/new Add(),     //Jetzt liegt der Returnwert oben und das Ergebnis von (2 + 7) direkt drunter
                    /*14*/new Return(2), //f1 ist fertig
            };
            Interpreter intp = new Interpreter(pro);
            assertEquals(3,intp.execute());
        }
        @Test
        public void TestExampleOnPiazza()
        {
            //Start
            Instruction[] pro= {
                    /* 0*/new Decl(2),   //Platz machen für t1 und result
                    /* 1*/new Ldi(1),  //P1
                    /* 2*/new Ldi(2),  //P2
                    /* 3*/new Ldi(11),   //Adresse von f1 laden
                    /* 4*/new Fork(2),   //f1 in neuem Thread starten
                    /* 5*/new Sts(1),    //Thread ID in t1 speichern
                    /* 6*/new Lfs(1),    //Thread ID aus t1 laden
                    /* 7*/new Join(),    //Warten, bis der Thread fertig ist und Ergebnis geben lassen
                    /* 8*/new Sts(2),    //Ergebnis in result speichern
                    /* 9*/new Lfs(2),    //Ergebnis aus result laden
                    /*10*/new Halt(),    //Fertig!

                    //Start f1
                    /*11*/new Ldi(7),
                    /*12*/new Ldi(2),
                    /*13*/new Add(),     //(2 + 7) berechnen
                    /*14*/new Lfs(-1),   //P1 (a laden)
                    /*15*/new Lfs(0),    //P2 (b laden)
                    /*16*/new Ldi(7),    //P3
                    /*17*/new Ldi(22),   //Adresse von f2
                    /*18*/new Fork(3),   //f2 in neuem Thread starten
                    /*19*/new Join(),    //Thread ID liegt oben => wir können direkt warten
                    /*20*/new Add(),     //Jetzt liegt der Returnwert oben und das Ergebnis von (2 + 7) direkt drunter
                    /*21*/new Return(2), //f1 ist fertig

                    //Start f2
                    /*22*/new Lfs(-2),
                    /*23*/new Lfs(-1),
                    /*24*/new Add(),
                    /*25*/new Lfs(0),
                    /*26*/new Add(),     //alle drei Werte addieren...
                    /*27*/new Return(3)  //und fertig.
            };
            Interpreter intp = new Interpreter(pro);
            assertEquals(19,intp.execute());
        }
    /*

    // Anmerkung:...
     folgende "nicht synchronized" test kann auch ein Ergebnis von 5000 geben , weil die Auswahl von Threads ist zufällig,
     deshalb hatte ich eine Array erzeugen, deren Length 1000 ist, damit solche Warscheinlichkeit am wenigsten ist ..



    int main ()
    {
        int[] arr;
        int i,t1,t2;
        arr= new int[1000];
        i=0;
        while(i<arr.length)
        {
            arr[i]=1;
            i++;
        }
        t2=fork:changeValue(arr);
        t1=fork:sum(arr);
        join(t2);
        return join(t1); // ohne Synchronation :  warscheinlich nicht gleich 5000
    }
   int changeValue(int[] arr)
    {
        int i;
        i=0;
        while(i<arr.length)
        {
            arr[i]=5;
            i++;
        }
        return 0;
    }
    int sum(int[]arr)
    {
        int ret,i;
        ret=0;
        i=arr.length-1;
        while(i>=0)
        {
            ret=ret+arr[i];
            i--;
        }
        return ret;
    }

 */
        @Test
    public void TestOccurrenceOfRaceCondition()
        {
            Function main= new Function("main",new String[]{},new Declaration[]{new Declaration(Type.IntArray,"arr"),new Declaration("i"),new Declaration("t1","t2")},
                    new Statement[]{
                            new Assignment("arr",new ArrayAllocator(new Number(1000))),
                            new Assignment("i",new Number(0)),
                            new While(new Comparison(new Variable("i"),Comp.Less,new ArrayLength(new Variable("arr"))),
                                    new Composite(new ArrayIndexAssignment(new Variable("arr"),new Variable("i"),new Number(1)),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))),false),
                            new Assignment("t2",new codegen. Call("changeValue",new Expression[]{new Variable("arr")},true)),
                            new Assignment("t1",new codegen.Call("sum",new Expression[]{new Variable("arr")},true)),
                            new ExpressionStatement(new codegen.Join(new Variable("t2"))),
                            new codegen.Return(new codegen.Join(new Variable("t1")))
                    });
            Function changeValue = new Function(Type.Int,"changeValue",new Parameter[]{new Parameter(Type.IntArray,"arr")},new Declaration[]{new Declaration("i")},new Statement[]{
                    new Assignment("i",new Number(0)),
                    new While(new Comparison(new Variable("i"),Comp.Less,new ArrayLength(new Variable("arr"))),
                            new Composite(new ArrayIndexAssignment(new Variable("arr"),new Variable("i"),new Number(5)),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))),false),
                    new codegen.Return(new Number(0))
            });
            Function sum = new Function(Type.Int,"sum",new Parameter[]{new Parameter(Type.IntArray,"arr")},new Declaration[]{new Declaration("ret","i")},new Statement[]{
                    new Assignment("ret",new Number(0)),
                    new Assignment("i",new Binary(new ArrayLength(new Variable("arr")),Binop.Minus,new Number(1))),
                    new While(new Comparison(new Variable("i"),Comp.GreaterEqual,new Number(0)),new Composite(new Assignment("ret",new Binary(new Variable("ret"),Binop.Plus,new ArrayAccess(new Variable("arr"),new Variable("i")))),
                            new Assignment("i",new Binary(new Variable("i"),Binop.Minus,new Number(1)))),false),
                    new codegen.Return(new Variable("ret"))
            });
            codegen.Program program = new Program(new Function[]{main,changeValue,sum});
            CodeGenerationVisitor cgv = new CodeGenerationVisitor();
            program.accept(cgv);
            int retVal = new Interpreter(cgv.getProgram()).execute();
            assertNotEquals(5000,retVal);
        }

    /*
    Ankerkung: folgende "synchronized test" hat 2 mögliche Ergebnisse:
    
        1. 5000:
             Der Interpreter  wählt  zuerst Thread t2 aus,
             dann hat t2 das Lock von Arr ,dann werden alle Arrayelemente auf 5 gesetzt, dann gibt t2  das Lock wieder frei,
             dann hat t1 das Lock , dann wird die Summierung ausgeführt und 5000 ausgeben.
        
        2. 1000:
            Der Interpreter wählt zuerst Thread t1 aus,
            dann hat t1 das Lock von Arr , dann wird sowieso die Summierung ausgefürht, bevor alle Elemente auf 5 gesetzt,
            dann wird 1000 ausgegeben.
              

int main ()
{
  int[] arr;
  int i,t1;
  arr= new int[1000];
  i=0;
  while(i<arr.length)
  {
      arr[i]=1;
      i++;
  }
  t2=fork:changeValue(arr);
  t1=fork:sum(arr);
  join(t2);
  return join(t1); // mit Synchronation :  gleich 5000 oder 1000
}
int changeValue(int[] arr)
{
 int i;
    synchronized(arr)
 {
  i=0;
  while(i<arr.length)
    {
      arr[i]=5;
      i++;
    }
  }
  return 0;
}
int sum(int[]arr)
{
 int ret,i;
    synchronized(arr)
    {
        ret=0;
        i=arr.length-1;
        while(i>=0)
        {
            ret=ret+arr[i];
            i--;
        }
    }
  return ret;
}

*/
        @Test
        public void TestSynchronized()
        {
            Function main= new Function("main",new String[]{},new Declaration[]{new Declaration(Type.IntArray,"arr"),new Declaration("i"),new Declaration("t1","t2")},
                    new Statement[]{
                            new Assignment("arr",new ArrayAllocator(new Number(1000))),
                            new Assignment("i",new Number(0)),
                            new While(new Comparison(new Variable("i"),Comp.Less,new ArrayLength(new Variable("arr"))),
                                    new Composite(new ArrayIndexAssignment(new Variable("arr"),new Variable("i"),new Number(1)),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))),false),
                            new Assignment("t2",new codegen. Call("changeValue",new Expression[]{new Variable("arr")},true)),
                            new Assignment("t1",new codegen.Call("sum",new Expression[]{new Variable("arr")},true)),
                            new ExpressionStatement(new codegen.Join(new Variable("t2"))),
                            new codegen.Return(new codegen.Join(new Variable("t1")))
                    });
            Function changeValue = new Function(Type.Int,"changeValue",new Parameter[]{new Parameter(Type.IntArray,"arr")},new Declaration[]{new Declaration("i")},new Statement[]{
                   new Synchronized(new Variable("arr"),new Statement[]{
                           new Assignment("i",new Number(0)),
                           new While(new Comparison(new Variable("i"),Comp.Less,new ArrayLength(new Variable("arr"))),
                                   new Composite(new ArrayIndexAssignment(new Variable("arr"),new Variable("i"),new Number(5)),new Assignment("i",new Binary(new Variable("i"),Binop.Plus,new Number(1)))),false),
                   }),
                    new codegen.Return(new Number(0))
            });
            Function sum = new Function(Type.Int,"sum",new Parameter[]{new Parameter(Type.IntArray,"arr")},new Declaration[]{new Declaration("ret","i")},new Statement[]{
                   new Synchronized(new Variable("arr"),new Statement[]{
                           new Assignment("ret",new Number(0)),
                           new Assignment("i",new Binary(new ArrayLength(new Variable("arr")),Binop.Minus,new Number(1))),
                           new While(new Comparison(new Variable("i"),Comp.GreaterEqual,new Number(0)),new Composite(new Assignment("ret",new Binary(new Variable("ret"),Binop.Plus,new ArrayAccess(new Variable("arr"),new Variable("i")))),
                                   new Assignment("i",new Binary(new Variable("i"),Binop.Minus,new Number(1)))),false),
                   }),
                    new codegen.Return(new Variable("ret"))
            });
            codegen.Program program = new Program(new Function[]{main,changeValue,sum});
            CodeGenerationVisitor cgv = new CodeGenerationVisitor();
            program.accept(cgv);
            int retVal = new Interpreter(cgv.getProgram()).execute();
            assertTrue(retVal==5000|| retVal==1000);System.out.println();
            if(retVal==5000) System.out.println("Der Interpreter wählt zuerst Thread t2 aus, mit Ergebnis: "+retVal);
            else System.out.println("Der Interpreter wählt zuerst Thread t1 aus , mit Ergebnis: "+retVal ); System.out.println();
        }


/*
int main ()
{
    int t1;
    int[] arr;
    arr = new int[2];
    t1=fork:getMyLock(arr);
    join(t1);
    return 0;
}
int getMyLock(int[] arr)
{
    int t2;
    synchronized(arr)
    {
          t2=fork:getMyLock(arr)
          join(t2);
    }
    return 0;
}
 */
@Test (expected = DeadLockException.class)
    public void TestDeadLock()
{
    Function main = new Function(Type.Int,"main",new Parameter[]{},new Declaration[]{new Declaration("t1"),new Declaration(Type.IntArray,"arr")},new Statement[]{
            new Assignment("arr",new ArrayAllocator(new Number(2))),
            new Assignment("t1",new Call("getMyLock",new Expression[]{new Variable("arr")},true)),
            new ExpressionStatement(new codegen.Join(new Variable("t1"))),
            new codegen.Return(new Number(0))
    });
    Function getMyLock = new Function(Type.Int,"getMyLock",new Parameter[]{new Parameter(Type.IntArray,"arr")},new Declaration[]{new Declaration("t2")},new Statement[]{
       new Synchronized(new Variable("arr"),new Statement[]{
               new Assignment("t2",new Call("getMyLock",new Expression[]{new Variable("arr")},true)),
               new ExpressionStatement(new codegen.Join(new Variable("t2")))
       })     ,
            new codegen.Return(new Number(0))
    });
    Program program = new Program(new Function[]{main,getMyLock});
    CodeGenerationVisitor cgv = new CodeGenerationVisitor();
    program.accept(cgv);
    new Interpreter(cgv.getProgram()).execute();

}
}
