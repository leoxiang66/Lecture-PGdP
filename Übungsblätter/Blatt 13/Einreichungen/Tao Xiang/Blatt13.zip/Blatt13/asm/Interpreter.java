package asm;

import util.Terminal;

import java.util.*;

public class Interpreter implements AsmVisitor,InterpreterThreadsConstants {
  private int[] heap = new int[1024];
  private int heapTop = 0;
  private Instruction[] program;
  private boolean halted;
  private InterpreterThread currenThread=null;
  private boolean declAllowed = true;
  private int count=0;
  private Stack<InterpreterThread> threadsPool= new Stack<InterpreterThread>();
  private int statusOfReadyThreads = V1_OfReadyThreads;
  private Map<Integer, HashSet<InterpreterThread>>  blockedThreadsOfLock = new HashMap<Integer,HashSet<InterpreterThread>>();
  public static int true_() {
    return -1;
  }

  public static int false_() {
    return 0;
  }

  public int pop() {
    if (currenThread.getStackPointer() < 0)
      throw new StackUnderflowException();
    int sp =currenThread.getStackPointer();
    currenThread.setStackPointer(sp-1);
    return currenThread.getStack()[sp];
  }

  public void push(int value) {
    int sp = currenThread.getStackPointer();
    currenThread.setStackPointer(sp+1);
    if (currenThread.getStackPointer() >= currenThread.getStack().length)
      throw new StackOverflowException();
    currenThread.getStack()[sp+1] = value;
  }

  public Interpreter(Instruction[] program)
  {
    this.program = program;
    currenThread= new InterpreterThread(count++);
    threadsPool.push(currenThread);
  }

  public int execute() {
    Random ran = new Random();
    int tempStatusOfReadyThreads=statusOfReadyThreads;
    boolean tobreak= false;
    while (!halted)
    {
      if(threadsPool.stream().filter(thread->thread.getStatus()==READY).count()==0) throw new DeadLockException("dead lock !");
      while (true)
     {
       tobreak=false;
       currenThread=threadsPool.get(ran.nextInt(threadsPool.size()));
       if(currenThread.getStatus()==READY)
       {
         int Scheduler = 0;
         while (Scheduler < 5)
         {
           if(tempStatusOfReadyThreads!=statusOfReadyThreads||halted)
           {
             tobreak=true;
             tempStatusOfReadyThreads=statusOfReadyThreads;
             break;
           }
           Instruction next = program[currenThread.getProgramCounter()];
           currenThread.setProgramCounter(currenThread.getProgramCounter() + 1);
           next.accept(this);
           Scheduler++;
         }
         if(tempStatusOfReadyThreads!=statusOfReadyThreads||halted)
         {
           tobreak=true;
           tempStatusOfReadyThreads=statusOfReadyThreads;
           break;
         }
       }
       if(tobreak) break;
     }
    }
    if(threadsPool.stream().filter(thread->thread.getStatus()==READY).count()>1) // es gibt noch living Threads bis auf main Thread
      throw new ThreadsNotAllDeadException("es gibt noch lebende Threads!");
    return threadsPool.get(0).getStack()[threadsPool.get(0).getStackPointer()];
  }

  @Override
  public void visit(Add add) {
    int a = pop();
    int b = pop();
    push(a + b);
    declAllowed = false;
  }

  @Override
  public void visit(Decl decl) {
    if (!declAllowed&&threadsPool.size()==1)
      throw new InvalidDeclarationException();
    if (decl.getCount() < 0)
      throw new InvalidStackAllocationException();
    currenThread.setStackPointer(currenThread.getStackPointer()+decl.getCount());
  }

  @Override
  public void visit(And and) {
    int a = pop();
    int b = pop();
    push(a & b);
    declAllowed = false;
  }

  @Override
  public void visit(Brc brc) {
    if (brc.getTarget() < 0 || brc.getTarget() > program.length)
      throw new InvalidJumpTargetException();
    int cond = pop();
    if (cond == -1)
     currenThread.setProgramCounter(brc.getTarget());
    declAllowed = false;
  }

  @Override
  public void visit(Call call) {
    if (call.getArgCount() < 0)
      throw new InvalidNumberOfMethodParametersException();
    int functionAddress = pop();
    if (functionAddress < 0 || functionAddress >= program.length)
      throw new InvalidMethodAddressException();
    int[] arguments = new int[call.getArgCount()];
    for (int i = 0; i < arguments.length; i++)
      arguments[i] = pop();
    push(currenThread.getFramePointer());
    push(currenThread.getProgramCounter());
    for (int i = 0; i < arguments.length; i++)
      push(arguments[arguments.length - 1 - i]);
    currenThread.setFramePointer(currenThread.getStackPointer());
    currenThread.setProgramCounter(functionAddress);
    declAllowed = true;
  }

  @Override
  public void visit(Cmp cmp) {
    int a = pop();
    int b = pop();
    switch (cmp.getCompareType()) {
      case EQ:
        push(a == b ? true_() : false_());
        break;
      case LT:
        push(a < b ? true_() : false_());
    }
    declAllowed = false;
  }

  @Override
  public void visit(Div div) {
    int a = pop();
    int b = pop();
    push(a / b);
    declAllowed = false;
  }

  @Override
  public void visit(Halt halt) {
    if(currenThread.getId()!=0) throw new  HaltNotInMainThreadException("Halt befindet sich nicht in main Thread");
    halted = true;
  }

  @Override
  public void visit(Ldi ldi) {
    push(ldi.getValue());
    declAllowed = false;
  }

  @Override
  public void visit(Lfs lds) {
    //System.out.println(currenThread.getProgramCounter()-1+"  "+lds.getIndex());
    int stackAddress = currenThread.getFramePointer() + lds.getIndex();
    if (stackAddress < 0 || stackAddress >= currenThread.getStack().length)
      throw new InvalidStackAccessException();
    push(currenThread.getStack()[stackAddress]);
    declAllowed = false;
  }

  @Override
  public void visit(Mod mod) {
    int a = pop();
    int b = pop();
    push(a % b);
    declAllowed = false;
  }

  @Override
  public void visit(Mul mul) {
    int a = pop();
    int b = pop();
    push(a * b);
    declAllowed = false;
  }

  @Override
  public void visit(Nop nop) {
    declAllowed = false;
  }

  @Override
  public void visit(Not not) {
    int a = pop();
    push(~a);
    declAllowed = false;
  }

  @Override
  public void visit(Or or) {
    int a = pop();
    int b = pop();
    push(a | b);
    declAllowed = false;
  }

  @Override
  public void visit(Pop pop) {
    int a = pop();
    currenThread.getRegister()[pop.getRegister()] = a;
    declAllowed = false;
  }

  @Override
  public void visit(Push push) {
    push(currenThread.getRegister()[push.getRegister()]);
    declAllowed = false;
  }

  @Override
  public void visit(In read) {
    int value = Terminal.askInt("Zahl eingeben: ");
    push(value);
    declAllowed = false;
  }

  @Override
  public void visit(Sts sts) {
    int stackAddress = currenThread.getFramePointer() + sts.getIndex();
    if (stackAddress < 0 || stackAddress >= currenThread.getStack().length)
      throw new InvalidStackAccessException();
    int value = pop();
    currenThread.getStack()[stackAddress] = value;
    declAllowed = false;
  }

  @Override
  public void visit(Sub sub) {
    int a = pop();
    int b = pop();
    push(a - b);
    declAllowed = false;
  }

  @Override
  public void visit(Out write) {
    int value = pop();
    System.out.println(value);
    declAllowed = false;
  }

  @Override
  public void visit(Return ret) {
    if (ret.getCells() < 0) throw new InvalidStackFrameSizeException();
    int retVal = pop();
    for (int i = 0; i < ret.getCells(); i++)
      pop();
    int pc = pop();
    if (pc<-1||pc >= program.length) throw new InvalidReturnAddressException();
    if(pc!=-1)
    {
      currenThread.setProgramCounter(pc);
      int fp = pop();
      if (fp < -1 || fp >= currenThread.getStack().length) throw new InvalidFramePointerException();
      currenThread.setFramePointer(fp);
      push(retVal);
    }
    else {
      currenThread.setRetValue(retVal);
      currenThread.setStatus(DEAD);
      currenThread.getJoiningQueue().forEach(interpreterThread -> interpreterThread.setStatus(READY));
      changeReadyThreadsStatus();
    }
    declAllowed = false;
  }

  @Override
  public void visit(Lfh lfh) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    push(heap[hAddr]);
    declAllowed=true;
  }

  @Override
  public void visit(Sth sth) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    int value = pop();
    heap[hAddr] = value;
   declAllowed=true;
  }

  @Override
  public void visit(Alloc alloc) {
    int size = pop();
    if (size == 0)
      // Zwei verschiedene Objekte dürfen nicht identisch sein!
      size++;
    if (size < 0 || heapTop + size > heap.length)
      throw new HeapAllocationException();
    push(heapTop);
    heapTop += size;
    declAllowed=true;
  }

  @Override
  public void visit(Join join) {
    int id =pop();
    InterpreterThread joined;
    try{
      joined = threadsPool.get(id);
    }
    catch (Exception e){throw new NoSuchThreadException("no such Thread");}
    if(joined.getStatus()!=DEAD)
    {
      currenThread.setStatus(JOINING);
      currenThread.setProgramCounter(currenThread.getProgramCounter()-1);
      joined.getJoiningQueue().offer(currenThread);
      push(id);
      changeReadyThreadsStatus();
    }
    else push(joined.getRetValue());
    declAllowed=true;
  }

  @Override
  public void visit(Fork fork){
    if (fork.getArgCount() < 0) throw new InvalidNumberOfMethodParametersException();
    int functionAddress = pop();
    if (functionAddress < 0 || functionAddress >= program.length) throw new InvalidMethodAddressException();
    declAllowed=true;
    int[] arguments = new int[fork.getArgCount()];
    for (int i = 0; i < arguments.length; i++)
      arguments[i] = pop();
    InterpreterThread newThread = new InterpreterThread(count++);
    push(newThread.getId());
    InterpreterThread tmp = currenThread;
    currenThread=newThread;
    threadsPool.add(newThread);
    changeReadyThreadsStatus();
    push(-1);
    push(-1);
    for (int i = 0; i < arguments.length; i++)
      push(arguments[arguments.length - 1 - i]);
    currenThread.setFramePointer(currenThread.getStackPointer());
    //System.out.println("id"+currenThread.getId()+" "+currenThread.getFramePointer());
    currenThread.setProgramCounter(functionAddress);
    currenThread=tmp;
    declAllowed = true;
  }

  @Override
  public void visit(Lock lock) {
    int heapAdr= pop();
    if(!blockedThreadsOfLock.containsKey(heapAdr)) blockedThreadsOfLock.put(heapAdr,new HashSet<InterpreterThread>());
    else
      {
      blockedThreadsOfLock.get(heapAdr).add(currenThread);
      currenThread.setStatus(BLOCKED);
      currenThread.setProgramCounter(currenThread.getProgramCounter()-1);
      push(heapAdr);
      changeReadyThreadsStatus();
    }
    declAllowed=true;
  }

  @Override
  public void visit(Unlock unlock) {
    int heapAdr= pop();
    if(!blockedThreadsOfLock.containsKey(heapAdr)) throw new NoThreadHasThisLockException("no thread has this lock");
    blockedThreadsOfLock.get(heapAdr).stream().forEach(interpreterThread -> interpreterThread.setStatus(READY));
    blockedThreadsOfLock.remove(heapAdr);
    changeReadyThreadsStatus();
    declAllowed=true;
  }

  private void changeReadyThreadsStatus() {
    statusOfReadyThreads=-statusOfReadyThreads;
  }

}
