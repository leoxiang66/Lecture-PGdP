package asm;

public class Join extends  Instruction{
    @Override
    public void accept(AsmVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return Opcode.JOIN.toString();
    }
}
