package asm;

public class HaltNotInMainThreadException extends InterpreterException  {
    public HaltNotInMainThreadException(String s) {
        super(s);
    }
}
