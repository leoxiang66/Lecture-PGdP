package asm;

import java.util.LinkedList;
import java.util.Queue;

public class InterpreterThread implements InterpreterThreadsConstants{
    private int id;
    private int[] stack=new int[128];
    private int stackPointer=-1;
    private int programCounter=0;
    private int framePointer=-1;
    private int[] register=new int[2];
    private int status=READY;
    private Queue<InterpreterThread> joiningQueue= new LinkedList<InterpreterThread>();
    private int retValue=0;
    public InterpreterThread(int id)
    {
        this.id=id;
    }
    public InterpreterThread(int id,int programCounter)
    {
        this.id=id;
        this.programCounter=programCounter;
    }
    public int getFramePointer() {
        return framePointer;
    }

    public int getId() {
        return id;
    }

    public int getProgramCounter() {
        return programCounter;
    }

    public int getStackPointer() {
        return stackPointer;
    }

    public int[] getRegister() {
        return register;
    }

    public int[] getStack() {
        return stack;
    }

    public void setStackPointer(int stackPointer) {
        this.stackPointer = stackPointer;
    }

    public void setFramePointer(int framePointer) {
        this.framePointer = framePointer;
    }

    public void setProgramCounter(int programCounter) {
        this.programCounter = programCounter;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Queue<InterpreterThread> getJoiningQueue() {
        return joiningQueue;
    }

    public int getRetValue() {
        return retValue;
    }

    public void setRetValue(int retValue) {
        this.retValue = retValue;
    }
}
