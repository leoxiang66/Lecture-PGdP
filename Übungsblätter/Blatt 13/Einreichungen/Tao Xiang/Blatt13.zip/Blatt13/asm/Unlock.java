package asm;

public class Unlock extends Instruction{
    @Override
    public void accept(AsmVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return Opcode.UNLOCK.toString();
    }
}
