package asm;

public class ThreadsNotAllDeadException extends InterpreterException {
    public ThreadsNotAllDeadException(String s) {
        super(s);
    }
}
