package asm;

public interface InterpreterThreadsConstants {
    int READY=0,JOINING=1,BLOCKED=2,DEAD=3;
    int V1_OfReadyThreads=1,V2_OfReadyThreads=-1;
}