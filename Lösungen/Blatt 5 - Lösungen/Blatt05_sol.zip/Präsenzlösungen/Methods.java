public class Methods {
  public static int[] invert(int[] array) {
    int[] invertiert = new int[array.length];
    for (int i = 0; i < invertiert.length; i++)
      invertiert[i] = array[array.length - i - 1];
    return invertiert;
  }

  public static int[] cut(int[] array, int length) {
    int[] geschnitten = new int[length];
    for (int i = 0; i < geschnitten.length && i < array.length; i++)
      geschnitten[i] = array[i];
    return geschnitten;
  }

  public static int[] linearize(int[][] array) {
    int length = 0;
    for (int i = 0; i < array.length; i++)
      length += array[i].length;
    int[] linearisiert = new int[length];
    int linIndex = 0;
    for (int i = 0; i < array.length; i++)
      for (int j = 0; j < array[i].length; j++)
        linearisiert[linIndex++] = array[i][j];
    return linearisiert;
  }

  public static void print(int[] array) {
    if (array.length == 0) {
      System.out.println("{}");
      return;
    }
    String tmp = "{" + array[0];
    for (int i = 1; i < array.length; i++) {
      tmp += ", ";
      tmp += array[i];
    }
    tmp += "}";
    System.out.println(tmp);
  }

  public static void main(String[] args) {
    int[] array = new int[] { 1, -1, 5, -27, 3, 200, 10 };
    int[] invertedArray = invert(array);
    print(invertedArray);
    int[] cutArray = cut(array, 3);
    print(cutArray);
    int[][] multiDimArray = new int[][] { new int[] { 1, 3 }, new int[] { 25 }, new int[] { 7, 4, 6, 9 } };
    int[] linearizedArray = linearize(multiDimArray);
    print(linearizedArray);
  }

}
