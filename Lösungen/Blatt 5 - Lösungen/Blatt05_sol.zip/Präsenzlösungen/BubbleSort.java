public class BubbleSort {

  // ************* Aufgabe a) *****************
  // Richtet zwei Zellen a[i] und a[j] von a nach aufsteigendem Wert aus
  public static void bubbleSort(int[] ar) {
    boolean match = false;
    // Durchlaufe in der aeusseren Schleife alle Elemente des Arrays
    for (int i = 0; i < ar.length - 1 && !match; i++) {
      match = true;
      // Durchlaufe in der inneren Schleife alle restlichen Elemente
      for (int j = ar.length - 1; j > i; j--) {
        // Vorgaenger ist groesser als aktuelles Element
        if (ar[j - 1] > ar[j]) {
          // Tausche Elemente
          swap(ar, j - 1, j);
          match = false;
        }
      }
    }
  }

  private static void swap(int[] ar, int pos1, int pos2) {
    int temp = ar[pos1];
    ar[pos1] = ar[pos2];
    ar[pos2] = temp;
  }

  // ************ Zusatzaufgabe *******************
  public static int[] filter(int[] a) {
    // Wichtig: a ist sortiert
    // Unterschiedliche Zahlen zaehlen
    int countFiltered = 0;
    for(int origIndex = 0; origIndex < a.length; origIndex++) {
      countFiltered++;
      // Gleiche Elemente werden uebersprungen
      for(int i = origIndex + 1; i < a.length; i++) {
        if(a[i] != a[origIndex])
          break;
        origIndex++;
      }
    }
    // Ergebnis-Array der richtigen Groeße erstellen
    int[] filtered = new int[countFiltered];
    // Unterschiedliche Werte ins Ergebnisfeld schreiben
    int filteredIndex = 0;
    for(int origIndex = 0; origIndex < a.length; origIndex++) {
      filtered[filteredIndex++] = a[origIndex];
      // Gleiche Elemente verwenden uebersprungen
      for(int i = origIndex + 1; i < a.length; i++) {
        if(a[i] != a[origIndex])
          break;
        origIndex++;
      }
    }
    return filtered;
  }

  public static void main(String[] args) {
    int[] a = { 1, 7, 3, 9, 4, 7, 1, 8, 2 };
    System.out.println(java.util.Arrays.toString(a));
    bubbleSort(a);
    System.out.println(java.util.Arrays.toString(a));
    int[] b = filter(a);
    System.out.println(java.util.Arrays.toString(b));
  }
}