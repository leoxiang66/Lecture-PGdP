class Student {
  private int matrikelNr;
  private String name;

  public Student(int matrikelNr, String name) {
    this.setMatrikelNr(matrikelNr);
    this.setName(name);
  }

  public int getMatrikelNr() {
    return matrikelNr;
  }

  public void setMatrikelNr(int matrikelNr) {
    this.matrikelNr = matrikelNr;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  /**
   * Fuegt einen Studenten an das Ende von 'students' hinzu.
   * 
   * @param students: Array von Studenten
   * @param student: Student der hinzugefuegt werden soll
   * @return true falls 'student' hinzugefuegt wurde, false sonst
   */
  public static boolean add(Student[] students, Student student) {
    // Erzeuge ein neues Array 'students' falls uebergebener Parameter NULL ist
    if (students == null || students.length == 0) {
      students = new Student[4];
    }

    // Erzeuge ein neuen Studenten 'student' falls uebergebener Parameter NULL ist.
    if (student != null) {
      // Fuege Studenten 'student' an die letze freie Stelle im Array 'students' hinzu
      for (int i = 0; i < students.length; i++) {
        if (students[i] == null) {
          students[i] = student;
          return true;
        }
      }
    }
    return false;
  }

  public static void anonymize(Student[] students, int matrikelNr) {
    Student studentFound = null;
    if (students != null) {
      for (int i = 0; i < students.length; i++) {
        if ((students[i] != null) && (students[i].getMatrikelNr() == matrikelNr)) {
          studentFound = students[i];
          studentFound.setName("XXX");
          break;
        }
      }
    }
  }

  public static Student anonymize2(Student[] students, int matrikelNr) {
    Student student = null;
    if (students != null) {
      for (int i = 0; i < students.length; i++) {
        if ((students[i] != null) && (students[i].getMatrikelNr() == matrikelNr)) {
          student = new Student(students[i].getMatrikelNr(), students[i].getName());
          student.setName("XXX");
          break;
        }
      }
    }
    return student;
  }

  // Gibt alle Studenten eines uebergebenen Arrays aus
  public static void printStudents(Student[] students) {
    if (students != null) {
      for (int i = 0; i < students.length; i++) {
        if (students[i] != null)
          System.out.println(students[i].toString());
      }
    }
  }

  public String toString() {
    return "Student mit Mat.Nr." + this.getMatrikelNr() + ": " + this.getName() + " angemeldet.";
  }

  public static void main(String[] args) {
    Student[] students = new Student[4];
    System.out.println(">>>> Ausgabe 1");
    add(students, new Student(1, "Harry Potter"));
    add(students, new Student(2, "Matthias chmidt"));
    printStudents(students);

    System.out.println("\n>>>> Ausgabe 2");
    add(null, new Student(3, "Martina Maier"));
    add(students, new Student(4, "Klaus Huber"));
    printStudents(students);

    System.out.println("\n>>>> Ausgabe 3");
    Student studentCp = anonymize2(students, 4);
    anonymize(students, 1);
    printStudents(students);

    System.out.println("\n>>>> Ausgabe 4");
    System.out.println(studentCp.toString());
  }
}