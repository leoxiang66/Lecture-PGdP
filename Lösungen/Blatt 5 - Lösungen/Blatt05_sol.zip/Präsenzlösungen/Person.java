public class Person {
  private String vorname;

  private String nachname;

  Person(String vorname, String nachname) {
    this.vorname = vorname;
    this.nachname = nachname;
  }

  public boolean equals(Person other) {
    return vorname.equals(other.vorname) && nachname.equals(other.nachname);
  }
}