import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChatClientUI extends Frame implements ChatClientMessageSenderThread {
    private Socket socket = null;
    private DataOutputStream streamOut = null;
    private ChatClientMessageReceiver messageReceiver = null;
    private TextArea displayTextArea = new TextArea();
    private TextField inputTextField = new TextField();
    private Button
            sendButton = new Button("Send"),
            connectButton = new Button("Connect"),
            quitButton = new Button("Bye");
    private String serverName = "localhost";
    private int serverPort = 1024;

    public ChatClientUI() {
        Panel keys = new Panel();
        keys.setLayout(new GridLayout(1, 2));
        keys.add(quitButton);
        keys.add(connectButton);
        Panel south = new Panel();
        south.setLayout(new BorderLayout());
        south.add("West", keys);
        south.add("Center", inputTextField);
        south.add("East", sendButton);
        Label title = new Label("Simple Chat Client Applet", Label.CENTER);
        title.setFont(new Font("Helvetica", Font.BOLD, 14));
        setLayout(new BorderLayout());
        add("North", title);
        add("Center", displayTextArea);
        add("South", south);
        quitButton.setEnabled(false);
        sendButton.setEnabled(false);
        pack();
        setVisible(true);

        quitButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    quit();
                }
            }
        );

        System.out.println(Thread.currentThread().getId());

        connectButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    new Thread(() -> {
                        println("Establishing connection. Please wait ...");
                        try {
                            socket = new Socket(serverName, serverPort);
                            println("Connected: " + socket);
                            open();
                            EventQueue.invokeLater(() -> {
                                sendButton.setEnabled(true);
                                connectButton.setEnabled(false);
                                quitButton.setEnabled(true);
                            });
                        } catch (UnknownHostException uhe) {
                            println("Host unknown: " + uhe.getMessage());
                        } catch (IOException ioe) {
                            println("Unexpected exception: " + ioe.getMessage());
                        }
                    }).start();
                }
            }
        );

        sendButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    send();
                    EventQueue.invokeLater(() -> inputTextField.requestFocus());
                }
            }        
         );

        inputTextField.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(final KeyEvent e) {
                if (e.getKeyChar() == KeyEvent.VK_ENTER)
                    send();
            }
        });

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    private void quit() {
        new Thread(() -> {
            inputTextField.setText(".bye");
            send();
            EventQueue.invokeLater(() -> {
                quitButton.setEnabled(false);
                sendButton.setEnabled(false);
                connectButton.setEnabled(true);
            });
        }).start();
    }

    public Socket getSocket() {
        return socket;
    }

    private void send() {
        try {
            streamOut.writeUTF(inputTextField.getText());
            streamOut.flush();
            EventQueue.invokeLater(() -> inputTextField.setText(""));
        } catch (IOException ioe) {
            println("Sending error: " + ioe.getMessage());
            close();
        }
    }

    public void handleMessage(final String msg) {
        if (msg.equals(".bye")) {
            println("Connection closed!");
            close();
        } else
            println(msg);
    }

    public void open() {
        try {
            streamOut = new DataOutputStream(socket.getOutputStream());
            messageReceiver = new ChatClientMessageReceiver(this);
            new Thread(messageReceiver).start();
        } catch (IOException ioe) {
            println("Error opening output stream: " + ioe);
        }
    }

    public void close() {
        try {
            if (streamOut != null)
                streamOut.close();
            if (socket != null)
                socket.close();
        } catch (IOException ioe) {
            println("Error closing ...");
        }
        messageReceiver.close();
        messageReceiver.setActive(false);
    }

    private void println(final String msg) {
        EventQueue.invokeLater(() -> displayTextArea.append(msg + "\n"));
    }

    public static void main(final String[] args) {
        final ChatClientUI chatGUI = new ChatClientUI();
    }

}
