import java.util.*;

public class Abteilung {
    private String name;
    private List<Mitarbeiter> mitarbeiter = new ArrayList<>();
    private List<Abteilung> unterabteilungen = new ArrayList<>();

    public Abteilung(final String name) {
        this.name = name;
    }

    public List<Mitarbeiter> getMitarbeiter() {
        return mitarbeiter;
    }

    public List<Abteilung> getUnterabteilungen() {
        return unterabteilungen;
    }

    public Mitarbeiter getChef() {
        for (Mitarbeiter m: mitarbeiter)
            if (mitarbeiter.contains(m.getChef()))
                return m.getChef();
        return null;
    }

    @Override
    public String toString() {
        final StringBuilder str = new StringBuilder();
        Mitarbeiter chef = getChef();
        str.append("Name:\n" + name + "\n");
        if (chef != null)
            str.append("Chef:\n" + getChef() + "\n");
        str.append("Mitarbeiter:\n" + mitarbeiter + "\n");
        str.append("Unterabteilungen:\n" + unterabteilungen + "\n");
        return str.toString();
    }

    public static void main(final String[] args) {
        final Abteilung regierung = new Abteilung("Bayrische Landesregierung");
        final Mitarbeiter ministerpräsident = new Mitarbeiter("Markus Söder");
        final Mitarbeiter kultusminister = new Mitarbeiter("Michael Piazolo", ministerpräsident);
        final Abteilung tum = new Abteilung("TU München");
        final Mitarbeiter präsident = new Mitarbeiter("Wolfgang Herrmann", kultusminister);
        final Mitarbeiter vize = new Mitarbeiter("Albert Berger", präsident);
        final Abteilung pgdp = new Abteilung("PGdP");
        final Mitarbeiter prof = new Mitarbeiter("Alexander Pretschner", vize);
        final Mitarbeiter ül1 = new Mitarbeiter("Julian Kranz", prof);
        final Mitarbeiter ül2 = new Mitarbeiter("Gerhard Hagerer", prof);
        
        regierung.getMitarbeiter().add(ministerpräsident);
        regierung.getMitarbeiter().add(kultusminister);
        regierung.getUnterabteilungen().add(tum);
        tum.getMitarbeiter().add(präsident);
        tum.getMitarbeiter().add(vize);
        tum.getUnterabteilungen().add(pgdp);
        pgdp.getMitarbeiter().add(prof);
        pgdp.getMitarbeiter().add(ül1);
        pgdp.getMitarbeiter().add(ül2);

        System.out.println(regierung.toString());
    }

}