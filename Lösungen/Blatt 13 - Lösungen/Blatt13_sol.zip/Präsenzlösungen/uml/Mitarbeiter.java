public class Mitarbeiter {
    private String name;
    private Mitarbeiter chef;

    public Mitarbeiter(final String name) {
        this.name = name;
    }

    public Mitarbeiter(final String name, final Mitarbeiter chef) {
        this.name = name;
        this.chef = chef;
    }

    public String getName() {
        return name;
    }

    public Mitarbeiter getChef() {
        return chef;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setChef(final Mitarbeiter chef) {
        this.chef = chef;
    }

    @Override
    public String toString() {
        return name;
    }
}