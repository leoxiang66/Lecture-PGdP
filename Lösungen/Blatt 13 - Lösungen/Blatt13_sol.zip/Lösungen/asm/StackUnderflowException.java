package asm;

public class StackUnderflowException extends InterpreterException {
  private static final long serialVersionUID = 1L;
  
  public StackUnderflowException(int threadId, int pc) {
    super("Stack underflow at instruction in thread " + threadId + " at instruction " + pc);
  }
}
