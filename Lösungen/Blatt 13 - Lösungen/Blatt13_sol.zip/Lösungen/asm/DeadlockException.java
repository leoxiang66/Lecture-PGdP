package asm;

public class DeadlockException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public DeadlockException() {
    super("No thread is ready => deadlock!");
  }
}
