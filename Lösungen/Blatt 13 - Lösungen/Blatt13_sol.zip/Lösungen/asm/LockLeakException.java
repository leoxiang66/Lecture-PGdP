package asm;

public class LockLeakException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public LockLeakException() {
    super("An address is still locked at the end of the program");
  }
}
