package asm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import util.Terminal;

public class Interpreter implements AsmVisitor {
  private int[] heap = new int[1024];
  private int heapTop = 0;
  private Instruction[] program;

  private HashMap<Integer, InterpreterThread> threads = new HashMap<>();

  private InterpreterThread currentThread;
  private ArrayList<Integer> ready = new ArrayList<>();
  private HashMap<Integer, ArrayList<Integer>> joining = new HashMap<>();
  private HashMap<Integer, ArrayList<Integer>> blocked = new HashMap<>();
  private HashSet<Integer> blockedAddresses = new HashSet<>();
  
  public Interpreter(Instruction[] program) {
    this.program = program;

    InterpreterThread mainThread = spawnThread(0);
    currentThread = mainThread;
    ready.add(mainThread.getId());
  }

  private int threadIdNext = 0;

  private InterpreterThread spawnThread(int programCounter) {
    InterpreterThread thread = new InterpreterThread(programCounter, threadIdNext++);
    threads.put(thread.getId(), thread);
    return thread;
  }

  private int insnSinceSched = 0;
  private int schedIndex = 0;

  private void scheduleNextThread() {
    if (ready.size() == 0)
      throw new DeadlockException();
    schedIndex = (schedIndex + 1) % ready.size();
    currentThread = threads.get(ready.get(schedIndex));
    insnSinceSched = 0;
  }

  private static int true_() {
    return -1;
  }

  private static int false_() {
    return 0;
  }

  private void push(int value) {
    currentThread.push(value);
  }

  private int pop() {
    return currentThread.pop();
  }

  private void terminateThread(int result) {
    currentThread.setHalted(true);
    currentThread.setResult(result);
    ArrayList<Integer> joiningThreads = joining.get(currentThread.getId());
    if (joiningThreads != null) {
      for (int tid : joiningThreads) {
        ready.add(tid);
        threads.get(tid).push(result);
      }
      joining.remove(currentThread.getId());
    }
    ready.remove((Object) currentThread.getId());
    if (currentThread.getId() != 0)
      scheduleNextThread();
  }

  public int execute() {
    while (!threads.get(0).isHalted()) {
      if (insnSinceSched >= 5)
        scheduleNextThread();
      else
        insnSinceSched++;

      Instruction next = program[currentThread.getProgramCounter()];
      currentThread.incPC();
      next.accept(this);
    }
    return threads.get(0).getResult();
  }

  @Override
  public void visit(Add add) {
    int a = pop();
    int b = pop();
    push(a + b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Decl decl) {
    if (!currentThread.isDeclAllowed())
      throw new InvalidDeclarationException();
    if (decl.getCount() < 0)
      throw new InvalidStackAllocationException();
    currentThread.setStackPointer(currentThread.getStackPointer() + decl.getCount());
  }

  @Override
  public void visit(And and) {
    int a = pop();
    int b = pop();
    push(a & b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Brc brc) {
    if (brc.getTarget() < 0 || brc.getTarget() > program.length)
      throw new InvalidJumpTargetException();
    int cond = pop();
    if (cond == -1)
      currentThread.setProgramCounter(brc.getTarget());
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Call call) {
    if (call.getArgCount() < 0)
      throw new InvalidNumberOfMethodParametersException();
    int functionAddress = pop();
    if (functionAddress < 0 || functionAddress >= program.length)
      throw new InvalidMethodAddressException();
    int[] arguments = new int[call.getArgCount()];
    for (int i = 0; i < arguments.length; i++)
      arguments[i] = pop();
    push(currentThread.getProgramCounter());
    push(currentThread.getFramePointer());
    for (int i = 0; i < arguments.length; i++)
      push(arguments[arguments.length - 1 - i]);
    currentThread.setFramePointer(currentThread.getStackPointer());
    currentThread.setProgramCounter(functionAddress);
    currentThread.setDeclAllowed(true);
  }

  @Override
  public void visit(Cmp cmp) {
    int a = pop();
    int b = pop();
    switch (cmp.getCompareType()) {
      case EQ:
        push(a == b ? true_() : false_());
        break;
      case LT:
        push(a < b ? true_() : false_());
    }
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Div div) {
    int a = pop();
    int b = pop();
    push(a / b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Halt halt) {
    int result = pop();
    if (currentThread.getId() != 0)
      throw new InvalidHaltException();
    if (blockedAddresses.size() > 0)
      throw new LockLeakException();
    if (ready.size() > 1 || blocked.size() > 0 || joining.size() > 0)
      throw new ThreadHasNotFinishedException();
    terminateThread(result);
  }

  @Override
  public void visit(Ldi ldi) {
    push(ldi.getValue());
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Lfs lds) {
    int stackAddress = currentThread.getFramePointer() + lds.getIndex();
    if (stackAddress < 0 || stackAddress >= currentThread.getStack().length)
      throw new InvalidStackAccessException(currentThread.getId(), currentThread.getProgramCounter());
    push(currentThread.getStack()[stackAddress]);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Mod mod) {
    int a = pop();
    int b = pop();
    push(a % b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Mul mul) {
    int a = pop();
    int b = pop();
    push(a * b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Nop nop) {
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Not not) {
    int a = pop();
    push(~a);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Or or) {
    int a = pop();
    int b = pop();
    push(a | b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Pop pop) {
    int a = pop();
    currentThread.setRegister(pop.getRegister(), a);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Push push) {
    push(currentThread.getRegister(push.getRegister()));
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(In read) {
    int value = Terminal.askInt("Zahl eingeben: ");
    push(value);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Sts sts) {
    int stackAddress = currentThread.getFramePointer() + sts.getIndex();
    if (stackAddress < 0 || stackAddress >= currentThread.getStack().length)
      throw new InvalidStackAccessException(currentThread.getId(), currentThread.getProgramCounter());
    int value = pop();
    currentThread.getStack()[stackAddress] = value;
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Sub sub) {
    int a = pop();
    int b = pop();
    push(a - b);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Out write) {
    int value = pop();
    System.out.println(value);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Return ret) {
    if (ret.getCells() < 0)
      throw new InvalidStackFrameSizeException();
    int retVal = pop();
    for (int i = 0; i < ret.getCells(); i++)
      pop();
    int framePointer = pop();
    currentThread.setFramePointer(framePointer);
    if (framePointer < -1 || framePointer >= currentThread.getStack().length)
      throw new InvalidFramePointerException();
    int returnAddress = pop();
    if (returnAddress == -1) {
      terminateThread(retVal);
      return;
    }
    currentThread.setProgramCounter(returnAddress);
    if (currentThread.getProgramCounter() < 0 || currentThread.getProgramCounter() >= program.length)
      throw new InvalidReturnAddressException();
    push(retVal);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Lfh lfh) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    push(heap[hAddr]);
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Sth sth) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    int value = pop();
    heap[hAddr] = value;
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Alloc alloc) {
    int size = pop();
    if (size == 0)
      // Zwei verschiedene Objekte dürfen nicht identisch sein!
      size++;
    if (size < 0 || heapTop + size > heap.length)
      throw new HeapAllocationException();
    push(heapTop);
    heapTop += size;
    currentThread.setDeclAllowed(false);
  }

  @Override
  public void visit(Fork fork) {
    if (fork.getArgCount() < 0)
      throw new InvalidNumberOfMethodParametersException();
    int functionAddress = pop();
    if (functionAddress < 0 || functionAddress >= program.length)
      throw new InvalidMethodAddressException();
    int[] arguments = new int[fork.getArgCount()];
    for (int i = 0; i < arguments.length; i++)
      arguments[i] = pop();
    InterpreterThread newThread = spawnThread(functionAddress);
    newThread.push(-1);
    newThread.push(-1);
    for (int i = 0; i < arguments.length; i++)
      newThread.push(arguments[arguments.length - i - 1]);
    newThread.setFramePointer(newThread.getStackPointer());
    ready.add(newThread.getId());
    push(newThread.getId());
  }

  @Override
  public void visit(Join join) {
    int id = pop();
    InterpreterThread thread = threads.get(id);
    if (thread == null)
      throw new InvalidThreadException(id);
    currentThread.setDeclAllowed(false);
    if (thread.isHalted()) {
      push(thread.getResult());
      return;
    }
    ready.remove((Object) currentThread.getId());
    joining.putIfAbsent(id, new ArrayList<>());
    joining.get(id).add(currentThread.getId());
    scheduleNextThread();
  }

  @Override
  public void visit(Lock lock) {
    int addr = pop();
    currentThread.setDeclAllowed(false);
    if (blockedAddresses.contains(addr)) {
      ready.remove((Object) currentThread.getId());
      blocked.putIfAbsent(addr, new ArrayList<>());
      blocked.get(addr).add(currentThread.getId());
      scheduleNextThread();
    } else
      blockedAddresses.add(addr);
  }

  @Override
  public void visit(Unlock unlock) {
    int addr = pop();
    if (!blockedAddresses.contains(addr))
      throw new InvalidUnlockException();
    ArrayList<Integer> blockedThreads = blocked.get(addr);
    if (blockedThreads != null) {
      ready.add(blockedThreads.remove(blockedThreads.size() - 1));
      if (blockedThreads.size() == 0)
        blocked.remove(addr);
    } else
      blockedAddresses.remove(addr);
    currentThread.setDeclAllowed(false);
  }

}
