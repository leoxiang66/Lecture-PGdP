package asm;

public class InvalidUnlockException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public InvalidUnlockException() {
    super("Invalid UNLOCK (address is not locked)");
  }
}
