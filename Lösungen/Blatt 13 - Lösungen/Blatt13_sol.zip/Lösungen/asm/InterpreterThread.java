package asm;

public class InterpreterThread {
  private int id;
  
  public int getId() {
    return id;
  }
  
  private int[] stack;
  
  public int[] getStack() {
    return stack;
  }
  
  private int stackPointer = -1;
  
  public int getStackPointer() {
    return stackPointer;
  }
  
  public void setStackPointer(int stackPointer) {
    this.stackPointer = stackPointer;
  }
  
  private int programCounter = 0;
  
  public int getProgramCounter() {
    return programCounter;
  }
  
  public void setProgramCounter(int programCounter) {
    this.programCounter = programCounter;
  }
  
  private int framePointer = -1;
  
  public int getFramePointer() {
    return framePointer;
  }
  
  public void setFramePointer(int framePointer) {
    this.framePointer = framePointer;
  }
  
  private int[] registers = new int[2];
  
  public int[] getRegisters() {
    return registers;
  }
  
  private boolean halted = false;
  
  public boolean isHalted() {
    return halted;
  }
  
  public void setHalted(boolean halted) {
    this.halted = halted;
  }
  
  private int result;
  
  public int getResult() {
    return result;
  }
  
  public void setResult(int result) {
    this.result = result;
  }
  
  private boolean declAllowed;
  
  public void setDeclAllowed(boolean declAllowed) {
    this.declAllowed = declAllowed;
  }
  
  public boolean isDeclAllowed() {
    return declAllowed;
  }
  
  public InterpreterThread(int programCounter, int id) {
    this.stack = new int[128];
    this.stackPointer = -1;
    this.framePointer = -1;
    this.programCounter = programCounter;
    this.id = id;
    this.declAllowed = true;
  }
  
  public void incPC() {
    programCounter++;
  }
  
  public void setRegister(int register, int value) {
    registers[register] = value;
  }
  
  public int getRegister(int register) {
    return registers[register];
  }
  
  public void push(int value) {
    stackPointer++;
    if (stackPointer >= stack.length)
      throw new StackOverflowException();
    stack[stackPointer] = value;
  }
  
  public int pop() {
    if (stackPointer < 0)
      throw new StackUnderflowException(id, programCounter);
    return stack[stackPointer--];
  }
}
