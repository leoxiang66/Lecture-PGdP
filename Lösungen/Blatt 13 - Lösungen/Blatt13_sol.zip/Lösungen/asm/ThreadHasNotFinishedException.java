package asm;

public class ThreadHasNotFinishedException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public ThreadHasNotFinishedException() {
    super("A thread is still running at the end of the program");
  }
}
