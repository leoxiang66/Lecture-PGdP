package asm;
import static asm.Opcode.*;

public class Unlock extends Instruction {
  @Override
  public String toString() {
    return UNLOCK.toString();
  }

  @Override
  public void accept(AsmVisitor visitor) {
    visitor.visit(this);
  }

}
