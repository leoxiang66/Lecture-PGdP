package asm;
import static asm.Opcode.*;

public class Join extends Instruction {
  @Override
  public String toString() {
    return JOIN.toString();
  }

  @Override
  public void accept(AsmVisitor visitor) {
    visitor.visit(this);
  }

}
