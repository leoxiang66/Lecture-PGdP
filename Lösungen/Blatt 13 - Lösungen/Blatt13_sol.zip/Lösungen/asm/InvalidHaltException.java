package asm;

public class InvalidHaltException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public InvalidHaltException() {
    super("Invalid HALT (not in the main thread)");
  }
}
