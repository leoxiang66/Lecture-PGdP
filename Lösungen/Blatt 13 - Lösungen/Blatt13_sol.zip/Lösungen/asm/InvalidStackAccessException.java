package asm;

public class InvalidStackAccessException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public InvalidStackAccessException(int threadId, int pc) {
    super("Invalid stack accesss in thread " + threadId + " at instruction " + pc);
  }
}
