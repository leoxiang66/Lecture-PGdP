package asm;

import static org.junit.Assert.*;

import org.junit.Test;

public class InterpreterTest {  
  /*
   * 1P
   */
  @Test
  public void testDoubleJoin() {
    Instruction[] program = {
        new Ldi(3),
        new Call(0),
        new Halt(),
        new Decl(1),
        new Decl(2),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Lfs(1),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Lfs(1),
        new Ldi(45),
        new Fork(1),
        new Sts(2),
        new Ldi(66),
        new Fork(0),
        new Sts(3),
        new Lfs(3),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Unlock(),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Push(0),
        new Return(3),
        new Decl(1),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Unlock(),
        new Ldi(11),
        new Lfs(1),
        new Join(),
        new Add(),
        new Pop(0),
        new Push(0),
        new Return(2),
        new Ldi(1),
        new Ldi(1),
        new Add(),
        new Pop(0),
        new Ldi(1),
        new Ldi(1),
        new Add(),
        new Pop(0),
        new Ldi(1),
        new Ldi(1),
        new Add(),
        new Pop(0),
        new Ldi(1),
        new Ldi(1),
        new Add(),
        new Pop(0),
        new Ldi(42),
        new Pop(0),
        new Push(0),
        new Return(0),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(53, intp.execute());
  }
  
  /*
   * 1P
   */
  @Test
  public void testSyncReturn() {
    Instruction[] program1 = {
        new Ldi(23),
        new Call(0),
        new Halt(),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Ldi(0),
        new Ldi(0),
        new Cmp(CompareType.EQ),
        new Not(),
        new Brc(18),
        new Ldi(42),
        new Pop(0),
        new Unlock(),
        new Push(0),
        new Return(1),
        new Unlock(),
        new Ldi(20),
        new Pop(0),
        new Push(0),
        new Return(1),
        new Decl(1),
        new Decl(1),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(2),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Push(0),
        new Return(2),
    };
    Instruction[] program2 = {
        new Ldi(23),
        new Call(0),
        new Halt(),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Ldi(0),
        new Ldi(42),
        new Cmp(CompareType.EQ),
        new Not(),
        new Brc(18),
        new Ldi(42),
        new Pop(0),
        new Unlock(),
        new Push(0),
        new Return(1),
        new Unlock(),
        new Ldi(20),
        new Pop(0),
        new Push(0),
        new Return(1),
        new Decl(1),
        new Decl(1),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(2),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Push(0),
        new Return(2),
    };
    Interpreter intp = new Interpreter(program1);
    assertEquals(42, intp.execute());
    intp = new Interpreter(program2);
    assertEquals(20, intp.execute());
  }
  
  /*
   * 1P
   */
  @Test
  public void testRaceSyncOnlyOne() {
    Instruction[] program = {
        new Ldi(28),
        new Call(0),
        new Halt(),
        new Decl(1),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(2),
        new Decl(1),
        new Decl(2),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Lfs(1),
        new Ldi(72),
        new Fork(1),
        new Sts(2),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(3),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Pop(0),
        new Push(0),
        new Return(3),
        new Decl(1),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Unlock(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(2),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(1, intp.execute());
  }
  
  /*
   * 1P
   */
  @Test
  public void testRaceSyncOtherArray() {
    Instruction[] program = {
        new Ldi(38),
        new Call(0),
        new Halt(),
        new Decl(1),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Lfs(-1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Lfs(-1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Unlock(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(3),
        new Decl(2),
        new Decl(4),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(2),
        new Ldi(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Lfs(1),
        new Lfs(2),
        new Ldi(3),
        new Fork(2),
        new Sts(3),
        new Lfs(1),
        new Lfs(2),
        new Ldi(3),
        new Fork(2),
        new Sts(4),
        new Lfs(1),
        new Lfs(2),
        new Ldi(3),
        new Fork(2),
        new Sts(5),
        new Lfs(1),
        new Lfs(2),
        new Ldi(3),
        new Fork(2),
        new Sts(6),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(4),
        new Join(),
        new Pop(0),
        new Lfs(5),
        new Join(),
        new Pop(0),
        new Lfs(6),
        new Join(),
        new Pop(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Pop(0),
        new Push(0),
        new Return(6),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(4, intp.execute());
  }

  /*
   * 1P
   */
  @Test
  public void testRaceSync() {
    Instruction[] program = {
        new Ldi(38),
        new Call(0),
        new Halt(),
        new Decl(1),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Unlock(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(2),
        new Decl(1),
        new Decl(4),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(2),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(3),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(4),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(5),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(4),
        new Join(),
        new Pop(0),
        new Lfs(5),
        new Join(),
        new Pop(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Pop(0),
        new Push(0),
        new Return(5),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(4, intp.execute());
  }
  
  /*
   * 1P
   */
  @Test
  public void testRace() {
    Instruction[] program = {
        new Ldi(28),
        new Call(0),
        new Halt(),
        new Decl(1),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Sts(1),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(2),
        new Decl(1),
        new Decl(2),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(2),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(3),
        new Lfs(2),
        new Join(),
        new Pop(0),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Pop(0),
        new Push(0),
        new Return(3),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(1, intp.execute());
  }
  
  /*
   * 1P
   */
  @Test
  public void testThreading1() {
    Instruction[] program = {
        new Ldi(27),
        new Call(0),
        new Halt(),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Ldi(1),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Add(),
        new Lfs(0),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Unlock(),
        new Ldi(42),
        new Pop(0),
        new Push(0),
        new Return(1),
        new Decl(1),
        new Decl(3),
        new Ldi(1),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Sth(),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(3),
        new Lfs(1),
        new Ldi(3),
        new Fork(1),
        new Sts(4),
        new Lfs(3),
        new Join(),
        new Sts(2),
        new Lfs(4),
        new Join(),
        new Lfs(2),
        new Add(),
        new Sts(2),
        new Lfs(1),
        new Ldi(0),
        new Ldi(1),
        new Add(),
        new Add(),
        new Lfh(),
        new Lfs(2),
        new Add(),
        new Pop(0),
        new Push(0),
        new Return(4),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(86, intp.execute());
    
  }
  
  /*
   * 1P
   */
  @Test
  public void testThreadingBasic() {
    Instruction[] program = {
      new Ldi(4),
      new Fork(0),
      new Join(),
      new Halt(),
      new Ldi(42),
      new Return(0)
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(42, intp.execute());
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = InvalidThreadException.class)
  public void testInvalidJoin() {
    Instruction[] program = {
        new Ldi(42),
        new Join(),
        new Halt(),
      };
      Interpreter intp = new Interpreter(program);
      assertEquals(42, intp.execute());;
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = InvalidUnlockException.class)
  public void testInvalidUnlock() {
    Instruction[] program = {
        new Ldi(42),
        new Alloc(),
        new Unlock(),
        new Ldi(0),
        new Halt(),
      };
      Interpreter intp = new Interpreter(program);
      assertEquals(42, intp.execute());;
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = DeadlockException.class)
  public void testDeadlock() {
    Instruction[] program = {
        new Ldi(23),
        new Call(0),
        new Halt(),
        new Lfs(-1),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Ldi(1),
        new Pop(0),
        new Ldi(1),
        new Pop(0),
        new Lfs(0),
        new Pop(0),
        new Push(0),
        new Push(0),
        new Lock(),
        new Unlock(),
        new Unlock(),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(2),
        new Decl(1),
        new Decl(1),
        new Decl(2),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(1),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Ldi(1),
        new Add(),
        new Alloc(),
        new Pop(1),
        new Push(0),
        new Push(1),
        new Sth(),
        new Push(1),
        new Sts(2),
        new Lfs(1),
        new Lfs(2),
        new Ldi(3),
        new Fork(2),
        new Sts(3),
        new Lfs(2),
        new Lfs(1),
        new Ldi(3),
        new Fork(2),
        new Sts(4),
        new Lfs(3),
        new Join(),
        new Pop(0),
        new Lfs(4),
        new Join(),
        new Pop(0),
        new Ldi(0),
        new Pop(0),
        new Push(0),
        new Return(4),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(42, intp.execute());
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = ThreadHasNotFinishedException.class)
  public void testMainExitsFirst() {
    Instruction[] program = {
        new Ldi(3),
        new Fork(0),
        new Halt(),
        new Ldi(-1),
        new Brc(3)
      };
      Interpreter intp = new Interpreter(program);
      assertEquals(42, intp.execute());;
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = LockLeakException.class)
  public void testNoUnlock() {
    Instruction[] program = {
        new Ldi(10),
        new Alloc(),
        new Lock(),
        new Ldi(0),
        new Halt(),
      };
      Interpreter intp = new Interpreter(program);
      assertEquals(42, intp.execute());;
  }
  
  /*
   * Alle Exception-Tests zusammen 2 Punkte,
   * 0.5 Punkte Abzug bei Fehlschlag
   * 
   * Achtung: Namen von Exceptions können bei Studis abweichen!
   */
  @Test(expected = InvalidHaltException.class)
  public void testInvalidHalt() {
    Instruction[] program = {
        new Ldi(6),
        new Fork(0),
        new Ldi(-1),
        new Brc(2),
        new Ldi(0),
        new Halt(),
        new Halt(),
      };
      Interpreter intp = new Interpreter(program);
      assertEquals(42, intp.execute());;
  }
  
  @Test
  public void testTests() {
    /*
     * 1P Abzug ohne Tests (zusammen mit Code-Generator)
     * 
     * Achtung: Die Tests müssen JUnit verwenden!
     */
    
    fail("Bitte JUnit-Tests prüfen!");
  }
  
  /*
   * Alte Tests
   */

  @Test
  public void testAllocZero() {
    Instruction[] program = {
      new Ldi(0),
      new Alloc(),
      new Pop(0),
      new Ldi(1),
      new Alloc(),
      new Pop(1),
      new Push(0),
      new Push(1),
      new Cmp(CompareType.EQ),
      new Halt()
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(0, intp.execute());
  }
  
  @Test
  public void testHeapSimple() {
    Instruction[] program = {
      new Ldi(2),
      new Alloc(),
      new Pop(0),
      new Ldi(42),
      new Push(0),
      new Sth(),
      new Push(0),
      new Lfh(),
      new Halt()
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(42, intp.execute());
  }
  
  @Test
  public void testExpr() {
    Instruction[] program = {
      new Ldi(5),
      new Ldi(2),
      new Mul(),
      new Ldi(3),
      new Mod(),
      new Not(),
      new Halt()
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(-4, intp.execute());
  }
  
  @Test
  public void testVariables() {
    Instruction[] program = {
      new Decl(3),
      new Ldi(5),
      new Sts(1),
      new Ldi(2),
      new Sts(2),
      new Ldi(3),
      new Sts(3),
      new Lfs(1),
      new Lfs(2),
      new Mul(),
      new Lfs(3),
      new Mod(),
      new Not(),
      new Halt()
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(-4, intp.execute());
  }
  
  @Test
  public void testControlFlow() {
    Instruction[] program = {
        new Decl(1),
        new Decl(1),
        new Decl(1),
        new Ldi(0),
        new Not(),
        new Ldi(7),
        new Ldi(3),
        new Cmp(CompareType.LT),
        new And(),
        new Brc(15),
        new Ldi(1),
        new Halt(),
        new Ldi(0),
        new Not(),
        new Brc(65),
        new Ldi(1),
        new Sts(1),
        new Ldi(2),
        new Sts(2),
        new Ldi(3),
        new Sts(3),
        new Ldi(1000),
        new Lfs(1),
        new Cmp(CompareType.LT),
        new Not(),
        new Brc(59),
        new Ldi(1),
        new Lfs(1),
        new Add(),
        new Sts(1),
        new Lfs(2),
        new Lfs(1),
        new Cmp(CompareType.LT),
        new Not(),
        new Not(),
        new Brc(56),
        new Ldi(1),
        new Lfs(2),
        new Add(),
        new Sts(2),
        new Lfs(3),
        new Lfs(1),
        new Cmp(CompareType.LT),
        new Not(),
        new Not(),
        new Brc(53),
        new Ldi(2),
        new Lfs(3),
        new Mul(),
        new Sts(3),
        new Ldi(0),
        new Not(),
        new Brc(40),
        new Ldi(0),
        new Not(),
        new Brc(30),
        new Ldi(0),
        new Not(),
        new Brc(21),
        new Lfs(3),
        new Lfs(2),
        new Add(),
        new Lfs(1),
        new Add(),
        new Halt()
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(3537, intp.execute());
  }

  @Test
  public void testFunctionCalls() {
    Instruction[] program = {
        new Ldi(26),
        new Call(0),
        new Halt(),
        new Lfs(-5),
        new Lfs(-4),
        new Lfs(-3),
        new Lfs(-2),
        new Lfs(-1),
        new Lfs(0),
        new Ldi(35),
        new Call(1),
        new Ldi(39),
        new Call(2),
        new Ldi(22),
        new Call(2),
        new Ldi(39),
        new Call(2),
        new Ldi(39),
        new Call(2),
        new Ldi(22),
        new Call(2),
        new Return(6),
        new Lfs(0),
        new Lfs(-1),
        new Add(),
        new Return(2),
        new Ldi(2),
        new Ldi(4),
        new Ldi(8),
        new Ldi(16),
        new Ldi(32),
        new Ldi(64),
        new Ldi(3),
        new Call(6),
        new Return(0),
        new Lfs(0),
        new Ldi(0),
        new Sub(),
        new Return(1),
        new Lfs(0),
        new Ldi(35),
        new Call(1),
        new Lfs(-1),
        new Add(),
        new Return(2),
    };
    Interpreter intp = new Interpreter(program);
    assertEquals(110, intp.execute());
  }

  @Test
  public void testFib() {
    Instruction[] program = {
        new Ldi(3),
        new Call(0),
        new Halt(),
        new Ldi(30),
        new Ldi(7),
        new Call(1),
        new Return(0),
        new Decl(4),
        new Lfs(0),
        new Ldi(1),
        new Cmp(CompareType.LT),
        new Not(),
        new Not(),
        new Brc(16),
        new Lfs(0),
        new Return(5),
        new Ldi(0),
        new Sts(1),
        new Ldi(1),
        new Sts(2),
        new Ldi(1),
        new Sts(3),
        new Lfs(0),
        new Lfs(3),
        new Cmp(CompareType.LT),
        new Not(),
        new Brc(44),
        new Lfs(1),
        new Sts(4),
        new Lfs(2),
        new Lfs(1),
        new Add(),
        new Sts(1),
        new Lfs(4),
        new Not(),
        new Not(),
        new Sts(2),
        new Ldi(1),
        new Lfs(3),
        new Add(),
        new Sts(3),
        new Ldi(0),
        new Not(),
        new Brc(22),
        new Ldi(2),
        new Lfs(0),
        new Sub(),
        new Ldi(7),
        new Call(1),
        new Lfs(1),
        new Add(),
        new Return(5),
    };
    
    Interpreter intp = new Interpreter(program);
    assertEquals(832040, intp.execute());
  }


}
