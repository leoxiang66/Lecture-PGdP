package asm;

public class InvalidThreadException extends InterpreterException {
  private static final long serialVersionUID = 1L;

  public InvalidThreadException(int id) {
    super("Invalid thread (id = " + id + ")");
  }
}
