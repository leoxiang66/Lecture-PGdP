import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Test;

public class WorkerTest {

  @Test(timeout = 1000)
  public void testSingle() throws InterruptedException {
    Queue<Integer> input = new Queue<>();
    Worker<Integer, Integer> incer = new Worker<>(input, new Queue<>(), x -> x + 1);
    incer.start();
    Worker<Integer, String> explainer = new Worker<>(incer.getOutput(), new Queue<>(), x -> "The value: " + x);
    explainer.start();

    Queue<String> output = explainer.getOutput();

    int n = 8;
    for (int i = 0; i < n; i++)
      input.enqueue(i);

    for (int i = 0; i < n; i++)
      assertEquals("The value: " + (i + 1), output.dequeue());

    incer.interrupt();
    explainer.interrupt();

    incer.join();
    explainer.join();
  }

  @Test(timeout = 1000)
  public void testMulti() throws InterruptedException {
    int workerCount = 10;
    Queue<Integer> input = new Queue<>();
    Queue<Integer> incOut = new Queue<>();
    ArrayList<Worker<Integer, Integer>> incers = new ArrayList<>();
    for (int i = 0; i < workerCount; i++) {
      Worker<Integer, Integer> w = new Worker<>(input, incOut, x -> x + 1);
      w.start();
      incers.add(w);
    }
    ArrayList<Worker<Integer, String>> explainers = new ArrayList<>();
    Queue<String> output = new Queue<>();
    for (int i = 0; i < workerCount; i++) {
      Worker<Integer, String> w = new Worker<>(incOut, output, x -> "The value: " + x);
      w.start();
      explainers.add(w);
    }

    int n = 8;
    for (int i = 0; i < n; i++)
      input.enqueue(i);

    HashSet<String> ref = new HashSet<>();
    for (int i = 0; i < n; i++)
      ref.add("The value: " + (i + 1));

    HashSet<String> act = new HashSet<>();
    for (int i = 0; i < n; i++)
      act.add(output.dequeue());

    assertEquals(ref, act);

    for (Worker<Integer, Integer> incer : incers) {
      incer.interrupt();
      incer.join();
    }
    for (Worker<Integer, String> explainer : explainers) {
      explainer.interrupt();
      explainer.join();
    }
  }

}
