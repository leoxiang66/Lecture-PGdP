package codegen;

public enum Bunop {
  Not
}
