
public class QueueAlternative<T> {
  private T[] elements;
  private int start;
  private int stop;
  
  @SuppressWarnings("unchecked")
  public QueueAlternative() {
    this.elements = (T[]) new Object[3];
    this.start = 0;
    this.stop = -1;
  }

  public synchronized void enqueue(T value) throws InterruptedException {
    while (stop >= 0 && (stop + 1) % elements.length == start)
      wait();
    
    stop = (stop + 1) % elements.length;
    elements[stop] = value;
    notifyAll();
  }

  public synchronized T dequeue() throws InterruptedException {
    while (stop == -1)
      wait();
    
    T value = elements[start];
    if(start == stop) {
      start = 0;
      stop = -1;
    } else
      start = (start + 1) % elements.length;
    
    notifyAll();
    return value;
  }
}
