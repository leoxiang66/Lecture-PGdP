import java.util.function.Function;

public class Worker<T, U> extends Thread {
  private Queue<T> input;
  private Queue<U> output;
  
  public Queue<U> getOutput() {
    return output;
  }
  
  private Function<T, U> func;
  
  public Worker(Queue<T> input, Queue<U> output, Function<T, U> func) {
    this.input = input;
    this.output = output;
    this.func = func;
  }

  @Override
  public void run() {
    while (true) {
      T next;
      try {
        next = input.dequeue();
        U result = func.apply(next);
        output.enqueue(result);
      } catch (InterruptedException e) {
        break;
      }
    }
  }

}
