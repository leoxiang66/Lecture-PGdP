
public class Queue<T> {
  private T[] elements;
  private int start;
  private int stop;

  private Object barrierProd = new Object();
  private Object barrierCons = new Object();

  @SuppressWarnings("unchecked")
  public Queue() {
    this.elements = (T[]) new Object[3];
    this.start = 0;
    this.stop = -1;
  }

  public void enqueue(T value) throws InterruptedException {
    synchronized (barrierProd) {
      while (stop >= 0 && (stop + 1) % elements.length == start)
        barrierProd.wait();
      synchronized (this) {
        stop = (stop + 1) % elements.length;
        elements[stop] = value;
      }
    }
    synchronized (barrierCons) {
      barrierCons.notify();
    }
  }

  public T dequeue() throws InterruptedException {
    T value;
    synchronized (barrierCons) {
      while (stop == -1)
        barrierCons.wait();
      synchronized (this) {
        value = elements[start];
        if (start == stop) {
          start = 0;
          stop = -1;
        } else
          start = (start + 1) % elements.length;
      }
    }
    synchronized (barrierProd) {
      barrierProd.notify();
    }
    return value;
  }
}
