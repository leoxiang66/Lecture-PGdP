package asm;

import util.Terminal;

public class Interpreter implements AsmVisitor {
  private int[] stack = new int[128];
  private int[] heap = new int[1024];
  private int heapTop = 0;
  private int stackPointer = -1;
  private int programCounter = 0;
  private int framePointer = -1;
  private Instruction[] program;
  private boolean halted;
  private int[] registers = new int[2];

  private boolean declAllowed = true;

  public static int true_() {
    return -1;
  }

  public static int false_() {
    return 0;
  }

  public int pop() {
    if (stackPointer < 0)
      throw new StackUnderflowException();
    return stack[stackPointer--];
  }

  public void push(int value) {
    stackPointer++;
    if (stackPointer >= stack.length)
      throw new StackOverflowException();
    stack[stackPointer] = value;
  }

  public Interpreter(Instruction[] program) {
    this.program = program;
  }

  public int execute() {
    while (!halted) {
//      System.out.println("Executing instruction at " + programCounter);
      Instruction next = program[programCounter];
      programCounter++;
      next.accept(this);
    }
    return stack[stackPointer];
  }

  @Override
  public void visit(Add add) {
    int a = pop();
    int b = pop();
    push(a + b);
    declAllowed = false;
  }

  @Override
  public void visit(Decl decl) {
    if (!declAllowed)
      throw new InvalidDeclarationException();
    if (decl.getCount() < 0)
      throw new InvalidStackAllocationException();
    stackPointer += decl.getCount();
  }

  @Override
  public void visit(And and) {
    int a = pop();
    int b = pop();
    push(a & b);
    declAllowed = false;
  }

  @Override
  public void visit(Brc brc) {
    if (brc.getTarget() < 0 || brc.getTarget() > program.length)
      throw new InvalidJumpTargetException();
    int cond = pop();
    if (cond == -1)
      programCounter = brc.getTarget();
    declAllowed = false;
  }

  @Override
  public void visit(Call call) {
    if (call.getArgCount() < 0)
      throw new InvalidNumberOfMethodParametersException();
    int functionAddress = pop();
    if (functionAddress < 0 || functionAddress >= program.length)
      throw new InvalidMethodAddressException();
    int[] arguments = new int[call.getArgCount()];
    for (int i = 0; i < arguments.length; i++)
      arguments[i] = pop();
    push(programCounter);
    push(framePointer);
    for (int i = 0; i < arguments.length; i++)
      push(arguments[arguments.length - 1 - i]);
    framePointer = stackPointer;
    programCounter = functionAddress;
    declAllowed = true;
  }

  @Override
  public void visit(Cmp cmp) {
    int a = pop();
    int b = pop();
    switch (cmp.getCompareType()) {
      case EQ:
        push(a == b ? true_() : false_());
        break;
      case LT:
        push(a < b ? true_() : false_());
    }
    declAllowed = false;
  }

  @Override
  public void visit(Div div) {
    int a = pop();
    int b = pop();
    push(a / b);
    declAllowed = false;
  }

  @Override
  public void visit(Halt halt) {
    halted = true;
  }

  @Override
  public void visit(Ldi ldi) {
    push(ldi.getValue());
    declAllowed = false;
  }

  @Override
  public void visit(Lfs lds) {
    int stackAddress = framePointer + lds.getIndex();
    if (stackAddress < 0 || stackAddress >= stack.length)
      throw new InvalidStackAccessException();
    push(stack[stackAddress]);
    declAllowed = false;
  }

  @Override
  public void visit(Mod mod) {
    int a = pop();
    int b = pop();
    push(a % b);
    declAllowed = false;
  }

  @Override
  public void visit(Mul mul) {
    int a = pop();
    int b = pop();
    push(a * b);
    declAllowed = false;
  }

  @Override
  public void visit(Nop nop) {
    declAllowed = false;
  }

  @Override
  public void visit(Not not) {
    int a = pop();
    push(~a);
    declAllowed = false;
  }

  @Override
  public void visit(Or or) {
    int a = pop();
    int b = pop();
    push(a | b);
    declAllowed = false;
  }

  @Override
  public void visit(Pop pop) {
    int a = pop();
    registers[pop.getRegister()] = a;
    declAllowed = false;
  }

  @Override
  public void visit(Push push) {
    push(registers[push.getRegister()]);
    declAllowed = false;
  }

  @Override
  public void visit(In read) {
    int value = Terminal.askInt("Zahl eingeben: ");
    push(value);
    declAllowed = false;
  }

  @Override
  public void visit(Sts sts) {
    int stackAddress = framePointer + sts.getIndex();
    if (stackAddress < 0 || stackAddress >= stack.length)
      throw new InvalidStackAccessException();
    int value = pop();
    stack[stackAddress] = value;
    declAllowed = false;
  }

  @Override
  public void visit(Sub sub) {
    int a = pop();
    int b = pop();
    push(a - b);
    declAllowed = false;
  }

  @Override
  public void visit(Out write) {
    int value = pop();
    System.out.println(value);
    declAllowed = false;
  }

  @Override
  public void visit(Return ret) {
    if (ret.getCells() < 0)
      throw new InvalidStackFrameSizeException();
    int retVal = pop();
    for (int i = 0; i < ret.getCells(); i++)
      pop();
    framePointer = pop();
    if (framePointer < -1 || framePointer >= stack.length)
      throw new InvalidFramePointerException();
    programCounter = pop();
    if (programCounter < 0 || programCounter >= program.length)
      throw new InvalidReturnAddressException();
    push(retVal);
    declAllowed = false;
  }

  @Override
  public void visit(Lfh lfh) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    push(heap[hAddr]);
  }

  @Override
  public void visit(Sth sth) {
    int hAddr = pop();
    if (hAddr < 0 || hAddr >= heap.length)
      throw new HeapAccessException();
    int value = pop();
    heap[hAddr] = value;
  }

  @Override
  public void visit(Alloc alloc) {
    int size = pop();
    if (size == 0)
      // Zwei verschiedene Objekte dürfen nicht identisch sein!
      size++;
    if (size < 0 || heapTop + size > heap.length)
      throw new HeapAllocationException();
    push(heapTop);
    heapTop += size;
  }

}
