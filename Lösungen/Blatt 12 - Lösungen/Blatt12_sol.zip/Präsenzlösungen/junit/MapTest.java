import org.junit.*;

public class MapTest {
    static private Fun<Integer, String> f;
    static private Integer[] a;
    static private String[] b;
    static private String[] b_ok;

    @Before
    public void init() {
        f = new IntToString();
        a = new Integer[42];
        for (int i = 0; i < a.length; ++i)
            a[i] = i;
        b = new String[a.length];
        b_ok = new String[a.length];
        for (int i = 0; i < b_ok.length; ++i)
            b_ok[i] = Integer.toString(i);
    }

    @After
    public void tidyUp() {
        f = null;
        a = null;
        b = null;
        b_ok = null;
    }

    @BeforeClass
    @AfterClass
    public static void checkIfEmpty() {
        Assert.assertNull(f);
        Assert.assertNull(a);
        Assert.assertNull(b);
        Assert.assertNull(b_ok);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow1() throws InterruptedException {
        Map.map(null, a, b, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow2() throws InterruptedException {
        Map.map(f, null, b, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow3() throws InterruptedException {
        Map.map(f, a, null, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow4() throws InterruptedException {
        String[] bb = new String[a.length-1];
        Map.map(f, a, bb, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow5() throws InterruptedException {
        Map.map(f, a, b, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrow6() throws InterruptedException {
        Map.map(f, a, b, -123);
    }

    @Test
    public void test() throws InterruptedException {
        for (int i = 1; i <= a.length; ++i) {
            init();
            Map.map(f, a, b, i);
            Assert.assertArrayEquals(b, b_ok);
        }
    }

}
