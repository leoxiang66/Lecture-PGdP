public class MutableIntDoubleList {
  private IntDoubleListElement elements;

  public MutableIntDoubleList() {
    // Am anfang hat die Liste keine Elemente
    elements = null;
  }

  // Elemente hinzufuegen
  public void append(int info) {
    IntDoubleListElement newElement = new IntDoubleListElement(info);
    IntDoubleListElement temp = elements;
    // Falls Liste leer ist
    if (elements == null)
      elements = newElement;
    else {
      // Falls List nicht leer ist, letze Element erreichen und neues Element
      // hinzufuegen
      while (temp.next != null) {
        temp = temp.next;
      }
      temp.next = newElement;
      newElement.prev = temp;
    }
  }

  public int size() {
    IntDoubleListElement temp = elements;
    int j = 0;
    // Zahlen wieviele Elemente es gibt, bis null erreicht wird
    while (temp != null) {
      temp = temp.next;
      j++;
    }
    return j;
  }

  public void remove(int pos) {
    IntDoubleListElement temp = elements;
    // Wenn pos > size, Fehler melden
    if (this.size() <= pos)
      System.out.println("Position ist grosser als Liste!");
    // Falls pos==0, muss man den Kopf der Liste verlinken
    else if (pos == 0) {
      elements = elements.next;
      elements.prev = null;
    } else {
      // Falls pos !=0 muss man das Elemente Nr. pos -1 mit Element Nr. pos + 1 linken
      int j = 0;
      while (j < pos - 1) {
        temp = temp.next;
        j++;
      }
      temp.next = temp.next.next;
      if(temp.next != null)
        temp.next.prev = temp;
    }
  }

  public String toString() {
    IntDoubleListElement temp = elements;
    String ret = "";
    // Liste iterieren
    while (temp != null) {
      // String iterativ konkatenieren
      ret = ret + temp.getInfo();
      if (temp.next != null)
        // Komma hinzufuegen falls temp nicht das letze Element der List ist
        ret = ret + ',';
      temp = temp.next;
    }
    return ret;
  }

  public int sum() {
    IntDoubleListElement temp = elements;
    int ret = 0;
    // Liste iterien
    while (temp != null) {
      // Iterativ summieren
      ret = ret + temp.getInfo();
      temp = temp.next;
    }
    return ret;
  }

  public IntDoubleListElement getFirstElement() {
    return elements;
  }

  public IntDoubleListElement getLastElement() {
    IntDoubleListElement ret;
    IntDoubleListElement temp = elements;
    // Falls Liste leer ist, null zurueckgeben
    if (elements == null)
      ret = null;
    else {
      // Falls liste nicht leer ist, letzes Element suchen
      while (temp.next != null) {
        temp = temp.next;
      }
      ret = temp;
    }
    return ret;
  }

  // Kopie der interne Elemente erstellen
  public MutableIntDoubleList copy() {
    MutableIntDoubleList ret = new MutableIntDoubleList();
    // temp1 hilft ueber "elements" zu iterieren
    IntDoubleListElement temp1 = elements;
    while (temp1.next != null) {
      // Wert in Kopie speichern
      ret.append(temp1.getInfo());
      temp1 = temp1.next;
    }
    return ret;
  }

  public IntDoubleListElement[] search(int intValue) {
    IntDoubleListElement[] ret = new IntDoubleListElement[this.size()];
    int j = 0;
    // temp1 hilft ueber "elements" zu iterieren
    IntDoubleListElement temp1 = elements;
    while (temp1 != null) {
      // Wert in Kopie speichern
      if (temp1.getInfo() == intValue)
        ret[j] = temp1;
      j++;
      temp1 = temp1.next;
    }
    return ret;
  }

  public MutableIntDoubleList reverse() {
    MutableIntDoubleList ret;
    // Letze Element erreichen
    IntDoubleListElement temp = elements;
    if (elements == null)
      ret = null;
    else {
      // Liste nach vorne iterien
      while (temp.next != null) {
        // Iterativ summieren
        temp = temp.next;
      }
      // Liste nach vorne iterien und neue Liste erstellen
      ret = new MutableIntDoubleList();
      while (temp.prev != null) {
        ret.append(temp.getInfo());
        temp = temp.prev;
      }

    }
    return ret;
  }

}