public class Test {
  public static void main(String[] args) {
    // Teste einfach verkettete Listen
    // Deklaration und Instanziierung des IntList-Objekts
    MutableIntList l = new MutableIntList();
    // Hinzufuegen von Elemente
    l.append(1);
    l.append(2);
    l.append(3);
    l.append(4);
    l.append(5);
    l.append(6);
    l.append(7);
    l.append(8);
    l.append(9);
    l.append(10);
    // Teste toString()
    System.out.println("Liste enhaelt: " + l.toString());
    // Teste size()
    System.out.println("Lange ist: " + l.size());
    // Teste remove(pos)
    l.remove(0);
    System.out.println("Liste enhaelt jetzt: " + l.toString());
    // Teste sum()
    System.out.println("Sume ist: " + l.sum());
    // Teste getLastElement()
    System.out.println("Letzte Element ist: " + l.getLastElement().getInfo());
    // Teste copy()
    MutableIntList l2 = l.copy();
    l.remove(0);
    // Vergleich original Liste mit Kopie
    System.out.println(l.toString());
    System.out.println(l2.toString());
    // Teste reverse()
    MutableIntList l3 = l2.reverse();
    System.out.println("Liste enhaelt: " + l3.toString());
    System.out.println("Ergebnisse Suche: ");
    IntListElement[] res = l3.search(5);
    for (int i = 0; i < l3.size(); i++)
      if (res[i] != null)
        System.out.println(res[i].getInfo());
    System.out.println("/++++Teste DV Listen++++/");
    // ---------------------------------------------------
    // Teste doppelt verkettete Listen
    // Deklaration und Instanziierung des IntList-Objekts
    MutableIntDoubleList dl = new MutableIntDoubleList();
    // Hinzufuegen von Elemente
    dl.append(1);
    dl.append(2);
    dl.append(3);
    dl.append(4);
    dl.append(5);
    dl.append(6);
    dl.append(7);
    dl.append(8);
    dl.append(9);
    dl.append(10);
    // Teste toString()
    System.out.println("Liste enhaelt: " + dl.toString());
    // Teste size()
    System.out.println("Lange ist: " + dl.size());
    // Teste remove(pos)
    dl.remove(0);
    System.out.println("Liste enhaelt jetzt: " + dl.toString());
    // Teste sum()
    System.out.println("Sume ist: " + dl.sum());
    // Teste getLastElement()
    System.out.println("Letzte Element ist: " + dl.getLastElement().getInfo());
    // Teste copy()
    MutableIntDoubleList dl2 = dl.copy();
    dl.remove(0);
    // Vergleich original Liste mit Kopie
    System.out.println(dl.toString());
    System.out.println(dl2.toString());
    // Teste reverse()
    MutableIntDoubleList dl3 = dl2.reverse();
    System.out.println("Liste enhaelt: " + dl3.toString());
    System.out.println("Ergebnisse Suche: ");
    IntDoubleListElement[] dres = dl3.search(5);
    for (int i = 0; i < dl3.size(); i++)
      if (dres[i] != null)
        System.out.println(dres[i].getInfo());
  }
}