public class IntDoubleListElement {
  private int info;
  
  public void setInfo(int inf) {
    info = inf;
  }

  public int getInfo() {
    return info;
  }

  public IntDoubleListElement next;
  public IntDoubleListElement prev;

  public IntDoubleListElement(int startInfo) {
    info = startInfo;
    next = null;
    prev = null;
  }
}
