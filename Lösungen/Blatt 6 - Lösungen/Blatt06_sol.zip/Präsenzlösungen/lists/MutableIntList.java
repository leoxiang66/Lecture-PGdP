public class MutableIntList {
  private IntListElement elements;

  public MutableIntList() {
    // Am anfang hat die Liste keine Elemente
    elements = null;
  }

  // Elemente hinzufuegen
  public void append(int info) {
    IntListElement newElement = new IntListElement(info);
    IntListElement temp = elements;
    // Falls Liste leer ist
    if (elements == null)
      elements = newElement;
    else {
      // Falls List nicht leer ist, letze Element erreichen und neues Element
      // hinzufuegen
      while (temp.next != null) {
        temp = temp.next;
      }
      temp.next = newElement;
    }
  }

  public int size() {
    IntListElement temp = elements;
    int j = 0;
    // Zahlen wieviele Elemente es gibt, bis null erreicht wird
    while (temp != null) {
      temp = temp.next;
      j++;
    }
    return j;
  }

  public void remove(int pos) {
    // Wenn pos > size, Fehler melden
    if (this.size() <= pos)
      System.out.println("Position ist grosser als Liste!");
    // Falls pos==0, muss man den Kopf der Liste verlinken
    else if (pos == 0)
      elements = elements.next;
    else {
      // Falls pos !=0 muss man das Elemente Nr. pos -1 mit Element Nr. pos + 1 linken
      IntListElement temp = elements;
      int j = 0;
      while (j < pos - 1) {
        temp = temp.next;
        j++;
      }
      temp.next = temp.next.next;
    }
  }

  public String toString() {
    IntListElement temp = elements;
    String ret = "";
    // Liste iterieren
    while (temp != null) {
      // String iterativ konkatenieren
      ret = ret + temp.getInfo();
      if (temp.next != null)
        // Komma hinzufuegen falls temp nicht das letze Element der List ist
        ret = ret + ',';
      temp = temp.next;
    }
    return ret;
  }

  public int sum() {
    IntListElement temp = elements;
    int ret = 0;
    // Liste iterien
    while (temp != null) {
      // Iterativ summieren
      ret = ret + temp.getInfo();
      temp = temp.next;
    }
    return ret;
  }

  public IntListElement getFirstElement() {
    return elements;
  }

  public IntListElement getLastElement() {
    IntListElement ret;
    IntListElement temp = elements;
    // Falls Liste leer ist, null zurueckgeben
    if (elements == null)
      ret = null;
    else {
      // Falls liste nicht leer ist, letzes Element suchen
      while (temp.next != null) {
        temp = temp.next;
      }
      ret = temp;
    }
    return ret;
  }

  // Kopie der interne Elemente erstellen
  public MutableIntList copy() {
    MutableIntList ret = new MutableIntList();
    // temp1 hilft ueber "elements" zu iterieren
    IntListElement temp1 = elements;
    while (temp1 != null) {
      // Wert in Kopie speichern
      ret.append(temp1.getInfo());
      temp1 = temp1.next;
    }
    return ret;
  }

  public IntListElement[] search(int intValue) {
    IntListElement[] ret = new IntListElement[this.size()];
    int j = 0;
    // temp1 hilft ueber "elements" zu iterieren
    IntListElement temp1 = elements;
    while (temp1.next != null) {
      // Wert in Kopie speichern
      if (temp1.getInfo() == intValue)
        ret[j] = temp1;
      j++;
      temp1 = temp1.next;
    }
    return ret;
  }

  public int[] toArray() {
    IntListElement temp = elements;
    // Array der Laenge size() ist initialisiert
    int[] ret = new int[this.size()];
    int i = 0;
    // elements wird iteriert und jedes element zu ret hinzugefuegt
    while (temp != null) {
      ret[i] = temp.getInfo();
      temp = temp.next;
      i++;
    }
    return ret;
  }

  public MutableIntList reverse() {
    if (elements == null)
      return null;
    IntListElement prev = null;
    IntListElement tmp = elements;
    IntListElement tmp2 = null;
    while (tmp != null) {
      // Kopiere info
      tmp2 = new IntListElement(tmp.getInfo());
      // Next von Kopie is prev
      tmp2.next = prev;
      prev = tmp2;
      tmp = tmp.next;
    }
    MutableIntList ret = new MutableIntList();
    ret.elements = tmp2;
    return ret;
  }

//Alternative Loesung zu reverse
  public MutableIntList reverse2() {
    // Liste ist als array gespeichert
    int[] arrayTemp = new int[this.size()];
    arrayTemp = this.toArray();
    // Array wird umgedreht mit Methode von PA2
    arrayTemp = reverseArray(arrayTemp);
    // Ergebniss wird als Liste gespeichert und zurueckgegeben
    MutableIntList ret = fromArray(arrayTemp);
    return ret;
  }

  public static MutableIntList fromArray(int[] ar) {
    MutableIntList ret = new MutableIntList();
    // Werte von array werden gelesen und in Liste hinzuegefuegt
    for (int i = 0; i < ar.length; i++) {
      ret.append(ar[i]);
    }
    return ret;
  }

  // Von PA2
  public static int[] reverseArray(int[] array) {
    int revArray[] = new int[array.length];
    for (int i = 0; i < array.length; i++)
      revArray[i] = array[array.length - (i + 1)];
    return revArray;
  }

}