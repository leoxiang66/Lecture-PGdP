public class IntListElement {
  private int info;

  public int getInfo() {
    return info;
  }

  public void setInfo(int info) {
    this.info = info;
  }

  public IntListElement next;

  public IntListElement(int startInfo) {
    info = startInfo;
    next = null;
  }



}
