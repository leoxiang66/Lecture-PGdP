public class BinarySearch {
  public static int binarySearch(int[] array, int x) {
    int left = 0;
    int right = array.length;
    int pivot = (left + right) / 2; // pivot = middle element

    // conditions: we are not out of bounds & left and right are not overlapping
    while (left <= right && pivot >= 0 && pivot <= array.length - 1) {
        // we found our element!
        if (array[pivot] == x)
            return pivot;
        // x is greater than pivot
        else if (array[pivot] < x)
            left = pivot + 1;
        // x is smaller than pivot
        else
            right = pivot - 1;

        pivot = (left + right) / 2; //we must reset pivot before checking another time
    }
    // x is not in the array
    return -1;
  }

  public static void main(String[] args) {
    int[] a = {1, 5, 19, 22, 109, 200};
    System.out.println(binarySearch(a, 22));
    System.out.println(binarySearch(a, 42));
  }
}
