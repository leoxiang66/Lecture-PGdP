
import java.util.Arrays;

public class MergeSort {
  private static int[] merge(int[] a, int[] b) {
    int[] merged = new int[a.length + b.length];
    int aIndex = 0;
    int bIndex = 0;
    for (int i = 0; i < merged.length; i++) {
      if (aIndex >= a.length)
        merged[i] = b[bIndex++];
      else if (bIndex >= b.length)
        merged[i] = a[aIndex++];
      else if (a[aIndex] < b[bIndex])
        merged[i] = a[aIndex++];
      else
        merged[i] = b[bIndex++];
    }
    return merged;
  }

  public static int[] mergeSortIt(int[] a) {
    // Wir teilen zunächst das Array in a.length viele 1-elementige Arrays auf
    int[][] parts = new int[a.length][];
    for (int i = 0; i < a.length; i++)
      parts[i] = new int[] { a[i] };
    // Wir mergen wiederholt je zwei benachbarte Arrays, bis nur mehr ein Teil-Array
    // über bleibt.
    while (parts.length > 1) {
      int[][] partsNew = new int[(parts.length + 1) / 2][];
      for (int i = 0; i < partsNew.length; i++) {
        if (2 * i + 1 < parts.length)
          partsNew[i] = merge(parts[2 * i], parts[2 * i + 1]);
        else
          // Ist die Länge nicht durch zwei teilbar, übernehmen wir den letzten Teil-Array
          // einfach
          partsNew[i] = parts[2 * i];
      }
      parts = partsNew;
    }
    return parts[0];
  }

  public static void main(String[] args) {
    int[] x = { 1, 4, -1, 5, 3, 9, 20, -20, 10, 4 };
    System.out.println(Arrays.toString(mergeSortIt(x)));
  }

}
