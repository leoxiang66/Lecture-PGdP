import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

public class MergeSortTest {

  @Test
  public void testMergeSort() {
    Random rand = new Random(42);
    int[] numbers = new int[1000000];
    for(int i = 0; i < numbers.length; i++)
      numbers[i] = rand.nextInt();
    int[] numbersCopy = Arrays.copyOf(numbers, numbers.length);
    int[] numbersStud = MergeSort.mergeSortIt(numbers);
    assertNotEquals("Kein neues Feld erzeugt", numbersStud, numbers);
    Arrays.sort(numbersCopy);
    assertArrayEquals("Feld nicht korrekt sortiert.", numbersCopy, numbersStud);
    
    assertTrue("Bitte prüfen, dass wirklich ein iteratives MergeSort implementiert wird!", false);
  }

}
