package asm;

public enum Opcode {
  NOP,
  ADD,
  SUB,
  MUL,
  MOD,
  DIV,
  AND,
  OR,
  NOT,
  SHL,
  LDI,
  LFS,
  STS,
  CALL,
  RETURN,
  BRC,
  CMP,
  IN,
  OUT,
  DECL,
  PUSH,
  POP,
  HALT;
}
