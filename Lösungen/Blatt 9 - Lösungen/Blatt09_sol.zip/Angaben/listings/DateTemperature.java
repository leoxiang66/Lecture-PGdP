import java.util.Date;

public class DateTemperature {
  final private Date date;
  final private double temperature;

  public DateTemperature(final Date date, final double temperature) {
    this.date = date;
    this.temperature = temperature;
  }

  public double getTemperature() {
    return temperature;
  }

  public Date getDate() {
    return date;
  }
}
