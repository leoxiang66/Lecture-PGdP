
public abstract class Grundflaeche {
  public abstract void accept(Visitor visitor);
}
