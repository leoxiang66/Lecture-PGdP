#!/bin/bash

javac -cp /usr/share/maven-repo/junit/junit/4.12/junit-4.12.jar:/usr/share/java/hamcrest-core-1.3.jar:. *.java
