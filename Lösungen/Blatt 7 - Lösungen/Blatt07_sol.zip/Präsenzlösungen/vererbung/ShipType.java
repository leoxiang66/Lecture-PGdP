
public enum ShipType {
  Sailboat, Motorboat
}
