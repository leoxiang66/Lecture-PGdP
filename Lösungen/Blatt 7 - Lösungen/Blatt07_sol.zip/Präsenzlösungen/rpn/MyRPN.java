package rpn;

public class MyRPN {

  static void eval(String[] input, IntStack stack) {
    if (input != null) {
      for (String s : input) {
        switch (s) {
          case "^2":
            stack.push(stack.peek() * stack.pop());
            break;
          case "+":
            stack.push(stack.pop() + stack.pop());
            break;
          case "*":
            stack.push(stack.pop() * stack.pop());
            break;
          default:
            stack.push(Integer.valueOf(s));
        }
      }
    }
  }

  public static void main(String[] args) {
//	   12 -43 ^2 +
    IntStack intStack = new IntStack();
    eval(new String[] { "12", "-43", "+", "^2" }, intStack);
    System.out.println("RPN 1: " + intStack.pop());

//     4 3 5 * +
    intStack = new IntStack();
    eval(new String[] { "4", "3", "5", "*", "+" }, intStack);
    System.out.println("RPN 2: " + intStack.pop());
  }

}
