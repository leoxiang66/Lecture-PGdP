public class Quicksort {

  private static void quicksort(int[] numbers, int left, int right) {
    if (right > left) { // sonst ist nichts (mehr) zu tun
      // Partitionieren und neuen Index des Pivot-Elements sichern:
      // int pivotIndex = partition(numbers, left, right);
      int pivotIndex = partitionRek(numbers, left, right);
      // Sortiere linke Seite:
      quicksort(numbers, left, pivotIndex - 1);
      // Sortiere rechte Seite:
      quicksort(numbers, pivotIndex + 1, right);
    }
  }

  private static int partition(int[] numbers, int left, int right) {
    int leftScan = left; // Links auf das erste Element
    int rightScan = right; // Rechts auf das letzte Element
    int pivot = numbers[right]; // Wahl des Pivot-Elements

    while (leftScan < rightScan) {
      while (leftScan < rightScan && numbers[leftScan] < pivot) {
        leftScan++; // eins weiter nach rechts
      }
      while (leftScan < rightScan && numbers[rightScan] >= pivot) {
        rightScan--; // eins weiter nach links
      }
      if (leftScan < rightScan) { // Falls leftScan und rightScan sich noch
        // nicht kreuzen, dann Elemente tauschen
        swap(numbers, leftScan, rightScan);
      }
      // Ansonsten ist die Partition fertig
    }
    // Pivot-Element an die Nahtstelle bringen
    swap(numbers, leftScan, right);
    return leftScan; // Index der Nahtstelle ausliefern
  }

  private static void swap(int[] numbers, int index1, int index2) {
    int temp = numbers[index1];
    numbers[index1] = numbers[index2];
    numbers[index2] = temp;
  }

  public static void main(String[] args) {
    // Initialisierung
    int count = 20;
    int[] test = new int[count];
    for (int i = 0; i < test.length; i++) {
      test[i] = (int) (10 * Math.random());
      System.out.print(test[i] + " ");
    }
    System.out.println();

    // Sortieren
    quicksort(test, 0, test.length - 1);

    // Ausgabe des sortierten Feldes
    for (int i = 0; i < test.length; i++) {
      System.out.print(test[i] + " ");
    }
    System.out.println();
  }

  // Ohne Schleifchen partitionieren:
  private static int partitionRek(int[] numbers, int left, int right) {
    return partitionRek(numbers, right, left, right);
  }

  private static int partitionRek(int[] numbers, int pivotIndex, int left, int right) {
    if (left >= right) {
      swap(numbers, pivotIndex, right);
      return right;
    }
    int pivot = numbers[pivotIndex];
    if (numbers[left] < pivot) {
      return partitionRek(numbers, pivotIndex, left + 1, right);
    }
    if (numbers[right] >= pivot) {
      return partitionRek(numbers, pivotIndex, left, right - 1);
    }
    swap(numbers, left, right);
    return partitionRek(numbers, pivotIndex, left, right);
  }
}
