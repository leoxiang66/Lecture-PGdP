/**
 * This class represents a set words and its counts.
 * 
 * This class ensures, that no empty words are added and that the word count is
 * always greater than or equal to <code>0</code>.
 *
 */
public class WordCountsArray {
  /**
   * the administered WordCount-objects
   */
  private WordCount[] wordCounts;

  /**
   * the actual number of administered WordCount-objects
   */
  private int actualSize;

  /**
   * the maximum number of administrable WordCount-objects; not final because of
   * Uebung 3 g)
   */
  private int maxSize;

  /**
   * Creates a new instance of this class.
   * 
   * The created instance is able to administer at most <code>maxSize</code>
   * words.
   * 
   * @param maxSize the maximum number of words that can be administered by this
   *                instance
   */
  public WordCountsArray(int maxSize) {
    if (maxSize < 0) {
      this.maxSize = 0;
    } else {
      this.maxSize = maxSize;
    }

    this.actualSize = 0;
    this.wordCounts = new WordCount[this.maxSize];
  }

  /**
   * Adds the specified word with the specified count to this instance.
   * 
   * This method creates a new {@link WordCount} instance and administers this
   * newly created instance. If the specified word is <code>null</code>, nothing
   * will be added. If the specified count is lower than <code>0</code>, the count
   * will be set to <code>0</code>, according to
   * {@link WordCount#WordCount(String, int)}.
   * 
   * @param word  the word to be added
   * @param count the count of the word to be added
   */
  public void add(String word, int count) {
    if (word == null || word.equals("")) {
      return;
    }

    /*
     * if we have reached the end of the array, increase the array size
     */
    if (actualSize == maxSize) {
      this.doubleSize();
    }

    this.wordCounts[actualSize] = new WordCount(word, count);
    this.actualSize++;
  }

  /**
   * Returns the number of words currently administered by this instance.
   * 
   * @return the number of words currently administered by this instance
   */
  public int size() {
    return this.actualSize;
  }

  /**
   * Returns the word at the position <code>index</code> of the
   * {@link WordCount}-Array.
   * 
   * @param index the index
   * @return the word at the specified <code>index</code> or <code>null</code>, if
   *         the specified <code>index</code> is illegal.
   */
  public String getWord(int index) {
    if (this.wordCounts[index] != null)
      return this.wordCounts[index].getWord();
    return "";
  }

  /**
   * Returns the count of the word at position <code>index</code> of the
   * {@link WordCount}-Array.
   * 
   * @param index the index
   * @return the count of the word at the specified <code>index</code> or
   *         <code>-1</code>, if the specified <code>index</code> is illegal
   */
  public int getCount(int index) {
    if (index < 0 || index >= this.actualSize) {
      return -1;
    }

    return this.wordCounts[index].getCount();
  }

  /**
   * Sets the count of the word at position <code>index</code> of the
   * {@link WordCount}-Array to the specified <code>count</code>.
   * 
   * If the specified <code>index</code> is illegal, nothing will happen. If the
   * specified <code>count</code> is lower than <code>0</code>, the count is set
   * to <code>0</code>.
   * 
   * @param index the index of the word whose frequency will be changed
   * @param count the new frequency of the word at position <code>index</code>
   */
  public void setCount(int index, int count) {
    if (index < 0 || index >= this.actualSize) {
      return;
    }

    if (count < 0) {
      this.wordCounts[index].setCount(0);
    } else {
      this.wordCounts[index].setCount(count);
    }
  }

  /**
   * Doubles the number of administerable WordCount-objects,
   */
  private void doubleSize() {
    this.maxSize = this.maxSize * 2;

    /* would be stupid, if former size was 0, so take action... */
    if (this.maxSize <= 0) {
      this.maxSize = 1;
    }

    WordCount[] newWordCounts = new WordCount[this.maxSize];

    /* copy old array */
    for (int i = 0; i < this.wordCounts.length; i++) {
      newWordCounts[i] = this.wordCounts[i];
    }

    this.wordCounts = newWordCounts;
  }
}
