public class Feldverarbeitung {

  public static void main(String[] args) {
    int n;
    n = Terminal.askInt("Bitte geben Sie die Groeße des Arrays ein.");
    while(n < 2) {
      n = Terminal.askInt("Bitte geben Sie eine gueltige Groeße ein.");
    }
    
    int[] array = new int[n];
    int i = 0;
    while(i < n) {
      array[i] = Terminal.askInt("Bitte geben Sie das naechste Element ein.");
      i++;
    }
    
    // Teilaufgabe a
    i = 0;
    int r = 0;
    while(i < n) {
      r += -(2*(i % 2) - 1)*array[i];
      i++;
    }
    System.out.println(r);
    
    // Teilaufgabe b
    int max1 = Math.max(array[0], array[1]);
    int max2 = Math.min(array[0], array[1]);
    i = 1;
    while(i < n) {
      if(array[i] > max1) {
        // Ein neues groeßtes Element wurde gefunden; das bisherige
        // maximum wird einen Platz nach hinten verschoben.
        max2 = max1;
        max1 = array[i];
      } else if(array[i] > max2) {
        // Ein neues zweitgroeßes Element wurde gefunden; wir
        // tauschen das bisherige Element mit diesem aus.
        max2 = array[i];
      }
      i++;
    }
    System.out.println(max2);
    
    // Teilaufgabe c
    i = 0;
    while(i + 1 < n) {
      array[i] += array[i + 1];
      i += 2;
    }
    
    i = 0;
    while(i < n) {
      System.out.println(array[i]);
      i++;
    }
  }

}
