
public class Odd {

  public static void main(String[] args) {
    int max = 30; // max ist gerade!
    int[] odd = new int[max/2];
    for(int i = 1; i < max; i += 2)
      odd[i/2] = i;
    
    System.out.print("Aufsteigend:");
    for(int i = 0; i < odd.length; i++)
      System.out.print(" " + odd[i]);
    System.out.println();

    System.out.print("Absteigend:");
    for(int i = 0; i < odd.length; i++)
      System.out.print(" " + odd[odd.length - 1 - i]);
    System.out.println();
  }

}
