
public class Motor {
  int leistung;
  int gewicht;
  int drehmoment;
  int zylinder;
  double hubraum;

  public Motor(int pLeistung, int pGewicht, int pDrehmoment, int pZylinder, 
               double pHubraum) {
    this.leistung = pLeistung;
    this.gewicht = pGewicht;
    this.drehmoment = pDrehmoment;
    this.zylinder = pZylinder;
    this.hubraum = pHubraum;
  }
}
