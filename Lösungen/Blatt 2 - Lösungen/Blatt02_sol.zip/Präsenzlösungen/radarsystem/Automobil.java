
public class Automobil {
  int sitze;
  String farbe;
  int maxV;
  int momV;
  String kennzeichen;
  Motor motor;

  public Automobil(int sitze, String farbe, int maxV, Motor motor) {
    this.sitze = sitze;
    this.farbe = farbe;
    this.maxV = maxV;
    this.motor = motor;
  }

  /**
   * Berechnet die zurückgelegte Distanz des Automobils abhängig von einer Zeitspanne t
   * 
   * @param t: Zeitspanne in h
   * @return
   */
  public int getDistance(int dauer) {
    int s = this.momV * dauer;
    return s;
  }

  /**
   * Berechnet die zurückgelegte Distanz des Automobils abhängig von einer Zeitspanne
   * zeitspanne
   * 
   * @param zeitspanne: Spezifiziert die Zeitspanne durch einen End- und
   *        Startzeitpunkt
   * @return
   */
  public long getDistanceByTimespan(Zeitspanne zeitspanne) {
    long s = this.momV * zeitspanne.getTimespan();
    return s;
  }
}
