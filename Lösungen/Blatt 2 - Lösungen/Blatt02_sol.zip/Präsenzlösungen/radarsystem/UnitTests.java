import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

import org.junit.*;
import org.junit.Test;

public class UnitTests {
  private ArrayList<String> reqAttr;

  @Before
  public void init() {
    reqAttr = new ArrayList<String>();
    reqAttr.add("Automobil");
    reqAttr.add("Motor");
    reqAttr.add("Radar");
  }

  @Test
  public void testAutomobilGetDistance() throws Exception {
    Motor motorAutomobilBlau = new Motor(77, 1200, 150, 4, 2.0);
    Automobil automobilBlau = new Automobil(5, "Rot", 190, motorAutomobilBlau);
    Field[] fields = Automobil.class.getDeclaredFields();
    String kennzeichen = "";
    for (Field f : fields) {
      if (f.getName().toLowerCase().equals("momv")) {
        f.setAccessible(true);
        f.setInt(automobilBlau, 100);
      } else if (f.getName().toLowerCase().equals("kennzeichen")) {
        f.setAccessible(true);
        f.set(automobilBlau, "M-EX-X2013");
        kennzeichen = (String) f.get(automobilBlau);
      }
    }

    assertEquals("Das Automobil " + kennzeichen + " berechnet die Distanz falsch!", 1000, automobilBlau.getDistance(10));
  }

  @Test
  public void testRadarDetect() throws Exception {
    Motor motorAutomobilBlau = new Motor(77, 1200, 150, 4, 2.0);
    Automobil automobilBlau = new Automobil(5, "Rot", 190, motorAutomobilBlau);
    Radar radar = new Radar();

    Field[] fields = Automobil.class.getDeclaredFields();
    for (Field f : fields) {
      if (f.getName().toLowerCase().equals("momv")) {
        f.setAccessible(true);
        f.setInt(automobilBlau, 100);
      } else if (f.getName().toLowerCase().equals("kennzeichen")) {
        f.setAccessible(true);
        f.set(automobilBlau, "M-EX-X2013");
      }
    }
    radar.detect(automobilBlau);

    fields = Radar.class.getDeclaredFields();
    Field check4Field = null;
    for (Field field : fields) {
      if (field.getName().toLowerCase().equals("automobil")) {
        field.setAccessible(true);
        check4Field = field;
        break;
      }
    }

    if (check4Field != null) {
      assertEquals("Automobils werden vomm Radar nicht gespeichert!", automobilBlau, check4Field.get(radar));
      check4Field.setAccessible(false);
    } else {
      fail("Attribut \"automobil\" in Klasse Radar nicht gefunden.");
    }
  }

  @Test
  public void testAccessModifier() throws Exception {
    boolean allPrivate = true;
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < reqAttr.size(); i++) {
      Class<?> clazz = Class.forName(reqAttr.get(i));
      sb.append("\n>>> Test Access-Modifier \nClass: " + clazz.getName());
      Field[] attr = clazz.getDeclaredFields();
      for (Field f : attr) {
        if (!Modifier.isPrivate(f.getModifiers())) {
          allPrivate = false;
          sb.append("\n- " + f.getName() + " ist nicht private");
        }
      }
    }
    //assertTrue(sb.toString(), allPrivate);
  }
}
