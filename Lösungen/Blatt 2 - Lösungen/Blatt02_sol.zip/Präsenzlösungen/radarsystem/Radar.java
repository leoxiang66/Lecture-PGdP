
public class Radar {
  Automobil automobil;

  /**
   * Detektiert ein vorbeifahrendes Automobil
   * 
   * @param automobil: Das zu detektierende Automobil
   */
  public void detect(Automobil automobil) {
    System.out.print(automobil.kennzeichen);
    System.out.print(" fährt ");
    System.out.print(automobil.momV);
    System.out.print(" km/h");
    System.out.print("\n");
    this.automobil = automobil;
  }
}
