
public class Test {

  public static void main(String[] args) {

    // Deklaration und Instanziierung der Automobil-Objekte
    Motor motorAutomobilBlau = new Motor(77, 1200, 147, 4, 2.0);
    Motor motorAutomobilRot = new Motor(140, 1400, 170, 6, 2.6);
    Automobil automobilBlau = new Automobil(5, "Rot", 190, motorAutomobilBlau);
    Automobil automobilRot = new Automobil(5, "Blau", 250, motorAutomobilRot);
    Radar radar = new Radar();

    // Die geforderten Kennzeichen zuordnen
    automobilBlau.kennzeichen = "M-EX-X2013";
    automobilRot.kennzeichen = "M-PG-DP213";

    // Die momentane Geschwindigkeit setzten
    automobilBlau.momV = 100;
    automobilRot.momV = 200;

    // Das rote und blaue Automobil am Radar vorbeifahren lassen
    radar.detect(automobilBlau);
    radar.detect(automobilRot);

    // Die Distanz von dem blauen Automobil ermitteln.
    int distanzAutomobilBlau = automobilBlau.getDistance(1);
    System.out.print(automobilBlau.kennzeichen);
    System.out.print(" hat ");
    System.out.print(distanzAutomobilBlau);
    System.out.print(" km zurückgelegt.");
    System.out.print("\n");

    // Die Distanz von dem roten Automobil ermitteln.
    int distanzAutomobilRot = automobilRot.getDistance(1);
    System.out.print(automobilRot.kennzeichen);
    System.out.print(" hat ");
    System.out.print(distanzAutomobilRot);
    System.out.print(" km zurückgelegt.");
    System.out.print("\n");

    // Zuletzt detektiertes Automobil durch das Radar
    System.out.print("Radar: Zuletzt detektiertes Automobil ");
    System.out.print(radar.automobil.kennzeichen);
    System.out.print(".");
    System.out.print("\n");

    // Zusatzaufgabe
    System.out.println("\n//Ausgabe der Zusatzaufgabe zum Testen");

    // Zeitspanne deklarieren und instanziieren
    int milliProH = 3600 * 1000; // Millisekdunen pro Stunde
    java.util.Date endZeitpunkt = new java.util.Date();
    java.util.Date startZeitpunkt = new java.util.Date(endZeitpunkt.getTime() - (2 * milliProH));
    Zeitspanne zeitspanne = new Zeitspanne(endZeitpunkt, startZeitpunkt);

    // Die Distanz von dem blauen Automobil ermitteln und ausgeben.
    System.out.print(automobilRot.kennzeichen);
    System.out.print(" hat ");
    System.out.print(automobilBlau.getDistanceByTimespan(zeitspanne));
    System.out.print(" km zurückgelegt.");
    System.out.print("\n");

    // Die Distanz von dem roten Automobil ermitteln und ausgeben.
    System.out.print(automobilRot.kennzeichen);
    System.out.print(" hat ");
    System.out.print(automobilRot.getDistanceByTimespan(zeitspanne));
    System.out.print(" km zurückgelegt.");
    System.out.print("\n");
  }

}
