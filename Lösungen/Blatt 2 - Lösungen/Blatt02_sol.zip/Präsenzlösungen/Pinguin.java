public class Pinguin {
  private Pinguin vater;
  private Pinguin mutter;
  private String name;
  private String schnabelfarbe;
  private float schnabellaenge;

  public Pinguin(Pinguin vater, Pinguin mutter, String name, String schnabelfarbe, float schnabellaenge) {
    this.vater = vater;
    this.mutter = mutter;
    this.name = name;
    this.schnabelfarbe = schnabelfarbe;
    this.schnabellaenge = schnabellaenge;
  }

  public Pinguin(String name, String schnabelfarbe, float schnabellaenge) {
    this.name = name;
    this.schnabelfarbe = schnabelfarbe;
    this.schnabellaenge = schnabellaenge;
  }

  public Pinguin getVater() {
    return vater;
  }

  public Pinguin getMutter() {
    return mutter;
  }

  public String getName() {
    return name;
  }

  public String getSchnabelfarbe() {
    return schnabelfarbe;
  }

  public float getSchnabellaenge() {
    return schnabellaenge;
  }

  public void setVater(Pinguin vater) {
    this.vater = vater;
  }

  public void setMutter(Pinguin mutter) {
    this.mutter = mutter;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setSchnabelfarbe(String schnabelfarbe) {
    this.schnabelfarbe = schnabelfarbe;
  }

  public void setSchnabellaenge(float schnabellaenge) {
    this.schnabellaenge = schnabellaenge;
  }

  @Override
  public String toString() {
    String str;
    str = "Pinguinbeschreibung:" + "\n";
    str += "  Name: " + name + "\n";
    str += "  Schnabelfarbe: " + schnabelfarbe + "\n";
    str += "  Schnabellänge: " + schnabellaenge + "\n\n";
    return str;
  }

  public boolean isSibling(Pinguin pinguin) {
    return this.vater == pinguin.vater && this.mutter == pinguin.mutter;
  }

  public static void main(String[] args) {
    Pinguin adam = new Pinguin("Adam", "gelb", 5.0f);
    Pinguin eva = new Pinguin("Eva", "rot", 7.0f);
    Pinguin kain = new Pinguin(adam, eva, "Kain", "orange", 6.0f);
    System.out.println("" + kain);
  }

}
