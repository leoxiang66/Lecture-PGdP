# Ubuntu 18.04

```
sudo apt-get install junit4 libhamcrest-java
```

# Other OS:

Download most recent and stable 

- junit-4.xx.jar: https://github.com/junit-team/junit4/releases

- hamcrest-core-1.x.jar: https://search.maven.org/search?q=a:hamcrest-core

Then, edit test.bash, such that the paths to the corresponding .jar files are set correctly. Afterwards run the corresponding commands
