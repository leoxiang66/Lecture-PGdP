/**
 * The class {@code Date} represents a date.
 * 
 * @author Florian Kelbert
 *
 */
public class Date {
  
}
