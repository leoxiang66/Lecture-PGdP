import java.lang.Math;
import java.util.LinkedList;

public class RecursiveDeterminant {

  public static int[][] removeRow(int[][] matrix, int rowIndex) {
    int n = matrix.length;
    int m = matrix[0].length;
    int[][] result = new int[n-1][m];
    for (int i = 0, j = 0; i < n; i++)
      if (i != rowIndex) {
        for (int k = 0; k < m; k++)
            result[j][k] = matrix[i][k];
        j++;
      }
    return result;
  }

  public static int[][] removeColumn(int[][] matrix, int columnIndex) {
    int n = matrix.length;
    int m = matrix[0].length;
    int[][] result = new int[n][m-1];
    for (int i = 0; i < n; i++)
      for (int j = 0, k = 0; j < m; j++)
        if (j != columnIndex)
          result[i][k++] = matrix[i][j];
    return result;
  }

  public static int det2x2(int[][] matrix) {
    return matrix[0][0] * matrix[1][1] - matrix[1][0] * matrix[0][1];
  }

  public static int det3x3(int[][] matrix) {
    int sum = 0;
    for (int i = 0, sgn = 1; i < 3; i++, sgn *= -1)
      sum += sgn * matrix[0][i] * det2x2(removeRow(removeColumn(matrix, i), 0));
    return sum;
  }

  public static int detNxN(int[][] matrix) {
    int n = matrix.length;
    int m = matrix[0].length;
    int sum = 0;
    if (n == 2 && m == 2)
      sum = det2x2(matrix);
    else 
      for (int i = 0, sgn = 1; i < m; i++, sgn *= -1)
        sum += sgn * matrix[0][i] * detNxN(removeRow(removeColumn(matrix, i), 0));
    return sum;
  }
}
