
class ATest {
  public static void main(String[] argv) {
    Expression<Integer> e = new MulOp<Integer>(new AddOp<Integer>(new Const<Integer>(13), new Const<Integer>(4)),
        new MinusOp<Integer>(new Const<Integer>(2)));
    System.out.println(e.evaluate());
    assert (e.evaluate() == -34);
    System.out.println(e);
    Expression<Boolean> f = new OrOp<Boolean>(new AndOp<Boolean>(new Const<Boolean>(true),
        new OrOp<Boolean>(new Const<Boolean>(true), new Const<Boolean>(false))), new Const<Boolean>(false));
    System.out.println(f.evaluate());
    assert (f.evaluate() == true);
    System.out.println(f);
  }
}
