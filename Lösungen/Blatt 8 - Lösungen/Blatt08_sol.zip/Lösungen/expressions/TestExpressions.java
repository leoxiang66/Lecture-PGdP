
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class TestExpressions {

  @org.junit.Test
  public void tHA44Expression() throws Exception {
    Class clazz = Class.forName("ATest");
    StringBuilder sb = new StringBuilder("\n>>> Test HA44: Ausgabe von Klasse " + clazz.getName()
        + ".\nHinweis an Tutoren: Dieser Test schlaegt immer fehl! Ausagbe daher auf Spezifikation pruefen.\n**** Begin der Ausgabe. ****\n");

    PrintStream defaultOut = System.out;
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PrintStream out = new PrintStream(baos);
    System.setOut(out);

    String[] args = {};
    ATest.main(args);

    String output = baos.toString("UTF-8");
    sb.append(output);
    sb.append("\n**** Ende der Ausgabe. ****");
    System.setOut(defaultOut);

    org.junit.Assert.fail(sb.toString());
  }

  @org.junit.Test
  public void tHA45ZExpression() throws Exception {
    try {
      Class clazz = Class.forName("ZATest");
      StringBuilder sb = new StringBuilder("\n>>> Test HA45: Ausgabe von Klasse " + clazz.getName()
          + ".\nHinweis an Tutoren: Dieser Test schlaegt immer fehl! Ausagbe daher auf Spezifikation pruefen.\n**** Begin der Ausgabe. ****\n");

      PrintStream defaultOut = System.out;
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      PrintStream out = new PrintStream(baos);
      System.setOut(out);

      String[] args = {};
      ZATest.main(args);

      String output = baos.toString("UTF-8");
      sb.append(output);
      sb.append("\n**** Ende der Ausgabe. ****");
      System.setOut(defaultOut);

      org.junit.Assert.fail(sb.toString());
    } catch (ClassNotFoundException e) {

    }
  }
}
