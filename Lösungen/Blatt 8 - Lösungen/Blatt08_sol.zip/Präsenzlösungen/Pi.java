public class Pi {

  public static double piRec(long n) {
    if (0 == n)
      return 4.0;
    else // +/-4 == (4-8*(n%2))
      return (4 - 8 * (n % 2)) / (2 * n + 1.0) + piRec(n - 1);
  }

//Praezision eingeben    
  public static long piRecPrec(double epsilon, long n) {
    if (Math.abs((4 - 8 * (n % 2)) / (2 * n + 1.0)) < epsilon)
      return n;
    else // +/-4 == (4-8*(n%2))
      return piRecPrec(epsilon, n + 1);
  }

//Iterative Version um Stackoverflow zu vermeiden
  public static double piIt(long n) {
    double pi = 0.0;
    double f = 4.0;

    for (long i = n; i >= 0; i--) {
      pi += f / (2 * i + 1);
      f = -f;
    }

    return Math.abs(pi);
  }

  public static long piItPrec(float epsilon) {
    long n = 0;
    float f = 4;

    while (f > epsilon) {
      f = 4 / (2 * n + 1);
      n++;
    }

    return n;
  }

//Alternative Reihe, welche schneller konvergiert
  public static float piIt2(long n) {
    float pi = 0.0f;
    long i = n;
    while (i >= 0) {
      pi += 8 / ((4 * i + 1.0f) * (4 * i + 3.0f));
      i--;
    }

    return pi;
  }

  public static long piIt2Prec(float epsilon) {
    long n = 0;
    float f = 4;

    while (f > epsilon) {
      f = 8 / ((4 * n + 1.0f) * (4 * n + 3.0f));
      n++;
    }

    return n;
  }

  public static void main(String[] args) {
    System.out.println(piRec(1000));
    System.out.println(piRecPrec(0.0001, 0));
    System.out.println(piRec(2000));
    System.out.println(piIt(20001));
// Terminiert nicht schnell ;)
//           System.out.println(piItPrec(Float.MIN_VALUE));   
    // System.out.println(piIt2(2237));
  }
}
