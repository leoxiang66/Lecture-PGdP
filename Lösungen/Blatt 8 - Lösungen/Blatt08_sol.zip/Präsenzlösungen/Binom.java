public class Binom {
  public static long binom(long n, long k) {
    if ((k == 0) || (k == n)) {
      return 1;
    } else {
      return binom(n - 1, k - 1) + binom(n - 1, k);
    }
  }

  public static double sechsRichtige() {
    return 1.0 / binom(49, 6);
  }

  public static void main(String[] args) {
    System.out.println(binom(49, 6));
    System.out.println(sechsRichtige());
  }
}
