public class Quersumme {
  public static int quersummeIt(int zahl) {
    int qs = 0;
    while (zahl > 0) {
      qs = qs + zahl % 10;
      zahl = zahl / 10;
    }
    return qs;
  }

  public static int quersummeRec(int zahl) {
    if (zahl > 0) {
      return zahl % 10 + quersummeRec(zahl / 10);
    } else {
      return zahl;
    }
  }

  public static void main(String[] args) {
    System.out.println(quersummeIt(312));
    System.out.println(quersummeRec(312));
  }
}
