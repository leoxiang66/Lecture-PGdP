
public class Primverquerung {
  /**
   * Testet, ob eine Zahl eine Primzahl ist
   * 
   * @param x Zahl, die getestet werden soll
   * @return das Testergebnis
   */
  private static boolean isPrim(int x) {
    if (x == 2)
      return true;
    // Gerade Zahlen sind nicht prim (außer 2)
    if (x % 2 == 0)
      return false;
    // Wir prüfen alle möglichen Teiler bis zur Wurzel von x
    for (int i = 3; i * i <= x; i += 2)
      if (x % i == 0)
        return false;
    return true;
  }

  public static int querPrim(int n) {
    int result = 0;
    for (int i = 2; i < n; i++) {
      if (isPrim(i)) {
        int quersumme = 0;
        // Eine Ziffer der Quersumme erhalten wir über den Rest bei
        // Division durch 10. Eine Ziffer von der Zahl abschneiden erreichen
        // wir durch ganzzahlige Division durch 10.
        for (int z = i; z != 0; z /= 10)
          quersumme += z % 10;
        // Ist die Quersumme durch 2 teilbar, addieren wir die Zahl i.
        if (quersumme % 2 == 0)
          result += i;
      }
    }
    return result;
  }

  public static void main(String[] args) {
    System.out.println(querPrim(25));
    System.out.println(querPrim(89));
    System.out.println(querPrim(122));
    System.out.println(querPrim(5424));
    System.out.println(querPrim(0));
    System.out.println(querPrim(-1));
  }

}
