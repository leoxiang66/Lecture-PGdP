
public class Referenz {
  int wert;

  public static void main(String[] args) {
    Referenz referenz = new Referenz();
    setzeWert(referenz, 5);
    System.out.println("Referenzwert 1: " + referenz.wert);

    referenz = setzeWert(referenz, 15);
    System.out.println("Referenzwert 2: " + referenz.wert);

    setzeWert(null, 10);
    System.out.println("Referenzwert 3: " + referenz.wert);

    referenz = setzeWert(null, 20);
    System.out.println("Referenzwert 4: " + referenz.wert);

  }

  public static Referenz setzeWert(Referenz referenz, int wert) {
    if (referenz == null) {
      referenz = new Referenz();
    }
    referenz.wert = wert;

    return referenz;
  }
}
