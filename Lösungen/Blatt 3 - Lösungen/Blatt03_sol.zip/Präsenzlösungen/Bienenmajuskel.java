public class Bienenmajuskel {

  public static void main(String[] args) {
    boolean stopInput = false, firstWord = true;
    String upper = "", pascal = "", startCase = "", snake = "";
    while (!stopInput) {
      System.out.print("Eingabe beenden mit leerem String: ");
      String next = Terminal.readString();
      stopInput = (next.length() == 0);
      if (stopInput) {
        System.out.println("Uppercase:  " + upper + "\n" + "Startcase:  " + startCase + "\n" + "PascalCase: "
            + pascal + "\n" + "Snake-Case: " + snake);
      } else {
        // Backup zwecks ung🐧ltiger Eingabe
        String bUpper = upper;
        String bPascal = pascal;
        String bStartCase = startCase;
        String bSnake = snake;
        boolean inputOK = true;
        int pos = 0;
        while (pos < next.length()) {
          char current = next.charAt(pos), small = '?', capital = '?';
          if (current >= 'a' && current <= 'z') {
            small = current;
            capital = (char) (current + ('A' - 'a'));
          } else if (current >= 'A' && current <= 'Z') {
            small = (char) (current + ('a' - 'A'));
            capital = current;
          } else {
            inputOK = false;
          }
          upper = upper + capital;
          if (pos == 0) {
            pascal = pascal + capital;
            if (!firstWord) {
              snake = snake + "_";
            }
          } else {
            pascal = pascal + small;
          }
          if ((pos == 0) && firstWord) {
            startCase = startCase + capital;
          } else {
            startCase = startCase + small;
          }
          snake = snake + small;
          pos++;
        }
        if (!inputOK) {
          System.out.println("Ignoriere ungültige Eingabe!");
          upper = bUpper;
          pascal = bPascal;
          snake = bSnake;
          startCase = bStartCase;
        } else {
          firstWord = false;
        }
      }
    }
  }

}
