
public class Auto {
  private int sitzplaetze;
  private String farbe;
  private int maxV;
  private int momV;
  private String kennzeichen;
  private Motor motor;

  public Auto(int sitzplaetze, String farbe, int maxV, Motor motor) {
    this.sitzplaetze = sitzplaetze;
    this.farbe = farbe;
    this.maxV = maxV;
    this.motor = motor;
  }

  /**
   * Berechnet die zurückgelegte Distanz des Autos abhängig von einer Zeitspanne t
   * 
   * @param t: Zeitspanne in h
   * @return
   */
  public int getDistance(int t) {
    int s = this.momV * t;
    return s;
  }

  /**
   * Berechnet die zurückgelegte Distanz des Autos abhängig von einer Zeitspanne
   * zeitspanne
   * 
   * @param zeitspanne: Spezifiziert die Zeitspanne durch einen End- und
   *        Startzeitpunkt
   * @return
   */
  public long getDistanceByTimespan(Zeitspanne zeitspanne) {
    long s = this.momV * zeitspanne.getTimespan();
    return s;
  }

  public int getSitzplaetze() {
    return sitzplaetze;
  }

  public void setSitzplaetze(int sitzplaetze) {
    this.sitzplaetze = sitzplaetze;
  }

  public String getFarbe() {
    return farbe;
  }

  public void setFarbe(String farbe) {
    this.farbe = farbe;
  }

  public int getMaxV() {
    return maxV;
  }

  public void setMaxV(int maxV) {
    this.maxV = maxV;
  }

  public int getMomV() {
    return momV;
  }

  public void setMomV(int momV) {
    this.momV = momV;
  }

  public String getKennzeichen() {
    return kennzeichen;
  }

  public void setKennzeichen(String kennzeichen) {
    this.kennzeichen = kennzeichen;
  }

  public Motor getMotor() {
    return motor;
  }

  public void setMotor(Motor motor) {
    this.motor = motor;
  }

}
