public class Zeitspanne {

  private java.util.Date endZeitpunkt;
  private java.util.Date startZeitpunkt;

  /**
   * Erzeugt eine Zeitspanne
   * 
   * @param endZeitpunkt: Ende der Zeitspanne
   * @param startZeitpunkt: Beginn der Zeitspanne
   */
  public Zeitspanne(java.util.Date endZeitpunkt, java.util.Date startZeitpunkt) {
    this.endZeitpunkt = endZeitpunkt;
    this.startZeitpunkt = startZeitpunkt;
  }

  // Berechnet die Zeitspanne abhängig von den festgelegten End- und
  // Startzeitpunkt
  public long getTimespan() {
    int eineStunde = 3600 * 1000;
    return (this.endZeitpunkt.getTime() - this.startZeitpunkt.getTime()) / eineStunde;
  }

  public java.util.Date getEndZeitpunkt() {
    return endZeitpunkt;
  }

  public void setEndZeitpunkt(java.util.Date endZeitpunkt) {
    this.endZeitpunkt = endZeitpunkt;
  }

  public java.util.Date getStartZeitpunkt() {
    return startZeitpunkt;
  }

  public void setStartZeitpunkt(java.util.Date startZeitpunkt) {
    this.startZeitpunkt = startZeitpunkt;
  }

}
