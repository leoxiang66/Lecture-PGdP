
public class Radar {
  private Auto auto;

  /**
   * Detektiert ein vorbeifahrendes Auto
   * 
   * @param auto: Das zu detektierende Auto
   */
  public void detect(Auto auto) {
    System.out.print(auto.getKennzeichen());
    System.out.print(" fährt ");
    System.out.print(auto.getMomV());
    System.out.print(" km/h");
    System.out.print("\n");
    this.auto = auto;
  }

  public Auto getAuto() {
    return auto;
  }

  public void setAuto(Auto auto) {
    this.auto = auto;
  }

}
