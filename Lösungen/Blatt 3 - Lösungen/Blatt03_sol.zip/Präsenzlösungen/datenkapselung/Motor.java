
public class Motor {
  private int zylinder;
  private int leistung;
  private int gewicht;
  private double hubraum;

  public Motor(int pZylinder, int pLeistung, int pGewicht, double pHubraum) {
    this.zylinder = pZylinder;
    this.leistung = pLeistung;
    this.gewicht = pGewicht;
    this.hubraum = pHubraum;
  }

  public int getZylinder() {
    return zylinder;
  }

  public void setZylinder(int zylinder) {
    this.zylinder = zylinder;
  }

  public int getLeistung() {
    return leistung;
  }

  public void setLeistung(int leistung) {
    this.leistung = leistung;
  }

  public int getGewicht() {
    return gewicht;
  }

  public void setGewicht(int gewicht) {
    this.gewicht = gewicht;
  }

  public double getHubraum() {
    return hubraum;
  }

  public void setHubraum(double hubraum) {
    this.hubraum = hubraum;
  }

}
