
public enum HttpMethod {
  GET, POST
}
